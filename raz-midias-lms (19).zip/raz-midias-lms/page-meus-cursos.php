<?php
/**
 * Template Name: Meus Cursos
 * @package RazMidiasLMS
 */

if (!is_user_logged_in()) {
    wp_redirect(home_url('/entrar'));
    exit;
}

get_header();

$user = wp_get_current_user();
$user_id = $user->ID;
$cursos = raz_lms_get_user_courses($user_id);

// Verificar última aula acessada
$last_curso_id = get_user_meta($user_id, '_raz_last_curso', true);
$last_aula_id = $last_curso_id ? get_user_meta($user_id, '_raz_last_aula_' . $last_curso_id, true) : null;
$last_aula = $last_aula_id ? get_post($last_aula_id) : null;
$last_curso = $last_curso_id ? get_post($last_curso_id) : null;
?>

<div class="raz-dashboard">
    <header class="raz-dashboard-header">
        <div class="raz-dashboard-header-content">
            <div class="raz-dashboard-logo">
                <?php if (has_custom_logo()) : ?>
                    <?php the_custom_logo(); ?>
                <?php else : ?>
                    <a href="<?php echo home_url('/'); ?>" class="raz-site-name"><?php bloginfo('name'); ?></a>
                <?php endif; ?>
            </div>
            
            <div class="raz-dashboard-user">
                <span class="raz-user-name"><?php echo esc_html($user->display_name); ?></span>
                <div class="raz-dashboard-avatar raz-hide-mobile">
                    <?php echo raz_lms_get_initials($user->display_name); ?>
                </div>
                <a href="<?php echo wp_logout_url(home_url()); ?>" class="raz-logout-link">Sair</a>
            </div>
        </div>
    </header>
    
    <style>
    .raz-site-name { font-size: 1.25rem; font-weight: 700; color: var(--text-primary); text-decoration: none; }
    .raz-user-name { color: var(--text-secondary); font-size: 14px; }
    .raz-logout-link { color: var(--text-muted); text-decoration: none; font-size: 14px; margin-left: 12px; }
    .raz-logout-link:hover { color: var(--danger, #ef4444); }
    .raz-course-card-link { text-decoration: none; color: inherit; display: block; }
    .raz-course-card-link:hover .raz-course-card-image img { transform: scale(1.05); }
    .raz-course-card-image { overflow: hidden; }
    .raz-course-card-image img { transition: transform 0.3s; width: 100%; height: 100%; object-fit: cover; }
    .raz-course-card-title-link { text-decoration: none; color: inherit; }
    .raz-course-card-title-link:hover { color: var(--primary); }
    .raz-dashboard-footer { margin-top: 3rem; padding: 2rem; text-align: center; }
    .raz-dashboard-footer a { color: var(--text-secondary); font-size: .875rem; text-decoration: none; }
    .raz-dashboard-footer a:hover { color: var(--primary); }
    
    .raz-continue-banner {
        background: linear-gradient(135deg, var(--primary) 0%, #764ba2 100%);
        border-radius: 16px;
        padding: 24px;
        margin-bottom: 24px;
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 16px;
    }
    .raz-continue-info h3 { font-size: 14px; opacity: 0.9; margin-bottom: 4px; font-weight: 500; }
    .raz-continue-info p { font-size: 18px; font-weight: 600; margin: 0; }
    .raz-continue-info small { font-size: 12px; opacity: 0.8; }
    .raz-continue-btn {
        display: inline-flex; align-items: center; gap: 8px;
        background: #fff; color: var(--primary); padding: 12px 24px;
        border-radius: 10px; font-weight: 600; text-decoration: none;
        transition: transform 0.15s, box-shadow 0.15s;
    }
    .raz-continue-btn:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.2); }
    .raz-continue-btn svg { width: 18px; height: 18px; }
    
    @media (max-width: 600px) {
        .raz-site-name { font-size: 1rem; }
        .raz-user-name { display: none; }
        .raz-hide-mobile { display: none !important; }
        .raz-logout-link { margin-left: 0; }
        .raz-continue-banner { flex-direction: column; text-align: center; }
        .raz-continue-info p { font-size: 16px; }
    }
    </style>
    
    <div class="raz-dashboard-content">
        <div class="raz-dashboard-welcome">
            <h1>Olá, <?php echo esc_html(explode(' ', $user->display_name)[0]); ?>!</h1>
            <p>Continue de onde parou ou explore novos conteúdos.</p>
        </div>
        
        <?php if ($last_aula && $last_curso && raz_lms_user_has_access($user_id, $last_curso->ID)) : ?>
        <div class="raz-continue-banner">
            <div class="raz-continue-info">
                <h3>Continuar assistindo</h3>
                <p><?php echo esc_html($last_aula->post_title); ?></p>
                <small><?php echo esc_html($last_curso->post_title); ?></small>
            </div>
            <a href="<?php echo get_permalink($last_aula->ID); ?>" class="raz-continue-btn">
                <svg viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                Continuar
            </a>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($cursos)) : ?>
        <div class="raz-dashboard-section">
            <div class="raz-dashboard-section-header">
                <h2 class="raz-dashboard-section-title">Meus Cursos</h2>
            </div>
            
            <div class="raz-dashboard-courses">
                <?php foreach ($cursos as $curso) :
                    $expiracao = raz_lms_get_access_expiration($user_id, $curso->ID);
                    $expired = $expiracao && $expiracao !== 'vitalicio' && strtotime($expiracao) < time();
                    $continue_aula = raz_lms_get_first_incomplete_lesson($user_id, $curso->ID);
                    $curso_url = get_permalink($curso->ID);
                    
                    // Se tem última aula salva para este curso, usar ela
                    $saved_aula = get_user_meta($user_id, '_raz_last_aula_' . $curso->ID, true);
                    if ($saved_aula && get_post($saved_aula)) {
                        $continue_aula = get_post($saved_aula);
                    }
                ?>
                <div class="raz-course-card <?php echo $expired ? 'expired' : ''; ?>">
                    <a href="<?php echo esc_url($curso_url); ?>" class="raz-course-card-link">
                        <?php if (has_post_thumbnail($curso->ID)) : ?>
                        <div class="raz-course-card-image">
                            <?php echo get_the_post_thumbnail($curso->ID, 'raz-course-card'); ?>
                        </div>
                        <?php else : ?>
                        <div class="raz-course-card-image" style="background:linear-gradient(135deg,var(--bg-dark),#1a365d);display:flex;align-items:center;justify-content:center;">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:48px;height:48px;color:var(--primary);"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                        </div>
                        <?php endif; ?>
                    </a>
                    
                    <div class="raz-course-card-content">
                        <?php if ($expired) : ?>
                        <div class="raz-course-card-expired-badge">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                            Acesso expirado
                        </div>
                        <?php endif; ?>
                        
                        <a href="<?php echo esc_url($curso_url); ?>" class="raz-course-card-title-link">
                            <h3 class="raz-course-card-title"><?php echo esc_html($curso->post_title); ?></h3>
                        </a>
                        
                        <div class="raz-course-card-meta">
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                                <?php echo raz_lms_count_aulas($curso->ID); ?> aulas
                            </span>
                            <?php if ($expiracao === 'vitalicio') : ?>
                            <span style="color:var(--success);">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                                Vitalício
                            </span>
                            <?php elseif ($expiracao && !$expired) : ?>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                                até <?php echo date_i18n('d/m/Y', strtotime($expiracao)); ?>
                            </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="raz-course-card-progress">
                            <div class="raz-course-card-progress-header">
                                <span>Progresso</span>
                                <span><?php echo $curso->progresso['percent']; ?>%</span>
                            </div>
                            <div class="raz-course-card-progress-bar">
                                <div class="raz-course-card-progress-fill" style="width: <?php echo $curso->progresso['percent']; ?>%;"></div>
                            </div>
                        </div>
                        
                        <?php if (!$expired && $continue_aula) : ?>
                        <a href="<?php echo get_permalink($continue_aula->ID); ?>" class="raz-course-card-action">
                            <?php echo $curso->progresso['completed'] > 0 ? 'Continuar' : 'Começar'; ?>
                        </a>
                        <?php elseif ($expired) : ?>
                        <span class="raz-course-card-action" style="background:var(--text-muted);cursor:not-allowed;">Renovar Acesso</span>
                        <?php else : ?>
                        <a href="<?php echo esc_url($curso_url); ?>" class="raz-course-card-action">Ver Curso</a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php else : ?>
        <div class="raz-access-blocked" style="background:var(--bg-primary);border-radius:12px;padding:3rem;">
            <div class="raz-access-blocked-icon" style="background:var(--bg-tertiary);">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--primary);"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
            </div>
            <h3 class="raz-access-blocked-title">Nenhum curso ainda</h3>
            <p class="raz-access-blocked-message">Você ainda não possui cursos. Explore nossa biblioteca e comece sua jornada de aprendizado!</p>
            <a href="<?php echo home_url('/cursos/'); ?>" class="raz-access-blocked-btn">Explorar Cursos</a>
        </div>
        <?php endif; ?>
        
        <footer class="raz-dashboard-footer">
            <a href="<?php echo wp_logout_url(home_url()); ?>">Sair da conta</a>
        </footer>
    </div>
</div>

<?php get_footer(); ?>
