<?php
/**
 * WooCommerce Integration
 * @package RazMidiasLMS
 */

defined('ABSPATH') || exit;

/**
 * Verificar se WooCommerce está ativo
 */
function raz_lms_woo_active() {
    return class_exists('WooCommerce');
}

/**
 * Adicionar meta box no produto WooCommerce
 */
function raz_lms_woo_product_meta_box() {
    if (!raz_lms_woo_active()) return;
    
    add_meta_box(
        'raz_lms_product_curso',
        'Curso Vinculado (Raz LMS)',
        'raz_lms_woo_product_meta_callback',
        'product',
        'side',
        'high'
    );
}
add_action('add_meta_boxes', 'raz_lms_woo_product_meta_box');

function raz_lms_woo_product_meta_callback($post) {
    wp_nonce_field('raz_lms_woo_product', 'raz_lms_woo_nonce');
    
    $curso_id = get_post_meta($post->ID, '_raz_produto_curso', true);
    $dias = get_post_meta($post->ID, '_raz_produto_dias_acesso', true) ?: 365;
    $vitalicio = get_post_meta($post->ID, '_raz_produto_vitalicio', true);
    
    $cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC'));
    ?>
    <p>
        <label><strong>Curso:</strong></label><br>
        <select name="raz_produto_curso" style="width:100%;">
            <option value="">Nenhum curso</option>
            <?php foreach ($cursos as $curso) : ?>
            <option value="<?php echo $curso->ID; ?>" <?php selected($curso_id, $curso->ID); ?>><?php echo esc_html($curso->post_title); ?></option>
            <?php endforeach; ?>
        </select>
    </p>
    <p>
        <label><strong>Dias de Acesso:</strong></label><br>
        <input type="number" name="raz_produto_dias_acesso" value="<?php echo intval($dias); ?>" min="1" style="width:100%;">
    </p>
    <p>
        <label>
            <input type="checkbox" name="raz_produto_vitalicio" value="1" <?php checked($vitalicio, '1'); ?>>
            Acesso Vitalício
        </label>
    </p>
    <?php
}

function raz_lms_woo_save_product_meta($post_id) {
    if (!isset($_POST['raz_lms_woo_nonce']) || !wp_verify_nonce($_POST['raz_lms_woo_nonce'], 'raz_lms_woo_product')) {
        return;
    }
    
    if (isset($_POST['raz_produto_curso'])) {
        update_post_meta($post_id, '_raz_produto_curso', intval($_POST['raz_produto_curso']));
    }
    if (isset($_POST['raz_produto_dias_acesso'])) {
        update_post_meta($post_id, '_raz_produto_dias_acesso', intval($_POST['raz_produto_dias_acesso']));
    }
    $vitalicio = isset($_POST['raz_produto_vitalicio']) ? '1' : '';
    update_post_meta($post_id, '_raz_produto_vitalicio', $vitalicio);
}
add_action('save_post_product', 'raz_lms_woo_save_product_meta');

/**
 * Liberar acesso quando pedido for concluído
 */
function raz_lms_woo_order_completed($order_id) {
    if (!raz_lms_woo_active()) return;
    
    $order = wc_get_order($order_id);
    if (!$order) return;
    
    $user_id = $order->get_user_id();
    if (!$user_id) return;
    
    foreach ($order->get_items() as $item) {
        $product_id = $item->get_product_id();
        $curso_id = get_post_meta($product_id, '_raz_produto_curso', true);
        
        if ($curso_id) {
            $dias = get_post_meta($product_id, '_raz_produto_dias_acesso', true) ?: 365;
            $vitalicio = get_post_meta($product_id, '_raz_produto_vitalicio', true) === '1';
            
            // Verificar se já tem acesso (renovar) ou liberar novo
            if (raz_lms_user_has_access($user_id, $curso_id)) {
                raz_lms_renew_access($user_id, $curso_id, $dias);
            } else {
                raz_lms_grant_access($user_id, $curso_id, $dias, $vitalicio);
            }
            
            // Log
            $order->add_order_note(sprintf(
                'Acesso ao curso "%s" liberado para o usuário #%d. Dias: %s',
                get_the_title($curso_id),
                $user_id,
                $vitalicio ? 'Vitalício' : $dias
            ));
        }
    }
}
add_action('woocommerce_order_status_completed', 'raz_lms_woo_order_completed');
add_action('woocommerce_order_status_processing', 'raz_lms_woo_order_completed');

/**
 * Webhook handler genérico (para Kiwify via Uncanny Automator ou direto)
 * URL: /wp-json/raz-lms/v1/webhook
 */
function raz_lms_webhook_handler(WP_REST_Request $request) {
    $payload = $request->get_json_params();
    
    // Log para debug
    if (WP_DEBUG) {
        error_log('RAZ LMS Webhook: ' . print_r($payload, true));
    }
    
    // Kiwify format
    if (isset($payload['event'])) {
        $event = $payload['event'];
        
        if (in_array($event, array('order_approved', 'order_paid', 'subscription_renewed'))) {
            return raz_lms_process_webhook_purchase($payload);
        }
        
        if (in_array($event, array('subscription_canceled', 'refund', 'chargeback'))) {
            return raz_lms_process_webhook_cancel($payload);
        }
    }
    
    // Generic format (email + curso_id)
    if (isset($payload['email']) && isset($payload['curso_id'])) {
        $email = sanitize_email($payload['email']);
        $curso_id = intval($payload['curso_id']);
        $dias = isset($payload['dias']) ? intval($payload['dias']) : 365;
        $vitalicio = isset($payload['vitalicio']) && $payload['vitalicio'];
        
        $user = get_user_by('email', $email);
        if (!$user) {
            // Criar usuário
            $username = sanitize_user(strtok($email, '@'));
            $counter = 1;
            while (username_exists($username)) { $username = $username . $counter++; }
            
            $user_id = wp_create_user($username, wp_generate_password(12, false), $email);
            if (is_wp_error($user_id)) {
                return new WP_REST_Response(array('error' => 'Erro ao criar usuário'), 400);
            }
            
            wp_new_user_notification($user_id, null, 'user');
        } else {
            $user_id = $user->ID;
        }
        
        raz_lms_grant_access($user_id, $curso_id, $dias, $vitalicio);
        
        return new WP_REST_Response(array('success' => true, 'user_id' => $user_id), 200);
    }
    
    return new WP_REST_Response(array('error' => 'Formato inválido'), 400);
}

function raz_lms_process_webhook_purchase($payload) {
    $customer = isset($payload['Customer']) ? $payload['Customer'] : array();
    $product = isset($payload['Product']) ? $payload['Product'] : array();
    
    $email = isset($customer['email']) ? sanitize_email($customer['email']) : '';
    $nome = isset($customer['full_name']) ? sanitize_text_field($customer['full_name']) : '';
    $product_id = isset($product['product_id']) ? sanitize_text_field($product['product_id']) : '';
    
    if (!$email) {
        return new WP_REST_Response(array('error' => 'Email não fornecido'), 400);
    }
    
    // Buscar ou criar usuário
    $user = get_user_by('email', $email);
    if (!$user) {
        $username = sanitize_user(strtok($email, '@'));
        $counter = 1;
        while (username_exists($username)) { $username = $username . $counter++; }
        
        $user_id = wp_create_user($username, wp_generate_password(12, false), $email);
        if (is_wp_error($user_id)) {
            return new WP_REST_Response(array('error' => 'Erro ao criar usuário'), 400);
        }
        
        wp_update_user(array('ID' => $user_id, 'display_name' => $nome));
        wp_new_user_notification($user_id, null, 'user');
    } else {
        $user_id = $user->ID;
    }
    
    // Buscar curso pelo ID do produto Kiwify
    $cursos = get_posts(array(
        'post_type' => 'curso',
        'posts_per_page' => 1,
        'meta_key' => '_raz_curso_kiwify_id',
        'meta_value' => $product_id
    ));
    
    if (!empty($cursos)) {
        $curso_id = $cursos[0]->ID;
        $dias = get_post_meta($curso_id, '_raz_curso_dias_acesso', true) ?: 365;
        $vitalicio = get_post_meta($curso_id, '_raz_curso_vitalicio', true) === '1';
        
        if (raz_lms_user_has_access($user_id, $curso_id)) {
            raz_lms_renew_access($user_id, $curso_id, $dias);
        } else {
            raz_lms_grant_access($user_id, $curso_id, $dias, $vitalicio);
        }
    }
    
    return new WP_REST_Response(array('success' => true), 200);
}

function raz_lms_process_webhook_cancel($payload) {
    $customer = isset($payload['Customer']) ? $payload['Customer'] : array();
    $product = isset($payload['Product']) ? $payload['Product'] : array();
    
    $email = isset($customer['email']) ? sanitize_email($customer['email']) : '';
    $product_id = isset($product['product_id']) ? sanitize_text_field($product['product_id']) : '';
    
    if (!$email) return new WP_REST_Response(array('error' => 'Email não fornecido'), 400);
    
    $user = get_user_by('email', $email);
    if (!$user) return new WP_REST_Response(array('error' => 'Usuário não encontrado'), 404);
    
    $cursos = get_posts(array(
        'post_type' => 'curso',
        'posts_per_page' => 1,
        'meta_key' => '_raz_curso_kiwify_id',
        'meta_value' => $product_id
    ));
    
    if (!empty($cursos)) {
        raz_lms_revoke_access($user->ID, $cursos[0]->ID);
    }
    
    return new WP_REST_Response(array('success' => true), 200);
}

// Registrar endpoint REST
add_action('rest_api_init', function() {
    register_rest_route('raz-lms/v1', '/webhook', array(
        'methods' => 'POST',
        'callback' => 'raz_lms_webhook_handler',
        'permission_callback' => '__return_true'
    ));
    
    // Manter compatibilidade com endpoint antigo Kiwify
    register_rest_route('raz-lms/v1', '/kiwify', array(
        'methods' => 'POST',
        'callback' => 'raz_lms_webhook_handler',
        'permission_callback' => '__return_true'
    ));
});
