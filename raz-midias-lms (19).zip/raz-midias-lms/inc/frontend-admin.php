<?php
/**
 * Frontend Admin Panel - Painel amigável para administrador
 * @package RazMidiasLMS
 */

defined('ABSPATH') || exit;

/**
 * Registrar página do painel admin
 */
function raz_lms_register_admin_page() {
    add_rewrite_rule('^gestao-cursos/?$', 'index.php?raz_admin_page=dashboard', 'top');
    add_rewrite_rule('^gestao-cursos/([^/]+)/?$', 'index.php?raz_admin_page=$matches[1]', 'top');
    add_rewrite_rule('^gestao-cursos/([^/]+)/([0-9]+)/?$', 'index.php?raz_admin_page=$matches[1]&raz_item_id=$matches[2]', 'top');
}
add_action('init', 'raz_lms_register_admin_page');

/**
 * Flush rewrite rules on theme activation
 */
function raz_lms_flush_rewrite_rules() {
    raz_lms_register_admin_page();
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'raz_lms_flush_rewrite_rules');

/**
 * Also check and flush if needed
 */
function raz_lms_maybe_flush_rules() {
    if (get_option('raz_lms_flush_rules') !== 'done') {
        flush_rewrite_rules();
        update_option('raz_lms_flush_rules', 'done');
    }
}
add_action('init', 'raz_lms_maybe_flush_rules', 99);

function raz_lms_admin_query_vars($vars) {
    $vars[] = 'raz_admin_page';
    $vars[] = 'raz_item_id';
    return $vars;
}
add_filter('query_vars', 'raz_lms_admin_query_vars');

function raz_lms_admin_template($template) {
    // Suportar tanto pretty URL quanto query string
    $page = get_query_var('raz_admin_page');
    
    // Fallback: verificar query string direta
    if (!$page && isset($_GET['raz_admin_page'])) {
        $page = sanitize_text_field($_GET['raz_admin_page']);
    }
    
    if ($page && current_user_can('manage_options')) {
        // Definir variáveis globais para o template
        global $raz_admin_page, $raz_item_id;
        $raz_admin_page = $page;
        $raz_item_id = get_query_var('raz_item_id') ?: (isset($_GET['raz_item_id']) ? intval($_GET['raz_item_id']) : 0);
        
        return RAZ_LMS_DIR . '/templates/admin-panel.php';
    }
    return $template;
}
add_filter('template_include', 'raz_lms_admin_template');

/**
 * Add admin menu link to frontend panel
 */
function raz_lms_admin_bar_menu($wp_admin_bar) {
    if (!current_user_can('manage_options')) return;
    
    $wp_admin_bar->add_node(array(
        'id' => 'raz-lms-gestao',
        'title' => '📚 Gestão LMS',
        'href' => home_url('/gestao-cursos/'),
        'meta' => array('target' => '_self')
    ));
}
add_action('admin_bar_menu', 'raz_lms_admin_bar_menu', 100);

/**
 * AJAX: Salvar curso
 */
function raz_lms_ajax_save_curso() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $curso_id = isset($_POST['curso_id']) ? intval($_POST['curso_id']) : 0;
    $titulo = sanitize_text_field($_POST['titulo']);
    $descricao = isset($_POST['descricao']) ? wp_kses_post($_POST['descricao']) : '';
    $conteudo = isset($_POST['conteudo']) ? wp_kses_post($_POST['conteudo']) : '';
    
    $post_data = array(
        'post_title' => $titulo,
        'post_excerpt' => $descricao,
        'post_content' => $conteudo,
        'post_type' => 'curso',
        'post_status' => 'publish'
    );
    
    if ($curso_id) {
        $post_data['ID'] = $curso_id;
        wp_update_post($post_data);
    } else {
        $curso_id = wp_insert_post($post_data);
    }
    
    // Upload de thumbnail
    if (!empty($_FILES['thumbnail']['name'])) {
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        
        $attachment_id = media_handle_upload('thumbnail', $curso_id);
        if (!is_wp_error($attachment_id)) {
            set_post_thumbnail($curso_id, $attachment_id);
        }
    } elseif (isset($_POST['thumbnail_id']) && intval($_POST['thumbnail_id']) > 0) {
        set_post_thumbnail($curso_id, intval($_POST['thumbnail_id']));
    }
    
    // Salvar metas
    if (isset($_POST['produto_woo'])) {
        update_post_meta($curso_id, '_raz_curso_produto_woo', intval($_POST['produto_woo']));
    }
    if (isset($_POST['dias_acesso'])) {
        update_post_meta($curso_id, '_raz_curso_dias_acesso', intval($_POST['dias_acesso']));
    }
    if (isset($_POST['kiwify_id'])) {
        update_post_meta($curso_id, '_raz_curso_kiwify_id', sanitize_text_field($_POST['kiwify_id']));
    }
    if (isset($_POST['cor_header'])) {
        update_post_meta($curso_id, '_raz_curso_cor_header', sanitize_hex_color($_POST['cor_header']));
    }
    if (isset($_POST['cor_controls'])) {
        update_post_meta($curso_id, '_raz_curso_cor_controls', sanitize_hex_color($_POST['cor_controls']));
    }
    $vitalicio = isset($_POST['vitalicio']) && $_POST['vitalicio'] === '1' ? '1' : '';
    update_post_meta($curso_id, '_raz_curso_vitalicio', $vitalicio);
    
    wp_send_json_success(array('curso_id' => $curso_id, 'message' => 'Curso salvo!'));
}
add_action('wp_ajax_raz_save_curso', 'raz_lms_ajax_save_curso');

/**
 * AJAX: Salvar módulo
 */
function raz_lms_ajax_save_modulo() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $modulo_id = isset($_POST['modulo_id']) ? intval($_POST['modulo_id']) : 0;
    $titulo = sanitize_text_field($_POST['titulo']);
    $curso_id = intval($_POST['curso_id']);
    $ordem = isset($_POST['ordem']) ? intval($_POST['ordem']) : 0;
    
    $post_data = array(
        'post_title' => $titulo,
        'post_type' => 'modulo',
        'post_status' => 'publish'
    );
    
    if ($modulo_id) {
        $post_data['ID'] = $modulo_id;
        wp_update_post($post_data);
    } else {
        $modulo_id = wp_insert_post($post_data);
    }
    
    update_post_meta($modulo_id, '_raz_modulo_curso', $curso_id);
    update_post_meta($modulo_id, '_raz_modulo_ordem', $ordem);
    
    wp_send_json_success(array('modulo_id' => $modulo_id, 'message' => 'Módulo salvo!'));
}
add_action('wp_ajax_raz_save_modulo', 'raz_lms_ajax_save_modulo');

/**
 * AJAX: Salvar aula
 */
function raz_lms_ajax_save_aula() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $aula_id = isset($_POST['aula_id']) ? intval($_POST['aula_id']) : 0;
    $titulo = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : (isset($_POST['titulo']) ? sanitize_text_field($_POST['titulo']) : '');
    $conteudo = isset($_POST['content']) ? wp_kses_post($_POST['content']) : (isset($_POST['conteudo']) ? wp_kses_post($_POST['conteudo']) : '');
    $modulo_id = intval($_POST['modulo_id']);
    $ordem = isset($_POST['ordem']) ? intval($_POST['ordem']) : 0;
    $video_provider = isset($_POST['video_provider']) ? sanitize_text_field($_POST['video_provider']) : '';
    $video_url = isset($_POST['video_url']) ? esc_url_raw($_POST['video_url']) : '';
    $duracao = isset($_POST['duracao']) ? sanitize_text_field($_POST['duracao']) : '';
    
    // Verificar se está travada
    if ($aula_id && raz_lms_is_locked($aula_id)) {
        wp_send_json_error(array('message' => 'Esta aula está travada'));
    }
    
    // Se não tem ordem definida, pegar a próxima
    if (!$ordem && $modulo_id) {
        $existing_aulas = raz_lms_get_aulas($modulo_id);
        $ordem = count($existing_aulas);
    }
    
    // Salvar versão antes de editar
    if ($aula_id) {
        raz_lms_save_content_version($aula_id, 'auto');
    }
    
    $post_data = array(
        'post_title' => $titulo,
        'post_content' => $conteudo,
        'post_type' => 'aula',
        'post_status' => 'publish'
    );
    
    if ($aula_id) {
        $post_data['ID'] = $aula_id;
        wp_update_post($post_data);
    } else {
        $aula_id = wp_insert_post($post_data);
    }
    
    update_post_meta($aula_id, '_raz_aula_modulo', $modulo_id);
    update_post_meta($aula_id, '_raz_aula_ordem', $ordem);
    update_post_meta($aula_id, '_raz_aula_video_url', $video_url);
    update_post_meta($aula_id, '_raz_aula_video_provider', $video_provider);
    update_post_meta($aula_id, '_raz_aula_duracao', $duracao);
    
    // Definir tipo baseado no vídeo
    $tipo = $video_url ? 'video' : 'texto';
    update_post_meta($aula_id, '_raz_aula_tipo', $tipo);
    
    // Salvar materiais (aceita JSON string ou array)
    $materiais = array();
    if (isset($_POST['materiais'])) {
        $mat_data = $_POST['materiais'];
        if (is_string($mat_data)) {
            $mat_data = json_decode(stripslashes($mat_data), true);
        }
        if (is_array($mat_data)) {
            foreach ($mat_data as $mat) {
                $materiais[] = array(
                    'nome' => sanitize_text_field($mat['nome'] ?? ''),
                    'display_name' => sanitize_text_field($mat['display_name'] ?? $mat['nome'] ?? ''),
                    'url' => esc_url_raw($mat['url'] ?? ''),
                    'tipo' => sanitize_text_field($mat['tipo'] ?? '')
                );
            }
        }
    }
    update_post_meta($aula_id, '_raz_aula_materiais', $materiais);
    
    // Salvar rotina de estudos
    if (isset($_POST['rotina'])) {
        $rotina_data = $_POST['rotina'];
        if (is_string($rotina_data)) {
            $rotina_data = json_decode(stripslashes($rotina_data), true);
        }
        if (is_array($rotina_data)) {
            update_post_meta($aula_id, '_raz_aula_rotina', array(
                'ativa' => !empty($rotina_data['ativa']),
                'dias' => intval($rotina_data['dias'] ?? 0),
                'mensagem' => sanitize_text_field($rotina_data['mensagem'] ?? '')
            ));
        }
    }
    
    // Limpar rascunho automático
    raz_lms_clear_auto_draft($aula_id);
    
    wp_send_json_success(array('aula_id' => $aula_id, 'message' => 'Aula salva!'));
}
add_action('wp_ajax_raz_save_aula', 'raz_lms_ajax_save_aula');

/**
 * AJAX: Deletar item
 */
function raz_lms_ajax_delete_item() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $item_id = intval($_POST['item_id']);
    $tipo = sanitize_text_field($_POST['tipo']);
    
    if ($tipo === 'modulo') {
        $aulas = raz_lms_get_aulas($item_id);
        foreach ($aulas as $aula) {
            wp_delete_post($aula->ID, true);
        }
    }
    
    wp_delete_post($item_id, true);
    
    wp_send_json_success(array('message' => 'Item deletado!'));
}
add_action('wp_ajax_raz_delete_item', 'raz_lms_ajax_delete_item');

/**
 * AJAX: Liberar acesso manual
 */
function raz_lms_ajax_grant_access() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $user_id = intval($_POST['user_id']);
    $curso_id = intval($_POST['curso_id']);
    $dias = intval($_POST['dias']) ?: 365;
    $vitalicio = isset($_POST['vitalicio']) && $_POST['vitalicio'] === '1';
    
    raz_lms_grant_access($user_id, $curso_id, $dias, $vitalicio);
    
    wp_send_json_success(array('message' => 'Acesso liberado!'));
}
add_action('wp_ajax_raz_grant_access', 'raz_lms_ajax_grant_access');

/**
 * AJAX: Reordenar módulos/aulas
 */
function raz_lms_ajax_reorder() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $items_raw = isset($_POST['items']) ? $_POST['items'] : '[]';
    $items = json_decode(stripslashes($items_raw), true);
    $tipo = sanitize_text_field($_POST['tipo']);
    
    if (!is_array($items)) {
        wp_send_json_error(array('message' => 'Dados inválidos'));
    }
    
    foreach ($items as $index => $item_id) {
        if ($tipo === 'modulo') {
            update_post_meta(intval($item_id), '_raz_modulo_ordem', $index);
        } else {
            update_post_meta(intval($item_id), '_raz_aula_ordem', $index);
        }
    }
    
    wp_send_json_success(array('message' => 'Ordem salva!'));
}
add_action('wp_ajax_raz_reorder', 'raz_lms_ajax_reorder');

/**
 * AJAX: Buscar cursos do usuário (para modal)
 */
function raz_lms_ajax_get_user_courses() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : (isset($_GET['user_id']) ? intval($_GET['user_id']) : 0);
    
    if (!$user_id) {
        wp_send_json_error(array('message' => 'ID do usuário não informado'));
    }
    
    $user_courses = raz_lms_get_user_courses($user_id);
    
    $courses_data = array();
    foreach ($user_courses as $curso) {
        $acesso = get_user_meta($user_id, '_raz_curso_acesso_' . $curso->ID, true);
        $ativo = raz_lms_user_has_access($user_id, $curso->ID);
        
        $expiracao = '-';
        if (isset($acesso['vitalicio']) && $acesso['vitalicio']) {
            $expiracao = 'Vitalício';
        } elseif (isset($acesso['expiracao'])) {
            $expiracao = date_i18n('d/m/Y', strtotime($acesso['expiracao']));
        }
        
        $courses_data[] = array(
            'id' => $curso->ID,
            'titulo' => $curso->post_title,
            'status' => $ativo ? 'ativo' : 'expirado',
            'expiracao' => $expiracao
        );
    }
    
    wp_send_json_success(array('courses' => $courses_data));
}
add_action('wp_ajax_raz_get_user_courses', 'raz_lms_ajax_get_user_courses');

/**
 * Exportar alunos via GET
 */
function raz_lms_export_alunos_direct() {
    if (!isset($_GET['raz_export']) || $_GET['raz_export'] !== 'alunos') return;
    if (!isset($_GET['nonce']) || !wp_verify_nonce($_GET['nonce'], 'raz_export_nonce')) return;
    if (!current_user_can('manage_options')) return;
    
    while (ob_get_level()) ob_end_clean();
    
    global $wpdb;
    
    $curso_id = isset($_GET['curso_id']) ? intval($_GET['curso_id']) : 0;
    $status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=alunos_' . date('Y-m-d') . '.csv');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    $output = fopen('php://output', 'w');
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    fputcsv($output, array('Nome', 'Email', 'Telefone', 'Curso', 'Data Início', 'Expiração', 'Status', 'Origem', 'Progresso'), ';');
    
    $where = "WHERE meta_key LIKE '_raz_curso_acesso_%'";
    if ($curso_id) {
        $where .= $wpdb->prepare(" AND meta_key = %s", '_raz_curso_acesso_' . $curso_id);
    }
    
    $acessos = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} {$where}");
    
    foreach ($acessos as $acesso) {
        $user = get_userdata($acesso->user_id);
        $cid = str_replace('_raz_curso_acesso_', '', $acesso->meta_key);
        $curso = get_post($cid);
        $data = maybe_unserialize($acesso->meta_value);
        
        if (!$user || !$curso) continue;
        
        $ativo = raz_lms_user_has_access($acesso->user_id, $cid);
        
        if ($status_filter === 'ativo' && !$ativo) continue;
        if ($status_filter === 'expirado' && $ativo) continue;
        
        $exp = '';
        if (isset($data['vitalicio']) && $data['vitalicio']) {
            $exp = 'Vitalício';
        } elseif (isset($data['expiracao'])) {
            $exp = date_i18n('d/m/Y', strtotime($data['expiracao']));
        }
        
        $telefone = get_user_meta($acesso->user_id, '_raz_telefone', true);
        $origem = isset($data['origem']) ? $data['origem'] : 'manual';
        $progress = raz_lms_get_course_progress($acesso->user_id, $cid);
        
        fputcsv($output, array(
            $user->display_name,
            $user->user_email,
            $telefone ?: '',
            $curso->post_title,
            isset($data['inicio']) ? date_i18n('d/m/Y', strtotime($data['inicio'])) : '',
            $exp,
            $ativo ? 'Ativo' : 'Expirado',
            ucfirst($origem),
            $progress['percent'] . '%'
        ), ';');
    }
    
    fclose($output);
    exit;
}
add_action('init', 'raz_lms_export_alunos_direct');

/**
 * Exportar relatório via GET
 */
function raz_lms_export_relatorio_direct() {
    if (!isset($_GET['raz_export']) || $_GET['raz_export'] !== 'relatorio') return;
    if (!isset($_GET['nonce']) || !wp_verify_nonce($_GET['nonce'], 'raz_export_nonce')) return;
    if (!current_user_can('manage_options')) return;
    
    while (ob_get_level()) ob_end_clean();
    
    global $wpdb;
    
    $tipo = isset($_GET['tipo']) ? sanitize_text_field($_GET['tipo']) : 'resumo';
    $curso_id = isset($_GET['curso_id']) ? intval($_GET['curso_id']) : 0;
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=relatorio_' . $tipo . '_' . date('Y-m-d') . '.csv');
    header('Pragma: no-cache');
    
    $output = fopen('php://output', 'w');
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    if ($tipo === 'resumo') {
        fputcsv($output, array('Curso', 'Total Alunos', 'Total Aulas', 'Conclusões', 'Taxa Conclusão'), ';');
        
        $cursos = $curso_id ? array(get_post($curso_id)) : get_posts(array('post_type' => 'curso', 'posts_per_page' => -1));
        
        foreach ($cursos as $curso) {
            if (!$curso) continue;
            $alunos = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s", '_raz_curso_acesso_' . $curso->ID));
            $aulas = raz_lms_count_aulas($curso->ID);
            
            $conclusoes = 0;
            $acessos = $wpdb->get_results($wpdb->prepare("SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s", '_raz_curso_acesso_' . $curso->ID));
            foreach ($acessos as $a) {
                $p = raz_lms_get_course_progress($a->user_id, $curso->ID);
                if ($p['percent'] >= 100) $conclusoes++;
            }
            
            $taxa = $alunos > 0 ? round(($conclusoes / $alunos) * 100) : 0;
            
            fputcsv($output, array($curso->post_title, $alunos, $aulas, $conclusoes, $taxa . '%'), ';');
        }
    } else {
        fputcsv($output, array('Aluno', 'Email', 'Curso', 'Progresso', 'Aulas Concluídas', 'Total Aulas'), ';');
        
        $where = "WHERE meta_key LIKE '_raz_curso_acesso_%'";
        if ($curso_id) $where .= $wpdb->prepare(" AND meta_key = %s", '_raz_curso_acesso_' . $curso_id);
        
        $acessos = $wpdb->get_results("SELECT user_id, meta_key FROM {$wpdb->usermeta} {$where}");
        
        foreach ($acessos as $a) {
            $user = get_userdata($a->user_id);
            $cid = str_replace('_raz_curso_acesso_', '', $a->meta_key);
            $curso = get_post($cid);
            if (!$user || !$curso) continue;
            
            $p = raz_lms_get_course_progress($a->user_id, $cid);
            
            fputcsv($output, array($user->display_name, $user->user_email, $curso->post_title, $p['percent'] . '%', $p['completed'], $p['total']), ';');
        }
    }
    
    fclose($output);
    exit;
}
add_action('init', 'raz_lms_export_relatorio_direct');

/**
 * AJAX: Obter dados do usuário para edição
 */
function raz_lms_ajax_get_user_data() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $user_id = intval($_GET['user_id']);
    $user = get_userdata($user_id);
    
    if (!$user) {
        wp_send_json_error(array('message' => 'Usuário não encontrado'));
    }
    
    // Obter cursos do usuário
    $cursos = array();
    global $wpdb;
    $metas = $wpdb->get_results($wpdb->prepare(
        "SELECT meta_key FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key LIKE '_raz_curso_acesso_%%'",
        $user_id
    ));
    
    foreach ($metas as $meta) {
        $curso_id = str_replace('_raz_curso_acesso_', '', $meta->meta_key);
        $cursos[] = intval($curso_id);
    }
    
    $telefone = get_user_meta($user_id, '_raz_telefone', true);
    
    wp_send_json_success(array(
        'id' => $user->ID,
        'name' => $user->display_name,
        'email' => $user->user_email,
        'telefone' => $telefone,
        'cursos' => $cursos
    ));
}
add_action('wp_ajax_raz_get_user_data', 'raz_lms_ajax_get_user_data');

/**
 * AJAX: Salvar usuário (criar ou atualizar)
 */
function raz_lms_ajax_save_user() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $user_id = isset($_POST['user_id']) && !empty($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $display_name = sanitize_text_field($_POST['display_name']);
    $email = sanitize_email($_POST['email']);
    $telefone = isset($_POST['telefone']) ? sanitize_text_field($_POST['telefone']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $cursos = isset($_POST['cursos']) ? array_map('intval', $_POST['cursos']) : array();
    $acesso_tipo = isset($_POST['acesso_tipo']) ? sanitize_text_field($_POST['acesso_tipo']) : 'dias';
    $dias = isset($_POST['dias']) ? intval($_POST['dias']) : 365;
    
    if (empty($display_name) || empty($email)) {
        wp_send_json_error(array('message' => 'Nome e email são obrigatórios'));
    }
    
    if (!is_email($email)) {
        wp_send_json_error(array('message' => 'Email inválido'));
    }
    
    if ($user_id) {
        // Atualizar usuário existente
        $existing = get_user_by('email', $email);
        if ($existing && $existing->ID != $user_id) {
            wp_send_json_error(array('message' => 'Este email já está em uso'));
        }
        
        wp_update_user(array(
            'ID' => $user_id,
            'display_name' => $display_name,
            'user_email' => $email
        ));
        
        // Salvar telefone
        update_user_meta($user_id, '_raz_telefone', $telefone);
        
        if (!empty($password) && strlen($password) >= 6) {
            wp_set_password($password, $user_id);
        }
    } else {
        // Criar novo usuário
        if (email_exists($email)) {
            wp_send_json_error(array('message' => 'Este email já está cadastrado'));
        }
        
        $username = sanitize_user(explode('@', $email)[0]);
        $original = $username;
        $counter = 1;
        while (username_exists($username)) {
            $username = $original . $counter;
            $counter++;
        }
        
        if (empty($password)) {
            $password = wp_generate_password(12, false);
        } elseif (strlen($password) < 6) {
            wp_send_json_error(array('message' => 'Senha deve ter pelo menos 6 caracteres'));
        }
        
        $user_id = wp_create_user($username, $password, $email);
        
        if (is_wp_error($user_id)) {
            wp_send_json_error(array('message' => $user_id->get_error_message()));
        }
        
        wp_update_user(array(
            'ID' => $user_id,
            'display_name' => $display_name,
            'first_name' => explode(' ', $display_name)[0]
        ));
        
        // Salvar telefone
        update_user_meta($user_id, '_raz_telefone', $telefone);
        
        // Enviar email com dados de acesso
        $subject = 'Seus dados de acesso - ' . get_bloginfo('name');
        $message = "Olá {$display_name},\n\n";
        $message .= "Sua conta foi criada!\n\n";
        $message .= "Email: {$email}\n";
        $message .= "Senha: {$password}\n\n";
        $message .= "Acesse: " . home_url('/entrar') . "\n\n";
        $message .= get_bloginfo('name');
        
        wp_mail($email, $subject, $message);
    }
    
    // Remover acessos antigos
    global $wpdb;
    $wpdb->query($wpdb->prepare(
        "DELETE FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key LIKE '_raz_curso_acesso_%%'",
        $user_id
    ));
    
    // Adicionar novos acessos
    foreach ($cursos as $curso_id) {
        $acesso_data = array(
            'inicio' => current_time('mysql'),
            'vitalicio' => ($acesso_tipo === 'vitalicio')
        );
        
        if ($acesso_tipo === 'dias' && $dias > 0) {
            $acesso_data['expiracao'] = date('Y-m-d', strtotime('+' . $dias . ' days'));
        }
        
        update_user_meta($user_id, '_raz_curso_acesso_' . $curso_id, $acesso_data);
    }
    
    wp_send_json_success(array('user_id' => $user_id));
}
add_action('wp_ajax_raz_save_user', 'raz_lms_ajax_save_user');

/**
 * AJAX: Excluir usuário
 */
function raz_lms_ajax_delete_user() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $user_id = intval($_POST['user_id']);
    
    if ($user_id == get_current_user_id()) {
        wp_send_json_error(array('message' => 'Você não pode excluir a si mesmo'));
    }
    
    $user = get_userdata($user_id);
    if (!$user) {
        wp_send_json_error(array('message' => 'Usuário não encontrado'));
    }
    
    // Não permitir excluir admins
    if (user_can($user_id, 'manage_options')) {
        wp_send_json_error(array('message' => 'Não é possível excluir administradores'));
    }
    
    require_once(ABSPATH . 'wp-admin/includes/user.php');
    wp_delete_user($user_id);
    
    wp_send_json_success();
}
add_action('wp_ajax_raz_delete_user', 'raz_lms_ajax_delete_user');


/**
 * AJAX: Obter cursos do usuário com detalhes
 */
function raz_lms_ajax_get_user_cursos() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $user_id = intval($_GET['user_id']);
    $cursos_data = array();
    
    global $wpdb;
    $metas = $wpdb->get_results($wpdb->prepare(
        "SELECT meta_key, meta_value FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key LIKE '_raz_curso_acesso_%%'",
        $user_id
    ));
    
    foreach ($metas as $meta) {
        $curso_id = intval(str_replace('_raz_curso_acesso_', '', $meta->meta_key));
        $curso = get_post($curso_id);
        if (!$curso) continue;
        
        $acesso = maybe_unserialize($meta->meta_value);
        $vitalicio = isset($acesso['vitalicio']) && $acesso['vitalicio'];
        $expiracao = isset($acesso['expiracao']) ? $acesso['expiracao'] : null;
        $expirado = $expiracao && !$vitalicio && strtotime($expiracao) < time();
        
        $cursos_data[] = array(
            'id' => $curso_id,
            'nome' => $curso->post_title,
            'vitalicio' => $vitalicio,
            'expiracao' => $expiracao ? date_i18n('d/m/Y', strtotime($expiracao)) : null,
            'expirado' => $expirado,
            'origem' => isset($acesso['origem']) ? $acesso['origem'] : 'manual'
        );
    }
    
    wp_send_json_success($cursos_data);
}
add_action('wp_ajax_raz_get_user_cursos', 'raz_lms_ajax_get_user_cursos');
