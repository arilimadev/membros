<?php
/**
 * Admin Functions
 * @package RazMidiasLMS
 */

defined('ABSPATH') || exit;

// Menu de administração
function raz_lms_admin_menu() {
    add_menu_page('Gestão LMS', 'Gestão LMS', 'manage_options', 'raz-lms-gestao', 'raz_lms_admin_dashboard', 'dashicons-groups', 6);
    add_submenu_page('raz-lms-gestao', 'Dashboard', 'Dashboard', 'manage_options', 'raz-lms-gestao', 'raz_lms_admin_dashboard');
    add_submenu_page('raz-lms-gestao', 'Alunos', 'Alunos', 'manage_options', 'raz-lms-alunos', 'raz_lms_admin_alunos');
    add_submenu_page('raz-lms-gestao', 'Acessos', 'Acessos', 'manage_options', 'raz-lms-acessos', 'raz_lms_admin_acessos');
    add_submenu_page('raz-lms-gestao', 'Configurações', 'Configurações', 'manage_options', 'raz-lms-config', 'raz_lms_admin_config');
}
add_action('admin_menu', 'raz_lms_admin_menu');

// Dashboard
function raz_lms_admin_dashboard() {
    $total_cursos = wp_count_posts('curso')->publish;
    $total_modulos = wp_count_posts('modulo')->publish;
    $total_aulas = wp_count_posts('aula')->publish;
    $total_alunos = count_users()['total_users'];
    ?>
    <div class="wrap">
        <h1>Dashboard LMS</h1>
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px;margin-top:20px;">
            <div style="background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin:0 0 10px;font-size:14px;color:#666;">Total de Cursos</h3>
                <p style="margin:0;font-size:32px;font-weight:bold;color:#0891b2;"><?php echo $total_cursos; ?></p>
            </div>
            <div style="background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin:0 0 10px;font-size:14px;color:#666;">Total de Módulos</h3>
                <p style="margin:0;font-size:32px;font-weight:bold;color:#0891b2;"><?php echo $total_modulos; ?></p>
            </div>
            <div style="background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin:0 0 10px;font-size:14px;color:#666;">Total de Aulas</h3>
                <p style="margin:0;font-size:32px;font-weight:bold;color:#0891b2;"><?php echo $total_aulas; ?></p>
            </div>
            <div style="background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin:0 0 10px;font-size:14px;color:#666;">Total de Alunos</h3>
                <p style="margin:0;font-size:32px;font-weight:bold;color:#0891b2;"><?php echo $total_alunos; ?></p>
            </div>
        </div>
        
        <div style="margin-top:30px;">
            <h2>Ações Rápidas</h2>
            <p>
                <a href="<?php echo admin_url('post-new.php?post_type=curso'); ?>" class="button button-primary">Novo Curso</a>
                <a href="<?php echo admin_url('post-new.php?post_type=modulo'); ?>" class="button">Novo Módulo</a>
                <a href="<?php echo admin_url('post-new.php?post_type=aula'); ?>" class="button">Nova Aula</a>
                <a href="<?php echo admin_url('admin.php?page=raz-lms-alunos&action=add'); ?>" class="button">Novo Aluno</a>
            </p>
        </div>
        
        <div style="margin-top:30px;">
            <h2>Webhook Kiwify</h2>
            <p>Configure este endpoint no painel da Kiwify:</p>
            <code style="display:block;padding:15px;background:#f0f0f1;border-radius:4px;margin-top:10px;">
                <?php echo rest_url('raz-lms/v1/kiwify'); ?>
            </code>
        </div>
    </div>
    <?php
}

// Gestão de Alunos
function raz_lms_admin_alunos() {
    $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'list';
    ?>
    <div class="wrap">
        <h1>Gestão de Alunos <a href="<?php echo admin_url('admin.php?page=raz-lms-alunos&action=add'); ?>" class="page-title-action">Adicionar Novo</a></h1>
        <?php
        if ($action === 'add' || $action === 'edit') {
            raz_lms_admin_aluno_form(isset($_GET['user_id']) ? intval($_GET['user_id']) : 0);
        } else {
            raz_lms_admin_alunos_list();
        }
        ?>
    </div>
    <?php
}

function raz_lms_admin_alunos_list() {
    $users = get_users(array('orderby' => 'registered', 'order' => 'DESC'));
    ?>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Cursos</th>
                <th>Cadastro</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user) :
                $cursos = raz_lms_get_user_courses($user->ID);
            ?>
            <tr>
                <td><strong><?php echo esc_html($user->display_name); ?></strong></td>
                <td><?php echo esc_html($user->user_email); ?></td>
                <td><?php echo count($cursos); ?></td>
                <td><?php echo date_i18n(get_option('date_format'), strtotime($user->user_registered)); ?></td>
                <td>
                    <a href="<?php echo admin_url('admin.php?page=raz-lms-alunos&action=edit&user_id=' . $user->ID); ?>">Editar</a> |
                    <a href="<?php echo admin_url('admin.php?page=raz-lms-acessos&user_id=' . $user->ID); ?>">Acessos</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php
}

function raz_lms_admin_aluno_form($user_id = 0) {
    $user = $user_id ? get_userdata($user_id) : null;
    
    if (isset($_POST['raz_save_aluno'])) {
        check_admin_referer('raz_save_aluno');
        
        $email = sanitize_email($_POST['email']);
        $nome = sanitize_text_field($_POST['nome']);
        
        if ($user_id) {
            wp_update_user(array('ID' => $user_id, 'user_email' => $email, 'display_name' => $nome));
            echo '<div class="notice notice-success"><p>Aluno atualizado!</p></div>';
        } else {
            $username = sanitize_user(strtok($email, '@'));
            $password = wp_generate_password(12, false);
            $counter = 1;
            $original = $username;
            while (username_exists($username)) { $username = $original . $counter++; }
            
            $new_user_id = wp_create_user($username, $password, $email);
            if (!is_wp_error($new_user_id)) {
                wp_update_user(array('ID' => $new_user_id, 'display_name' => $nome));
                if (isset($_POST['enviar_email'])) wp_new_user_notification($new_user_id, null, 'user');
                echo '<div class="notice notice-success"><p>Aluno criado!</p></div>';
                $user_id = $new_user_id;
                $user = get_userdata($user_id);
            }
        }
    }
    ?>
    <form method="post">
        <?php wp_nonce_field('raz_save_aluno'); ?>
        <table class="form-table">
            <tr>
                <th><label for="nome">Nome</label></th>
                <td><input type="text" name="nome" class="regular-text" value="<?php echo $user ? esc_attr($user->display_name) : ''; ?>" required></td>
            </tr>
            <tr>
                <th><label for="email">Email</label></th>
                <td><input type="email" name="email" class="regular-text" value="<?php echo $user ? esc_attr($user->user_email) : ''; ?>" required></td>
            </tr>
            <?php if (!$user_id) : ?>
            <tr>
                <th></th>
                <td><label><input type="checkbox" name="enviar_email" value="1" checked> Enviar email com dados de acesso</label></td>
            </tr>
            <?php endif; ?>
        </table>
        <p class="submit">
            <button type="submit" name="raz_save_aluno" class="button button-primary"><?php echo $user_id ? 'Atualizar' : 'Criar'; ?> Aluno</button>
            <a href="<?php echo admin_url('admin.php?page=raz-lms-alunos'); ?>" class="button">Cancelar</a>
        </p>
    </form>
    
    <?php if ($user_id) : ?>
    <hr><h2>Cursos do Aluno</h2>
    <?php
    $cursos = raz_lms_get_user_courses($user_id);
    if (!empty($cursos)) : ?>
    <table class="wp-list-table widefat fixed striped">
        <thead><tr><th>Curso</th><th>Progresso</th><th>Acesso até</th></tr></thead>
        <tbody>
            <?php foreach ($cursos as $curso) :
                $expiracao = raz_lms_get_access_expiration($user_id, $curso->ID);
            ?>
            <tr>
                <td><?php echo esc_html($curso->post_title); ?></td>
                <td>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <div style="flex:1;height:8px;background:#e2e8f0;border-radius:4px;overflow:hidden;max-width:200px;">
                            <div style="width:<?php echo $curso->progresso['percent']; ?>%;height:100%;background:#0891b2;"></div>
                        </div>
                        <span><?php echo $curso->progresso['percent']; ?>%</span>
                    </div>
                </td>
                <td><?php echo $expiracao === 'vitalicio' ? '<span style="color:#10b981;">Vitalício</span>' : ($expiracao ? date_i18n(get_option('date_format'), strtotime($expiracao)) : '-'); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else : ?>
    <p>Este aluno ainda não tem cursos liberados.</p>
    <?php endif; ?>
    <?php endif;
}

// Gestão de Acessos
function raz_lms_admin_acessos() {
    $user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
    
    // Processar ações
    if (isset($_POST['raz_grant_access'])) {
        check_admin_referer('raz_manage_access');
        $grant_user_id = intval($_POST['user_id']);
        $grant_curso_id = intval($_POST['curso_id']);
        $dias = intval($_POST['dias']);
        $vitalicio = isset($_POST['vitalicio']);
        raz_lms_grant_access($grant_user_id, $grant_curso_id, $dias, $vitalicio);
        echo '<div class="notice notice-success"><p>Acesso liberado!</p></div>';
    }
    
    if (isset($_POST['raz_renew_access'])) {
        check_admin_referer('raz_manage_access');
        raz_lms_renew_access(intval($_POST['user_id']), intval($_POST['curso_id']), intval($_POST['dias']));
        echo '<div class="notice notice-success"><p>Acesso renovado!</p></div>';
    }
    
    if (isset($_GET['revoke']) && wp_verify_nonce($_GET['_wpnonce'], 'raz_revoke_access')) {
        raz_lms_revoke_access(intval($_GET['revoke_user']), intval($_GET['revoke_curso']));
        echo '<div class="notice notice-success"><p>Acesso revogado!</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>Gestão de Acessos</h1>
        
        <div class="card" style="max-width:600px;padding:20px;margin-top:20px;">
            <h2>Liberar Acesso</h2>
            <form method="post">
                <?php wp_nonce_field('raz_manage_access'); ?>
                <table class="form-table">
                    <tr>
                        <th><label>Aluno</label></th>
                        <td>
                            <select name="user_id" style="width:100%;" required>
                                <option value="">Selecione um aluno</option>
                                <?php foreach (get_users(array('orderby' => 'display_name')) as $u) : ?>
                                <option value="<?php echo $u->ID; ?>" <?php selected($user_id, $u->ID); ?>><?php echo esc_html($u->display_name . ' (' . $u->user_email . ')'); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label>Curso</label></th>
                        <td>
                            <select name="curso_id" style="width:100%;" required>
                                <option value="">Selecione um curso</option>
                                <?php foreach (get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title')) as $c) : ?>
                                <option value="<?php echo $c->ID; ?>"><?php echo esc_html($c->post_title); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label>Dias de Acesso</label></th>
                        <td><input type="number" name="dias" value="365" min="1" class="small-text"></td>
                    </tr>
                    <tr>
                        <th></th>
                        <td><label><input type="checkbox" name="vitalicio" value="1"> Acesso Vitalício</label></td>
                    </tr>
                </table>
                <p>
                    <button type="submit" name="raz_grant_access" class="button button-primary">Liberar Acesso</button>
                    <button type="submit" name="raz_renew_access" class="button">Renovar Acesso</button>
                </p>
            </form>
        </div>
        
        <h2 style="margin-top:30px;">Acessos Ativos</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead><tr><th>Aluno</th><th>Curso</th><th>Início</th><th>Expiração</th><th>Status</th><th>Ações</th></tr></thead>
            <tbody>
                <?php
                global $wpdb;
                $acessos = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_curso_acesso_%'");
                
                foreach ($acessos as $acesso) :
                    $acesso_user_id = $acesso->user_id;
                    $acesso_curso_id = str_replace('_raz_curso_acesso_', '', $acesso->meta_key);
                    $acesso_data = maybe_unserialize($acesso->meta_value);
                    $u = get_userdata($acesso_user_id);
                    $c = get_post($acesso_curso_id);
                    if (!$u || !$c) continue;
                    $has_access = raz_lms_user_has_access($acesso_user_id, $acesso_curso_id);
                ?>
                <tr>
                    <td><strong><?php echo esc_html($u->display_name); ?></strong><br><small><?php echo esc_html($u->user_email); ?></small></td>
                    <td><?php echo esc_html($c->post_title); ?></td>
                    <td><?php echo isset($acesso_data['inicio']) ? date_i18n(get_option('date_format'), strtotime($acesso_data['inicio'])) : '-'; ?></td>
                    <td><?php echo (isset($acesso_data['vitalicio']) && $acesso_data['vitalicio']) ? '<span style="color:#10b981;">Vitalício</span>' : (isset($acesso_data['expiracao']) ? date_i18n(get_option('date_format'), strtotime($acesso_data['expiracao'])) : '-'); ?></td>
                    <td><span style="color:<?php echo $has_access ? '#10b981' : '#ef4444'; ?>;font-weight:bold;">● <?php echo $has_access ? 'Ativo' : 'Expirado'; ?></span></td>
                    <td><a href="<?php echo wp_nonce_url(admin_url('admin.php?page=raz-lms-acessos&revoke=1&revoke_user=' . $acesso_user_id . '&revoke_curso=' . $acesso_curso_id), 'raz_revoke_access'); ?>" onclick="return confirm('Revogar acesso?');" style="color:#ef4444;">Revogar</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// Configurações
function raz_lms_admin_config() {
    if (isset($_POST['raz_save_config'])) {
        check_admin_referer('raz_save_config');
        update_option('raz_lms_login_redirect', esc_url_raw($_POST['login_redirect']));
        update_option('raz_lms_logout_redirect', esc_url_raw($_POST['logout_redirect']));
        update_option('raz_lms_acesso_negado_msg', sanitize_textarea_field($_POST['acesso_negado_msg']));
        update_option('raz_lms_acesso_expirado_msg', sanitize_textarea_field($_POST['acesso_expirado_msg']));
        echo '<div class="notice notice-success"><p>Configurações salvas!</p></div>';
    }
    
    $login_redirect = get_option('raz_lms_login_redirect', home_url('/cursos/'));
    $logout_redirect = get_option('raz_lms_logout_redirect', home_url());
    $acesso_negado_msg = get_option('raz_lms_acesso_negado_msg', 'Você não tem acesso a este conteúdo.');
    $acesso_expirado_msg = get_option('raz_lms_acesso_expirado_msg', 'Seu acesso a este curso expirou.');
    ?>
    <div class="wrap">
        <h1>Configurações LMS</h1>
        <form method="post">
            <?php wp_nonce_field('raz_save_config'); ?>
            <table class="form-table">
                <tr>
                    <th><label>Redirecionamento após Login</label></th>
                    <td><input type="url" name="login_redirect" class="regular-text" value="<?php echo esc_url($login_redirect); ?>"></td>
                </tr>
                <tr>
                    <th><label>Redirecionamento após Logout</label></th>
                    <td><input type="url" name="logout_redirect" class="regular-text" value="<?php echo esc_url($logout_redirect); ?>"></td>
                </tr>
                <tr>
                    <th><label>Mensagem de Acesso Negado</label></th>
                    <td><textarea name="acesso_negado_msg" rows="3" class="large-text"><?php echo esc_textarea($acesso_negado_msg); ?></textarea></td>
                </tr>
                <tr>
                    <th><label>Mensagem de Acesso Expirado</label></th>
                    <td><textarea name="acesso_expirado_msg" rows="3" class="large-text"><?php echo esc_textarea($acesso_expirado_msg); ?></textarea></td>
                </tr>
            </table>
            <p class="submit"><button type="submit" name="raz_save_config" class="button button-primary">Salvar Configurações</button></p>
        </form>
    </div>
    <?php
}
