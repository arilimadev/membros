<?php
/**
 * Ferramentas de Curso - Duplicação e Travamento
 * @package RazMidiasLMS
 */

defined('ABSPATH') || exit;

/**
 * Duplicar módulo
 */
function raz_lms_duplicate_modulo($modulo_id, $target_curso_id = null) {
    $modulo = get_post($modulo_id);
    if (!$modulo || $modulo->post_type !== 'modulo') return false;
    
    $curso_id = $target_curso_id ?: get_post_meta($modulo_id, '_raz_modulo_curso', true);
    
    // Criar novo módulo
    $new_modulo_id = wp_insert_post(array(
        'post_title' => $modulo->post_title . ' (Cópia)',
        'post_content' => $modulo->post_content,
        'post_status' => 'publish',
        'post_type' => 'modulo'
    ));
    
    if (is_wp_error($new_modulo_id)) return false;
    
    // Copiar meta dados
    update_post_meta($new_modulo_id, '_raz_modulo_curso', $curso_id);
    
    $ordem = get_post_meta($modulo_id, '_raz_modulo_ordem', true);
    update_post_meta($new_modulo_id, '_raz_modulo_ordem', intval($ordem) + 1);
    
    // Duplicar aulas do módulo
    $aulas = raz_lms_get_aulas($modulo_id);
    foreach ($aulas as $aula) {
        raz_lms_duplicate_aula($aula->ID, $new_modulo_id);
    }
    
    return $new_modulo_id;
}

/**
 * Duplicar aula
 */
function raz_lms_duplicate_aula($aula_id, $target_modulo_id = null) {
    $aula = get_post($aula_id);
    if (!$aula || $aula->post_type !== 'aula') return false;
    
    $modulo_id = $target_modulo_id ?: get_post_meta($aula_id, '_raz_aula_modulo', true);
    
    // Criar nova aula
    $new_aula_id = wp_insert_post(array(
        'post_title' => $aula->post_title . ($target_modulo_id ? '' : ' (Cópia)'),
        'post_content' => $aula->post_content,
        'post_status' => 'publish',
        'post_type' => 'aula'
    ));
    
    if (is_wp_error($new_aula_id)) return false;
    
    // Copiar meta dados
    $metas_to_copy = array(
        '_raz_aula_modulo',
        '_raz_aula_ordem',
        '_raz_aula_tipo',
        '_raz_aula_video_url',
        '_raz_aula_video_provider',
        '_raz_aula_duracao',
        '_raz_aula_materiais'
    );
    
    update_post_meta($new_aula_id, '_raz_aula_modulo', $modulo_id);
    
    foreach ($metas_to_copy as $meta_key) {
        if ($meta_key === '_raz_aula_modulo') continue;
        $value = get_post_meta($aula_id, $meta_key, true);
        if ($value) {
            update_post_meta($new_aula_id, $meta_key, $value);
        }
    }
    
    // Ajustar ordem se for cópia no mesmo módulo
    if (!$target_modulo_id) {
        $ordem = get_post_meta($aula_id, '_raz_aula_ordem', true);
        update_post_meta($new_aula_id, '_raz_aula_ordem', intval($ordem) + 1);
    }
    
    return $new_aula_id;
}

/**
 * Verificar se item está travado
 */
function raz_lms_is_locked($post_id) {
    return (bool) get_post_meta($post_id, '_raz_locked', true);
}

/**
 * Travar/destravar item
 */
function raz_lms_toggle_lock($post_id, $lock = true) {
    if ($lock) {
        update_post_meta($post_id, '_raz_locked', true);
    } else {
        delete_post_meta($post_id, '_raz_locked');
    }
    return true;
}

/**
 * AJAX: Duplicar módulo
 */
function raz_lms_ajax_duplicate_modulo() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $modulo_id = intval($_POST['modulo_id']);
    $target_curso_id = isset($_POST['target_curso_id']) ? intval($_POST['target_curso_id']) : null;
    
    $new_id = raz_lms_duplicate_modulo($modulo_id, $target_curso_id);
    
    if ($new_id) {
        wp_send_json_success(array('new_id' => $new_id));
    } else {
        wp_send_json_error(array('message' => 'Erro ao duplicar módulo'));
    }
}
add_action('wp_ajax_raz_duplicate_modulo', 'raz_lms_ajax_duplicate_modulo');

/**
 * AJAX: Duplicar aula
 */
function raz_lms_ajax_duplicate_aula() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $aula_id = intval($_POST['aula_id']);
    $target_modulo_id = isset($_POST['target_modulo_id']) ? intval($_POST['target_modulo_id']) : null;
    
    $new_id = raz_lms_duplicate_aula($aula_id, $target_modulo_id);
    
    if ($new_id) {
        wp_send_json_success(array('new_id' => $new_id));
    } else {
        wp_send_json_error(array('message' => 'Erro ao duplicar aula'));
    }
}
add_action('wp_ajax_raz_duplicate_aula', 'raz_lms_ajax_duplicate_aula');

/**
 * AJAX: Travar/Destravar item
 */
function raz_lms_ajax_toggle_lock() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $post_id = intval($_POST['post_id']);
    $lock = isset($_POST['lock']) && $_POST['lock'] === '1';
    
    raz_lms_toggle_lock($post_id, $lock);
    
    wp_send_json_success(array('locked' => $lock));
}
add_action('wp_ajax_raz_toggle_lock', 'raz_lms_ajax_toggle_lock');

/**
 * AJAX: Obter módulos de um curso (para duplicação)
 */
function raz_lms_ajax_get_curso_modulos() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error();
    }
    
    $curso_id = intval($_GET['curso_id']);
    $modulos = raz_lms_get_modulos($curso_id);
    
    $data = array();
    foreach ($modulos as $m) {
        $data[] = array(
            'id' => $m->ID,
            'title' => $m->post_title
        );
    }
    
    wp_send_json_success($data);
}
add_action('wp_ajax_raz_get_curso_modulos', 'raz_lms_ajax_get_curso_modulos');
