<?php
/**
 * Template: Acesso Bloqueado
 * @package RazMidiasLMS
 */

get_header();

$user_id = get_current_user_id();
$curso = null;

if (is_singular('aula')) {
    $curso = raz_lms_get_curso_from_aula(get_the_ID());
} elseif (is_singular('modulo')) {
    $curso_id = get_post_meta(get_the_ID(), '_raz_modulo_curso', true);
    $curso = $curso_id ? get_post($curso_id) : null;
}

// Verificar se expirou ou nunca teve acesso
$acesso = $curso ? get_user_meta($user_id, '_raz_curso_acesso_' . $curso->ID, true) : null;
$expirado = $acesso && isset($acesso['expiracao']) && strtotime($acesso['expiracao']) < time();

$mensagem_negado = get_option('raz_lms_acesso_negado_msg', 'Você não tem acesso a este conteúdo.');
$mensagem_expirado = get_option('raz_lms_acesso_expirado_msg', 'Seu acesso a este curso expirou.');
?>

<div class="raz-access-blocked">
    <div class="raz-access-blocked-icon">
        <?php if ($expirado) : ?>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <?php else : ?>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
        <?php endif; ?>
    </div>
    
    <h1 class="raz-access-blocked-title">
        <?php echo $expirado ? 'Acesso Expirado' : 'Acesso Restrito'; ?>
    </h1>
    
    <p class="raz-access-blocked-message">
        <?php echo $expirado ? esc_html($mensagem_expirado) : esc_html($mensagem_negado); ?>
    </p>
    
    <?php if ($expirado && $curso) : ?>
    <p class="raz-access-blocked-message" style="font-size:.875rem;">
        Seu acesso ao curso <strong><?php echo esc_html($curso->post_title); ?></strong> expirou em <?php echo date_i18n(get_option('date_format'), strtotime($acesso['expiracao'])); ?>.
    </p>
    <?php endif; ?>
    
    <div style="display:flex;gap:1rem;flex-wrap:wrap;justify-content:center;">
        <?php if ($curso) : ?>
        <a href="<?php echo get_permalink($curso->ID); ?>" class="raz-access-blocked-btn" style="background:var(--text-secondary);">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
            Ver Curso
        </a>
        <?php endif; ?>
        
        <a href="<?php echo home_url('/cursos/'); ?>" class="raz-access-blocked-btn">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            Ver Todos os Cursos
        </a>
    </div>
</div>

<?php get_footer(); ?>
