<?php
/**
 * Admin: Avaliações das Aulas
 */
global $wpdb;

$curso_filter = isset($_GET['curso']) ? intval($_GET['curso']) : 0;
$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title'));

// Buscar todas as avaliações
$ratings = array();
$meta_rows = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_lesson_rating_%'");

foreach ($meta_rows as $row) {
    $aula_id = str_replace('_raz_lesson_rating_', '', $row->meta_key);
    $aula = get_post($aula_id);
    if (!$aula) continue;
    
    $modulo = raz_lms_get_modulo_from_aula($aula_id);
    $curso = raz_lms_get_curso_from_aula($aula_id);
    
    if (!$curso) continue;
    if ($curso_filter && $curso->ID != $curso_filter) continue;
    
    $user = get_userdata($row->user_id);
    
    $ratings[] = array(
        'aula' => $aula,
        'modulo' => $modulo,
        'curso' => $curso,
        'user' => $user,
        'rating' => intval($row->meta_value)
    );
}

// Ordenar por rating (menores primeiro)
usort($ratings, function($a, $b) { return $a['rating'] - $b['rating']; });

// Estatísticas por aula
$stats = array();
foreach ($ratings as $r) {
    $aid = $r['aula']->ID;
    if (!isset($stats[$aid])) {
        $stats[$aid] = array('aula' => $r['aula'], 'curso' => $r['curso'], 'total' => 0, 'sum' => 0);
    }
    $stats[$aid]['total']++;
    $stats[$aid]['sum'] += $r['rating'];
}
foreach ($stats as $k => $s) {
    $stats[$k]['avg'] = $s['total'] > 0 ? round($s['sum'] / $s['total'], 1) : 0;
}
usort($stats, function($a, $b) { return $a['avg'] - $b['avg']; });
?>

<div class="admin-header">
    <h2>Avaliações das Aulas</h2>
</div>

<!-- Filtro -->
<div style="margin-bottom:24px;display:flex;gap:12px;align-items:center;">
    <form method="get">
        <input type="hidden" name="raz_admin_page" value="avaliacoes">
        <select name="curso" onchange="this.form.submit()" style="padding:10px 16px;border:1px solid var(--border);border-radius:8px;">
            <option value="">Todos os cursos</option>
            <?php foreach ($cursos as $c) : ?>
            <option value="<?php echo $c->ID; ?>" <?php selected($curso_filter, $c->ID); ?>><?php echo esc_html($c->post_title); ?></option>
            <?php endforeach; ?>
        </select>
    </form>
    <span class="badge badge-primary"><?php echo count($ratings); ?> avaliações</span>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:32px;">
    <!-- Aulas com piores avaliações -->
    <div class="form-card">
        <h3 style="margin-bottom:16px;">⚠️ Aulas que precisam de atenção</h3>
        <?php 
        $low_rated = array_filter($stats, function($s) { return $s['avg'] <= 3; });
        if (empty($low_rated)) : 
        ?>
        <p style="color:var(--muted);">Nenhuma aula com avaliação baixa</p>
        <?php else : ?>
        <?php foreach (array_slice($low_rated, 0, 5) as $s) : ?>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 0;border-bottom:1px solid var(--border);">
            <div>
                <div style="font-weight:500;font-size:14px;"><?php echo esc_html($s['aula']->post_title); ?></div>
                <div style="font-size:12px;color:var(--muted);"><?php echo esc_html($s['curso']->post_title); ?></div>
            </div>
            <div style="display:flex;align-items:center;gap:4px;">
                <span style="color:#fbbf24;">★</span>
                <strong style="color:var(--danger);"><?php echo $s['avg']; ?></strong>
                <span style="font-size:12px;color:var(--muted);">(<?php echo $s['total']; ?>)</span>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
    
    <!-- Aulas mais bem avaliadas -->
    <div class="form-card">
        <h3 style="margin-bottom:16px;">🏆 Aulas mais bem avaliadas</h3>
        <?php 
        $high_rated = array_filter($stats, function($s) { return $s['avg'] >= 4; });
        usort($high_rated, function($a, $b) { return $b['avg'] - $a['avg']; });
        if (empty($high_rated)) : 
        ?>
        <p style="color:var(--muted);">Nenhuma avaliação ainda</p>
        <?php else : ?>
        <?php foreach (array_slice($high_rated, 0, 5) as $s) : ?>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 0;border-bottom:1px solid var(--border);">
            <div>
                <div style="font-weight:500;font-size:14px;"><?php echo esc_html($s['aula']->post_title); ?></div>
                <div style="font-size:12px;color:var(--muted);"><?php echo esc_html($s['curso']->post_title); ?></div>
            </div>
            <div style="display:flex;align-items:center;gap:4px;">
                <span style="color:#fbbf24;">★</span>
                <strong style="color:var(--success);"><?php echo $s['avg']; ?></strong>
                <span style="font-size:12px;color:var(--muted);">(<?php echo $s['total']; ?>)</span>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Lista completa -->
<div class="form-card">
    <h3 style="margin-bottom:16px;">📋 Todas as Avaliações</h3>
    <?php 
    $per_page = 20;
    $current_page = isset($_GET['pag_av']) ? max(1, intval($_GET['pag_av'])) : 1;
    $total_ratings = count($ratings);
    $total_pages = ceil($total_ratings / $per_page);
    $offset = ($current_page - 1) * $per_page;
    $paged_ratings = array_slice($ratings, $offset, $per_page);
    
    if (empty($ratings)) : ?>
    <p style="color:var(--muted);">Nenhuma avaliação ainda</p>
    <?php else : ?>
    <table class="data-table">
        <thead>
            <tr>
                <th>Aluno</th>
                <th>Aula</th>
                <th>Curso</th>
                <th>Avaliação</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($paged_ratings as $r) : ?>
            <tr>
                <td>
                    <strong><?php echo $r['user'] ? esc_html($r['user']->display_name) : 'Usuário removido'; ?></strong>
                    <?php if ($r['user']) : ?>
                    <br><span style="font-size:12px;color:var(--muted);"><?php echo esc_html($r['user']->user_email); ?></span>
                    <?php endif; ?>
                </td>
                <td><?php echo esc_html($r['aula']->post_title); ?></td>
                <td style="color:var(--muted);"><?php echo esc_html($r['curso']->post_title); ?></td>
                <td>
                    <div style="display:flex;align-items:center;gap:2px;">
                        <?php for ($i = 1; $i <= 5; $i++) : ?>
                        <span style="color:<?php echo $i <= $r['rating'] ? '#fbbf24' : '#e2e8f0'; ?>;">★</span>
                        <?php endfor; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <?php if ($total_pages > 1) : ?>
    <div class="pagination" style="margin-top:20px;">
        <?php if ($current_page > 1) : ?>
        <a href="<?php echo add_query_arg('pag_av', $current_page - 1); ?>" class="btn btn-sm btn-secondary">← Anterior</a>
        <?php endif; ?>
        <span class="pagination-info">Página <?php echo $current_page; ?> de <?php echo $total_pages; ?></span>
        <?php if ($current_page < $total_pages) : ?>
        <a href="<?php echo add_query_arg('pag_av', $current_page + 1); ?>" class="btn btn-sm btn-secondary">Próxima →</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    
    <?php endif; ?>
</div>
