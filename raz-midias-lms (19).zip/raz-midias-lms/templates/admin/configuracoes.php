<?php
/**
 * Admin: Configurações
 */
$login_logo = get_option('raz_lms_login_logo', '');
$login_bg_color = get_option('raz_lms_login_bg_color', '#667eea');
$login_btn_color = get_option('raz_lms_login_btn_color', '#4f46e5');

if (isset($_POST['save_config']) && wp_verify_nonce($_POST['config_nonce'], 'raz_save_config')) {
    update_option('raz_lms_login_logo', esc_url_raw($_POST['login_logo']));
    update_option('raz_lms_login_bg_color', sanitize_hex_color($_POST['login_bg_color']));
    update_option('raz_lms_login_btn_color', sanitize_hex_color($_POST['login_btn_color']));
    
    $login_logo = get_option('raz_lms_login_logo', '');
    $login_bg_color = get_option('raz_lms_login_bg_color', '#667eea');
    $login_btn_color = get_option('raz_lms_login_btn_color', '#4f46e5');
    
    echo '<div class="alert alert-success" style="margin-bottom:20px;">Configurações salvas!</div>';
}
?>

<div class="admin-header">
    <h2>Configurações</h2>
</div>

<form method="post" style="max-width:600px;">
    <?php wp_nonce_field('raz_save_config', 'config_nonce'); ?>
    
    <div class="form-card">
        <h3 style="margin-bottom:20px;">🎨 Página de Login</h3>
        
        <div class="form-group">
            <label>Logo do Login</label>
            <div style="display:flex;gap:12px;align-items:center;">
                <div class="logo-preview" style="width:120px;height:60px;background:#f1f5f9;border-radius:8px;display:flex;align-items:center;justify-content:center;overflow:hidden;">
                    <?php if ($login_logo) : ?>
                    <img src="<?php echo esc_url($login_logo); ?>" style="max-height:60px;max-width:100%;">
                    <?php else : ?>
                    <span style="color:var(--muted);font-size:12px;">Sem logo</span>
                    <?php endif; ?>
                </div>
                <div>
                    <input type="hidden" name="login_logo" id="login_logo" value="<?php echo esc_url($login_logo); ?>">
                    <button type="button" class="btn btn-secondary btn-sm" onclick="selectLogo()">Selecionar</button>
                    <?php if ($login_logo) : ?>
                    <button type="button" class="btn btn-sm" style="color:var(--danger);" onclick="document.getElementById('login_logo').value='';document.querySelector('.logo-preview').innerHTML='<span style=color:var(--muted);font-size:12px;>Sem logo</span>';">Remover</button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="form-group">
            <label>Cor de Fundo</label>
            <div style="display:flex;gap:12px;align-items:center;">
                <input type="color" name="login_bg_color" id="login_bg_color" value="<?php echo esc_attr($login_bg_color); ?>" style="width:50px;height:40px;padding:0;border:none;cursor:pointer;">
                <input type="text" value="<?php echo esc_attr($login_bg_color); ?>" style="width:100px;" onchange="document.getElementById('login_bg_color').value=this.value" id="login_bg_hex">
            </div>
        </div>
        
        <div class="form-group">
            <label>Cor do Botão</label>
            <div style="display:flex;gap:12px;align-items:center;">
                <input type="color" name="login_btn_color" id="login_btn_color" value="<?php echo esc_attr($login_btn_color); ?>" style="width:50px;height:40px;padding:0;border:none;cursor:pointer;">
                <input type="text" value="<?php echo esc_attr($login_btn_color); ?>" style="width:100px;" onchange="document.getElementById('login_btn_color').value=this.value" id="login_btn_hex">
            </div>
        </div>
    </div>
    
    <button type="submit" name="save_config" class="btn btn-primary">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
        Salvar Configurações
    </button>
</form>

<script>
document.getElementById('login_bg_color').addEventListener('input', function() {
    document.getElementById('login_bg_hex').value = this.value;
});
document.getElementById('login_btn_color').addEventListener('input', function() {
    document.getElementById('login_btn_hex').value = this.value;
});

var mediaFrame = null;

function selectLogo() {
    // Verificar se wp.media está disponível
    if (typeof wp === 'undefined') {
        console.error('wp não definido');
        alert('Erro: WordPress não carregou corretamente. Recarregue a página.');
        return;
    }
    
    if (typeof wp.media === 'undefined') {
        console.error('wp.media não definido');
        alert('Erro: Biblioteca de mídia não carregada. Recarregue a página e aguarde alguns segundos.');
        return;
    }
    
    // Criar frame se não existir
    if (!mediaFrame) {
        mediaFrame = wp.media({
            title: 'Selecionar Logo',
            button: { text: 'Usar esta imagem' },
            multiple: false,
            library: { type: 'image' }
        });
        
        mediaFrame.on('select', function() {
            var att = mediaFrame.state().get('selection').first().toJSON();
            document.getElementById('login_logo').value = att.url;
            document.querySelector('.logo-preview').innerHTML = '<img src="' + att.url + '" style="max-height:60px;max-width:100%;">';
        });
    }
    
    mediaFrame.open();
}

// Debug: verificar quando wp.media fica disponível
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, wp:', typeof wp, 'wp.media:', typeof wp !== 'undefined' ? typeof wp.media : 'N/A');
});
</script>
