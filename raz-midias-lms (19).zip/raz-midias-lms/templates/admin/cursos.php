<?php
/**
 * Admin: Lista de Cursos - Estilo Cards
 */
$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'date', 'order' => 'DESC'));
global $wpdb;
?>

<div class="admin-header">
    <h2>Cursos</h2>
    <a href="<?php echo home_url('/gestao-cursos/curso-editar'); ?>" class="btn btn-primary">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Novo Curso
    </a>
</div>

<?php if (empty($cursos)) : ?>
<div class="empty-state">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
    <h3>Nenhum curso cadastrado</h3>
    <p>Comece criando seu primeiro curso</p>
    <a href="<?php echo home_url('/gestao-cursos/curso-editar'); ?>" class="btn btn-primary" style="margin-top:16px;">Criar Curso</a>
</div>
<?php else : ?>
<div class="courses-grid">
    <?php foreach ($cursos as $curso) :
        $modulos = raz_lms_get_modulos($curso->ID);
        $total_aulas = raz_lms_count_aulas($curso->ID);
        $thumb = get_the_post_thumbnail_url($curso->ID, 'medium');
        $alunos_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s",
            '_raz_curso_acesso_' . $curso->ID
        ));
    ?>
    <div class="course-card">
        <div class="course-card-image">
            <?php if ($thumb) : ?>
            <img src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr($curso->post_title); ?>">
            <?php endif; ?>
        </div>
        <div class="course-card-body">
            <h3 class="course-card-title"><?php echo esc_html($curso->post_title); ?></h3>
            <p class="course-card-meta"><?php echo count($modulos); ?> módulos • <?php echo $total_aulas; ?> aulas • <?php echo $alunos_count; ?> alunos</p>
            <div class="course-card-actions">
                <a href="<?php echo home_url('/gestao-cursos/curso-editar/' . $curso->ID); ?>" class="course-card-btn">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                    Editar
                </a>
                <a href="<?php echo get_permalink($curso->ID); ?>" class="course-card-btn secondary" target="_blank">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                    Ver
                </a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
