<?php
/**
 * Admin: Editar Aula com Editor Rico Avançado - Corrigido
 */
$aula_id = $item_id;
$aula = $aula_id ? get_post($aula_id) : null;
$modulo_id = $aula_id ? get_post_meta($aula_id, '_raz_aula_modulo', true) : (isset($_GET['modulo']) ? intval($_GET['modulo']) : 0);
$curso_id = isset($_GET['curso']) ? intval($_GET['curso']) : 0;

if (!$curso_id && $modulo_id) {
    $curso_id = get_post_meta($modulo_id, '_raz_modulo_curso', true);
}

$modulo = $modulo_id ? get_post($modulo_id) : null;
$curso = $curso_id ? get_post($curso_id) : null;

$video_url = $aula_id ? get_post_meta($aula_id, '_raz_aula_video_url', true) : '';
$video_provider = $aula_id ? get_post_meta($aula_id, '_raz_aula_video_provider', true) : '';
$ordem = $aula_id ? get_post_meta($aula_id, '_raz_aula_ordem', true) : 0;
$materiais = $aula_id ? get_post_meta($aula_id, '_raz_aula_materiais', true) : array();
if (!is_array($materiais)) $materiais = array();

wp_enqueue_media();
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $aula_id ? 'Editar Aula' : 'Nova Aula'; ?> - <?php bloginfo('name'); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <?php wp_head(); ?>
    <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    :root { --primary: #6366f1; --primary-dark: #4f46e5; --bg: #f8fafc; --card: #fff; --border: #e2e8f0; --text: #1e293b; --muted: #64748b; --success: #10b981; --danger: #ef4444; }
    body { font-family: 'Inter', -apple-system, sans-serif; background: var(--bg); color: var(--text); }
    
    .page-header { background: var(--card); border-bottom: 1px solid var(--border); padding: 16px 32px; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 100; }
    .page-header h1 { font-size: 18px; font-weight: 600; }
    .page-header .back-link { color: var(--muted); text-decoration: none; font-size: 14px; margin-bottom: 4px; display: block; }
    .page-header .back-link:hover { color: var(--primary); }
    
    .page-content { max-width: 900px; margin: 0 auto; padding: 32px; }
    
    .form-card { background: var(--card); border-radius: 12px; padding: 24px; margin-bottom: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
    .form-card h3 { font-size: 16px; font-weight: 600; margin-bottom: 16px; }
    .form-group { margin-bottom: 20px; }
    .form-group label { display: block; font-size: 14px; font-weight: 500; margin-bottom: 8px; }
    .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 12px 16px; border: 1px solid var(--border); border-radius: 8px; font-size: 15px; font-family: inherit; }
    .form-group input:focus, .form-group select:focus { outline: none; border-color: var(--primary); }
    .form-hint { font-size: 13px; color: var(--muted); margin-top: 4px; }
    .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    
    .btn { display: inline-flex; align-items: center; gap: 8px; padding: 12px 24px; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; border: none; text-decoration: none; transition: all 0.15s; }
    .btn-primary { background: var(--primary); color: #fff; }
    .btn-primary:hover { background: var(--primary-dark); }
    .btn-secondary { background: var(--bg); color: var(--text); border: 1px solid var(--border); }
    .btn-danger { background: var(--danger); color: #fff; }
    .btn-sm { padding: 8px 12px; font-size: 13px; }
    
    .autosave-indicator { display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 6px; font-size: 13px; background: var(--bg); color: var(--muted); }
    .autosave-indicator.saving { background: #fef3c7; color: #b45309; }
    .autosave-indicator.saved { background: #d1fae5; color: #059669; }
    
    /* Editor */
    .editor-container { border: 1px solid var(--border); border-radius: 12px; overflow: hidden; background: #fff; }
    .editor-toolbar { background: #f8fafc; border-bottom: 1px solid var(--border); padding: 8px 12px; display: flex; flex-wrap: wrap; gap: 4px; align-items: center; }
    .editor-btn { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; border: none; background: transparent; cursor: pointer; border-radius: 6px; color: var(--text); font-size: 14px; }
    .editor-btn:hover { background: var(--border); }
    .editor-separator { width: 1px; height: 24px; background: var(--border); margin: 0 6px; }
    .editor-select { padding: 6px 10px; border: 1px solid var(--border); border-radius: 6px; font-size: 13px; background: #fff; }
    .color-picker { width: 28px; height: 28px; padding: 0; border: 1px solid var(--border); border-radius: 4px; cursor: pointer; }
    
    .editor-area { min-height: 450px; padding: 24px; outline: none; font-size: 16px; line-height: 1.8; overflow-y: auto; }
    .editor-area:focus { background: #fff; }
    .editor-area img, .editor-area video { max-width: 100%; border-radius: 8px; margin: 12px 0; display: block; cursor: pointer; }
    .editor-area img:hover, .editor-area video:hover { outline: 2px solid var(--primary); }
    .editor-area audio { width: 100%; margin: 12px 0; display: block; }
    .editor-area a { color: var(--primary); }
    .editor-area pre { background: #1e293b; color: #e2e8f0; padding: 16px; border-radius: 8px; overflow-x: auto; font-family: monospace; font-size: 14px; }
    .editor-area blockquote { border-left: 4px solid var(--primary); padding-left: 16px; margin: 16px 0; color: var(--muted); }
    
    .editor-collapse { border: 1px solid var(--border); border-radius: 8px; margin: 12px 0; }
    .editor-collapse-header { padding: 12px 16px; background: #f8fafc; cursor: pointer; display: flex; align-items: center; gap: 8px; font-weight: 500; }
    .editor-collapse-header::before { content: '▶'; font-size: 10px; transition: transform 0.2s; }
    .editor-collapse.open .editor-collapse-header::before { transform: rotate(90deg); }
    .editor-collapse-content { padding: 16px; display: none; border-top: 1px solid var(--border); min-height: 50px; }
    .editor-collapse.open .editor-collapse-content { display: block; }
    
    .materiais-list { display: flex; flex-direction: column; gap: 8px; margin-top: 12px; }
    .material-item { display: flex; align-items: center; gap: 12px; padding: 12px 16px; background: var(--bg); border-radius: 8px; }
    .material-item svg { color: var(--primary); flex-shrink: 0; }
    .material-info { flex: 1; display: flex; flex-direction: column; gap: 4px; }
    .material-name-input { border: none; background: transparent; font-size: 14px; font-weight: 500; padding: 4px 0; width: 100%; }
    .material-name-input:focus { outline: none; border-bottom: 1px solid var(--primary); }
    .material-type { font-size: 12px; color: var(--muted); }
    
    .toast { position: fixed; bottom: 24px; right: 24px; background: var(--text); color: #fff; padding: 16px 24px; border-radius: 10px; transform: translateY(100px); opacity: 0; transition: all 0.3s; z-index: 2000; }
    .toast.show { transform: translateY(0); opacity: 1; }
    .toast.success { background: var(--success); }
    
    .module-badge { background: var(--bg); padding: 12px 20px; border-radius: 8px; display: inline-flex; align-items: center; gap: 8px; margin-bottom: 24px; }
    
    .spin { animation: spin 1s linear infinite; }
    @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
    </style>
</head>
<body>

<header class="page-header">
    <div>
        <a href="<?php echo home_url('/gestao-cursos/curso-editar/' . $curso_id . '?tab=conteudo'); ?>" class="back-link">
            ← Voltar para <?php echo $curso ? esc_html($curso->post_title) : 'Curso'; ?>
        </a>
        <h1><?php echo $aula_id ? 'Editar Aula' : 'Nova Aula'; ?></h1>
    </div>
    <div style="display:flex;align-items:center;gap:12px;">
        <span class="autosave-indicator" id="autosave-status">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><circle cx="12" cy="12" r="10"/></svg>
            <span>Não salvo</span>
        </span>
    </div>
</header>

<div class="page-content">
    <?php if ($modulo) : ?>
    <div class="module-badge">
        <svg viewBox="0 0 24 24" fill="none" stroke="var(--muted)" stroke-width="2" width="18" height="18"><path d="M3 3h7v7H3zM14 3h7v7h-7zM14 14h7v7h-7zM3 14h7v7H3z"/></svg>
        <span style="color:var(--muted);">Módulo:</span>
        <strong><?php echo esc_html($modulo->post_title); ?></strong>
    </div>
    <?php endif; ?>
    
    <form id="form-aula">
        <input type="hidden" name="aula_id" id="aula_id" value="<?php echo $aula_id; ?>">
        <input type="hidden" name="modulo_id" value="<?php echo $modulo_id; ?>">
        <input type="hidden" name="ordem" value="<?php echo $ordem; ?>">
        
        <div class="form-card">
            <div class="form-group">
                <label>Título da Aula *</label>
                <input type="text" name="titulo" id="aula_titulo" value="<?php echo $aula ? esc_attr($aula->post_title) : ''; ?>" required style="font-size:18px;padding:16px;">
            </div>
        </div>
        
        <div class="form-card">
            <h3>🎬 Vídeo da Aula (opcional)</h3>
            <div class="form-row">
                <div class="form-group">
                    <label>Provedor de Vídeo</label>
                    <select name="video_provider" id="video_provider">
                        <option value="">Sem vídeo</option>
                        <option value="youtube" <?php selected($video_provider, 'youtube'); ?>>YouTube</option>
                        <option value="vimeo" <?php selected($video_provider, 'vimeo'); ?>>Vimeo</option>
                        <option value="panda" <?php selected($video_provider, 'panda'); ?>>Panda Video</option>
                        <option value="bunny" <?php selected($video_provider, 'bunny'); ?>>Bunny Stream</option>
                        <option value="custom" <?php selected($video_provider, 'custom'); ?>>URL Direta (MP4)</option>
                    </select>
                </div>
                <div class="form-group" id="video-url-group" style="<?php echo $video_provider ? '' : 'display:none;'; ?>">
                    <label>URL do Vídeo</label>
                    <div style="display:flex;gap:8px;">
                        <input type="url" name="video_url" id="video_url" value="<?php echo esc_url($video_url); ?>" placeholder="https://..." style="flex:1;">
                        <button type="button" class="btn btn-secondary" id="btn-select-video" style="display:none;" onclick="selectVideoFromLibrary()">Biblioteca</button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="form-card">
            <h3>📝 Conteúdo da Aula</h3>
            <p class="form-hint" style="margin-bottom:16px;">Editor com suporte a texto, imagens, áudios, vídeos, código e collapse.</p>
            
            <div class="editor-container">
                <div class="editor-toolbar">
                    <select class="editor-select" onchange="if(this.value){execCmd('formatBlock',this.value);this.value='';}">
                        <option value="">Formato</option>
                        <option value="h1">Título 1</option>
                        <option value="h2">Título 2</option>
                        <option value="h3">Título 3</option>
                        <option value="p">Parágrafo</option>
                        <option value="pre">Código</option>
                    </select>
                    <div class="editor-separator"></div>
                    <button type="button" class="editor-btn" onclick="execCmd('bold')" title="Negrito"><b>B</b></button>
                    <button type="button" class="editor-btn" onclick="execCmd('italic')" title="Itálico"><i>I</i></button>
                    <button type="button" class="editor-btn" onclick="execCmd('underline')" title="Sublinhado"><u>U</u></button>
                    <button type="button" class="editor-btn" onclick="execCmd('strikeThrough')" title="Riscado"><s>S</s></button>
                    <div class="editor-separator"></div>
                    <input type="color" class="color-picker" id="textColor" value="#000000" oninput="execCmd('foreColor',this.value)" title="Cor do texto">
                    <input type="color" class="color-picker" id="bgColor" value="#ffff00" oninput="execCmd('hiliteColor',this.value)" title="Cor de fundo">
                    <div class="editor-separator"></div>
                    <button type="button" class="editor-btn" onclick="execCmd('justifyLeft')" title="Esquerda">☰</button>
                    <button type="button" class="editor-btn" onclick="execCmd('justifyCenter')" title="Centro">≡</button>
                    <button type="button" class="editor-btn" onclick="execCmd('justifyRight')" title="Direita">☰</button>
                    <div class="editor-separator"></div>
                    <button type="button" class="editor-btn" onclick="execCmd('insertUnorderedList')" title="Lista">•</button>
                    <button type="button" class="editor-btn" onclick="execCmd('insertOrderedList')" title="Numerada">1.</button>
                    <div class="editor-separator"></div>
                    <button type="button" class="editor-btn" onclick="insertLink()" title="Link">🔗</button>
                    <button type="button" class="editor-btn" onclick="insertImage()" title="Imagem">🖼</button>
                    <button type="button" class="editor-btn" onclick="insertAudio()" title="Áudio">🔊</button>
                    <button type="button" class="editor-btn" onclick="insertVideo()" title="Vídeo">🎬</button>
                    <button type="button" class="editor-btn" onclick="insertCode()" title="Código">&lt;/&gt;</button>
                    <button type="button" class="editor-btn" onclick="insertCollapse()" title="Acordeão">📂</button>
                    <button type="button" class="editor-btn" onclick="insertHTML()" title="HTML">HTML</button>
                    <div class="editor-separator"></div>
                    <button type="button" class="editor-btn" onclick="execCmd('removeFormat')" title="Limpar">✖</button>
                </div>
                <div class="editor-area" id="editor" contenteditable="true"><?php echo $aula ? $aula->post_content : '<p>Digite o conteúdo aqui...</p>'; ?></div>
            </div>
            <input type="hidden" name="conteudo" id="conteudo">
        </div>
        
        <div class="form-card">
            <h3>📎 Materiais Complementares</h3>
            <p class="form-hint" style="margin-bottom:16px;">Adicione arquivos e personalize o nome exibido.</p>
            
            <button type="button" class="btn btn-secondary" onclick="addMaterial()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                Adicionar Material
            </button>
            
            <div class="materiais-list" id="materiais-list">
                <?php foreach ($materiais as $index => $mat) : ?>
                <div class="material-item" data-index="<?php echo $index; ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                    <div class="material-info">
                        <input type="text" class="material-name-input" name="materiais[<?php echo $index; ?>][display_name]" value="<?php echo esc_attr($mat['display_name'] ?? $mat['nome']); ?>" placeholder="Nome para exibição">
                        <span class="material-type"><?php echo esc_html($mat['tipo']); ?> - <?php echo esc_html($mat['nome']); ?></span>
                        <input type="hidden" name="materiais[<?php echo $index; ?>][id]" value="<?php echo intval($mat['id']); ?>">
                        <input type="hidden" name="materiais[<?php echo $index; ?>][nome]" value="<?php echo esc_attr($mat['nome']); ?>">
                        <input type="hidden" name="materiais[<?php echo $index; ?>][url]" value="<?php echo esc_url($mat['url']); ?>">
                        <input type="hidden" name="materiais[<?php echo $index; ?>][tipo]" value="<?php echo esc_attr($mat['tipo']); ?>">
                    </div>
                    <button type="button" class="btn btn-sm btn-danger" onclick="removeMaterial(this)">×</button>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div style="display:flex;gap:16px;align-items:center;">
            <button type="submit" class="btn btn-primary" style="padding:14px 32px;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                Salvar Aula
            </button>
            <a href="<?php echo home_url('/gestao-cursos/curso-editar/' . $curso_id . '?tab=conteudo'); ?>" class="btn btn-secondary">Cancelar</a>
        </div>
    </form>
</div>

<div class="toast" id="toast"></div>

<?php wp_footer(); ?>

<script>
var razAdmin = {
    ajaxurl: '<?php echo admin_url('admin-ajax.php'); ?>',
    nonce: '<?php echo wp_create_nonce('raz_admin_nonce'); ?>',
    homeUrl: '<?php echo home_url(); ?>',
    cursoId: <?php echo $curso_id ?: 0; ?>
};

var materialIndex = <?php echo count($materiais); ?>;
var autosaveTimer = null;
var hasChanges = false;
var isSaving = false;

function showToast(msg, type) {
    var t = document.getElementById('toast');
    t.textContent = msg;
    t.className = 'toast ' + (type || '') + ' show';
    setTimeout(function() { t.classList.remove('show'); }, 3000);
}

function execCmd(cmd, val) {
    document.execCommand(cmd, false, val || null);
    document.getElementById('editor').focus();
    markChanged();
}

function insertLink() {
    var url = prompt('URL do link:');
    if (url) execCmd('createLink', url);
}

function insertImage() {
    var frame = wp.media({ title: 'Inserir Imagem', button: { text: 'Inserir' }, multiple: false, library: { type: 'image' } });
    frame.on('select', function() {
        var att = frame.state().get('selection').first().toJSON();
        execCmd('insertHTML', '<p><img src="' + att.url + '" alt="" style="max-width:100%;cursor:pointer;" onclick="resizeMedia(this)"></p><p>&nbsp;</p>');
    });
    frame.open();
}

function insertAudio() {
    var frame = wp.media({ title: 'Inserir Áudio', button: { text: 'Inserir' }, multiple: false, library: { type: 'audio' } });
    frame.on('select', function() {
        var att = frame.state().get('selection').first().toJSON();
        execCmd('insertHTML', '<p><audio src="' + att.url + '" controls style="width:100%;"></audio></p><p>&nbsp;</p>');
    });
    frame.open();
}

function insertVideo() {
    var frame = wp.media({ title: 'Inserir Vídeo', button: { text: 'Inserir' }, multiple: false, library: { type: 'video' } });
    frame.on('select', function() {
        var att = frame.state().get('selection').first().toJSON();
        execCmd('insertHTML', '<p><video src="' + att.url + '" controls style="max-width:100%;"></video></p><p>&nbsp;</p>');
    });
    frame.open();
}

function insertCode() {
    var code = prompt('Cole o código:');
    if (code) execCmd('insertHTML', '<pre><code>' + code.replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</code></pre><p>&nbsp;</p>');
}

function insertCollapse() {
    var title = prompt('Título do acordeão:');
    if (title) {
        var html = '<div class="editor-collapse"><div class="editor-collapse-header" onclick="this.parentElement.classList.toggle(\'open\')">' + title + '</div><div class="editor-collapse-content">Conteúdo aqui...</div></div><p>&nbsp;</p>';
        execCmd('insertHTML', html);
    }
}

function insertHTML() {
    var html = prompt('Cole o HTML:');
    if (html) execCmd('insertHTML', html + '<p>&nbsp;</p>');
}

function resizeMedia(el) {
    var w = prompt('Nova largura (ex: 300px ou 50%):', el.style.width || '100%');
    if (w) { el.style.width = w; el.style.height = 'auto'; markChanged(); }
}

document.getElementById('video_provider').addEventListener('change', function() {
    var g = document.getElementById('video-url-group');
    var b = document.getElementById('btn-select-video');
    g.style.display = this.value ? 'block' : 'none';
    b.style.display = this.value === 'custom' ? 'flex' : 'none';
    if (!this.value) document.getElementById('video_url').value = '';
    markChanged();
});
document.getElementById('video_provider').dispatchEvent(new Event('change'));

function selectVideoFromLibrary() {
    var frame = wp.media({ title: 'Selecionar Vídeo', button: { text: 'Usar' }, multiple: false, library: { type: 'video' } });
    frame.on('select', function() {
        var att = frame.state().get('selection').first().toJSON();
        document.getElementById('video_url').value = att.url;
        markChanged();
    });
    frame.open();
}

function addMaterial() {
    var frame = wp.media({ title: 'Selecionar Material', button: { text: 'Adicionar' }, multiple: true });
    frame.on('select', function() {
        var atts = frame.state().get('selection').toJSON();
        atts.forEach(function(att) {
            var dn = att.title || att.filename.replace(/\.[^/.]+$/, '');
            var h = '<div class="material-item" data-index="' + materialIndex + '">';
            h += '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>';
            h += '<div class="material-info">';
            h += '<input type="text" class="material-name-input" name="materiais[' + materialIndex + '][display_name]" value="' + dn + '" placeholder="Nome">';
            h += '<span class="material-type">' + (att.subtype || att.type) + ' - ' + att.filename + '</span>';
            h += '<input type="hidden" name="materiais[' + materialIndex + '][id]" value="' + att.id + '">';
            h += '<input type="hidden" name="materiais[' + materialIndex + '][nome]" value="' + att.filename + '">';
            h += '<input type="hidden" name="materiais[' + materialIndex + '][url]" value="' + att.url + '">';
            h += '<input type="hidden" name="materiais[' + materialIndex + '][tipo]" value="' + (att.subtype || att.type) + '">';
            h += '</div><button type="button" class="btn btn-sm btn-danger" onclick="removeMaterial(this)">×</button></div>';
            document.getElementById('materiais-list').insertAdjacentHTML('beforeend', h);
            materialIndex++;
        });
        markChanged();
    });
    frame.open();
}

function removeMaterial(btn) { btn.closest('.material-item').remove(); markChanged(); }

function markChanged() {
    hasChanges = true;
    updateStatus('unsaved');
    clearTimeout(autosaveTimer);
    autosaveTimer = setTimeout(function() { if (hasChanges && !isSaving) saveAula(true); }, 30000);
}

function updateStatus(s) {
    var el = document.getElementById('autosave-status');
    el.className = 'autosave-indicator';
    if (s === 'saving') {
        el.classList.add('saving');
        el.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" class="spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg><span>Salvando...</span>';
    } else if (s === 'saved') {
        el.classList.add('saved');
        el.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><polyline points="20 6 9 17 4 12"/></svg><span>Salvo</span>';
    } else {
        el.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><circle cx="12" cy="12" r="10"/></svg><span>Não salvo</span>';
    }
}

function saveAula(auto) {
    if (isSaving) return;
    isSaving = true;
    
    document.getElementById('conteudo').value = document.getElementById('editor').innerHTML;
    updateStatus('saving');
    
    var fd = new FormData(document.getElementById('form-aula'));
    fd.append('action', 'raz_save_aula');
    fd.append('nonce', razAdmin.nonce);
    
    fetch(razAdmin.ajaxurl, { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            isSaving = false;
            if (d.success) {
                hasChanges = false;
                updateStatus('saved');
                // Atualizar ID se era nova aula
                if (d.data.aula_id) {
                    document.getElementById('aula_id').value = d.data.aula_id;
                    history.replaceState(null, '', razAdmin.homeUrl + '/gestao-cursos/aula-editar/' + d.data.aula_id + '?curso=' + razAdmin.cursoId);
                }
                if (!auto) showToast('Aula salva!', 'success');
            } else {
                updateStatus('unsaved');
                showToast(d.data.message || 'Erro', 'error');
            }
        })
        .catch(function() { isSaving = false; updateStatus('unsaved'); });
}

document.getElementById('form-aula').onsubmit = function(e) {
    e.preventDefault();
    saveAula(false);
};

document.getElementById('editor').addEventListener('input', markChanged);
document.querySelectorAll('#form-aula input, #form-aula select').forEach(function(el) {
    el.addEventListener('change', markChanged);
    el.addEventListener('input', markChanged);
});

document.addEventListener('keydown', function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); saveAula(false); }
});

window.addEventListener('beforeunload', function(e) {
    if (hasChanges) { e.preventDefault(); e.returnValue = ''; }
});

// Collapse toggle
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('editor-collapse-header')) {
        e.target.parentElement.classList.toggle('open');
    }
});
</script>

</body>
</html>
<?php exit; ?>
rico de Versões</h3>
            <button class="aluno-modal-close" onclick="closeVersions()">&times;</button>
        </div>
        <div class="aluno-modal-body">
            <div class="versions-list" id="versions-list">
                <p style="text-align:center;color:var(--muted);">Carregando...</p>
            </div>
        </div>
    </div>
</div>

<!-- Modal Duplicar -->
<div class="aluno-modal" id="duplicate-modal">
    <div class="aluno-modal-content" style="max-width:500px;">
        <div class="aluno-modal-header">
            <h3>Duplicar Aula</h3>
            <button class="aluno-modal-close" onclick="closeDuplicate()">&times;</button>
        </div>
        <div class="aluno-modal-body">
            <div class="form-group">
                <label>Destino</label>
                <select id="dup_destino" onchange="loadDupModulos()">
                    <option value="mesmo">Mesmo módulo (criar cópia)</option>
                    <option value="outro">Outro curso/módulo</option>
                </select>
            </div>
            <div id="dup-outro" style="display:none;">
                <div class="form-group">
                    <label>Curso</label>
                    <select id="dup_curso" onchange="loadDupModulos()">
                        <?php 
                        $all_cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1));
                        foreach ($all_cursos as $c) : ?>
                        <option value="<?php echo $c->ID; ?>"><?php echo esc_html($c->post_title); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Módulo</label>
                    <select id="dup_modulo"></select>
                </div>
            </div>
        </div>
        <div class="aluno-modal-footer">
            <button class="btn btn-secondary" onclick="closeDuplicate()">Cancelar</button>
            <button class="btn btn-primary" onclick="confirmDuplicate()">Duplicar</button>
        </div>
    </div>
</div>

<!-- Modal Emoji -->
<div class="aluno-modal" id="emoji-modal" style="z-index:1100;">
    <div class="aluno-modal-content" style="max-width:350px;">
        <div class="aluno-modal-header">
            <h3>Inserir Emoji</h3>
            <button class="aluno-modal-close" onclick="closeEmoji()">&times;</button>
        </div>
        <div class="aluno-modal-body" style="display:flex;flex-wrap:wrap;gap:8px;font-size:24px;">
            <?php 
            $emojis = ['😀','😃','😄','😁','😅','😂','🤣','😊','😇','🙂','😉','😌','😍','🥰','😘','😋','😛','🤔','🤨','😐','😑','😶','🙄','😏','😣','😥','😮','🤐','😯','😪','😫','🥱','😴','😌','😛','😜','😝','🤑','🤗','🤭','🤫','🤔','🤐','🤨','😐','😑','😶','😏','😒','🙄','😬','🤥','😌','😔','😪','🤤','😷','🤒','🤕','🤢','🤮','🤧','🥵','🥶','🥴','😵','🤯','🤠','🥳','🥸','😎','🤓','🧐','😕','😟','🙁','☹️','😮','😯','😲','😳','🥺','😦','😧','😨','😰','😥','😢','😭','😱','😖','😣','😞','😓','😩','😫','🥱','😤','😡','😠','🤬','😈','👿','💀','☠️','💩','🤡','👹','👺','👻','👽','👾','🤖','😺','😸','😹','😻','😼','😽','🙀','😿','😾','🙈','🙉','🙊','💋','💌','💘','💝','💖','💗','💓','💞','💕','💟','❣️','💔','❤️','🧡','💛','💚','💙','💜','🤎','🖤','🤍','💯','💢','💥','💫','💦','💨','🕳️','💣','💬','👁️‍🗨️','🗨️','🗯️','💭','💤','👋','🤚','🖐️','✋','🖖','👌','🤌','🤏','✌️','🤞','🤟','🤘','🤙','👈','👉','👆','🖕','👇','☝️','👍','👎','✊','👊','🤛','🤜','👏','🙌','👐','🤲','🤝','🙏','✍️','💅','🤳','💪','🦾','🦿','🦵','🦶','👂','🦻','👃','🧠','🫀','🫁','🦷','🦴','👀','👁️','👅','👄','👶','🧒','👦','👧','🧑','👱','👨','🧔','👩','🧓','👴','👵','🙍','🙎','🙅','🙆','💁','🙋','🧏','🙇','🤦','🤷','👮','🕵️','💂','🥷','👷','🤴','👸','👳','👲','🧕','🤵','👰','🤰','🤱','👼','🎅','🤶','🦸','🦹','🧙','🧚','🧛','🧜','🧝','🧞','🧟','💆','💇','🚶','🧍','🧎','🏃','💃','🕺','🕴️','👯','🧖','🧗','🤸','🏌️','🏇','⛷️','🏂','🏋️','🤼','🤽','🤾','🤺','⛹️','🏊','🚣','🧘','🛀','🛌','👭','👫','👬','💏','💑','👪','👨‍👩‍👦','👨‍👩‍👧','👨‍👩‍👧‍👦','👨‍👩‍👦‍👦','👨‍👩‍👧‍👧','👨‍👦','👨‍👦‍👦','👨‍👧','👨‍👧‍👦','👨‍👧‍👧','👩‍👦','👩‍👦‍👦','👩‍👧','👩‍👧‍👦','👩‍👧‍👧','🗣️','👤','👥','🫂','👣','🐵','🐒','🦍','🦧','🐶','🐕','🦮','🐕‍🦺','🐩','🐺','🦊','🦝','🐱','🐈','🐈‍⬛','🦁','🐯','🐅','🐆','🐴','🐎','🦄','🦓','🦌','🦬','🐮','🐂','🐃','🐄','🐷','🐖','🐗','🐽','🐏','🐑','🐐','🐪','🐫','🦙','🦒','🐘','🦣','🦏','🦛','🐭','🐁','🐀','🐹','🐰','🐇','🐿️','🦫','🦔','🦇','🐻','🐻‍❄️','🐨','🐼','🦥','🦦','🦨','🦘','🦡','🐾','🦃','🐔','🐓','🐣','🐤','🐥','🐦','🐧','🕊️','🦅','🦆','🦢','🦉','🦤','🪶','🦩','🦚','🦜','🐸','🐊','🐢','🦎','🐍','🐲','🐉','🦕','🦖','🐳','🐋','🐬','🦭','🐟','🐠','🐡','🦈','🐙','🐚','🐌','🦋','🐛','🐜','🐝','🪲','🐞','🦗','🪳','🕷️','🕸️','🦂','🦟','🪰','🪱','🦠','💐','🌸','💮','🏵️','🌹','🥀','🌺','🌻','🌼','🌷','🌱','🪴','🌲','🌳','🌴','🌵','🌾','🌿','☘️','🍀','🍁','🍂','🍃','🍇','🍈','🍉','🍊','🍋','🍌','🍍','🥭','🍎','🍏','🍐','🍑','🍒','🍓','🫐','🥝','🍅','🫒','🥥','🥑','🍆','🥔','🥕','🌽','🌶️','🫑','🥒','🥬','🥦','🧄','🧅','🍄','🥜','🌰','🍞','🥐','🥖','🫓','🥨','🥯','🥞','🧇','🧀','🍖','🍗','🥩','🥓','🍔','🍟','🍕','🌭','🥪','🌮','🌯','🫔','🥙','🧆','🥚','🍳','🥘','🍲','🫕','🥣','🥗','🍿','🧈','🧂','🥫','🍱','🍘','🍙','🍚','🍛','🍜','🍝','🍠','🍢','🍣','🍤','🍥','🥮','🍡','🥟','🥠','🥡','🦀','🦞','🦐','🦑','🦪','🍦','🍧','🍨','🍩','🍪','🎂','🍰','🧁','🥧','🍫','🍬','🍭','🍮','🍯','🍼','🥛','☕','🫖','🍵','🍶','🍾','🍷','🍸','🍹','🍺','🍻','🥂','🥃','🥤','🧋','🧃','🧉','🧊','🥢','🍽️','🍴','🥄','🔪','🏺','🌍','🌎','🌏','🌐','🗺️','🧭','🏔️','⛰️','🌋','🗻','🏕️','🏖️','🏜️','🏝️','🏞️','🏟️','🏛️','🏗️','🧱','🪨','🪵','🛖','🏘️','🏚️','🏠','🏡','🏢','🏣','🏤','🏥','🏦','🏨','🏩','🏪','🏫','🏬','🏭','🏯','🏰','💒','🗼','🗽','⛪','🕌','🛕','🕍','⛩️','🕋','⛲','⛺','🌁','🌃','🏙️','🌄','🌅','🌆','🌇','🌉','♨️','🎠','🎡','🎢','💈','🎪','🚂','🚃','🚄','🚅','🚆','🚇','🚈','🚉','🚊','🚝','🚞','🚋','🚌','🚍','🚎','🚐','🚑','🚒','🚓','🚔','🚕','🚖','🚗','🚘','🚙','🛻','🚚','🚛','🚜','🏎️','🏍️','🛵','🦽','🦼','🛺','🚲','🛴','🛹','🛼','🚏','🛣️','🛤️','🛢️','⛽','🚨','🚥','🚦','🛑','🚧','⚓','⛵','🛶','🚤','🛳️','⛴️','🛥️','🚢','✈️','🛩️','🛫','🛬','🪂','💺','🚁','🚟','🚠','🚡','🛰️','🚀','🛸','🛎️','🧳','⌛','⏳','⌚','⏰','⏱️','⏲️','🕰️','🕛','🕧','🕐','🕜','🕑','🕝','🕒','🕞','🕓','🕟','🕔','🕠','🕕','🕡','🕖','🕢','🕗','🕣','🕘','🕤','🕙','🕥','🕚','🕦','🌑','🌒','🌓','🌔','🌕','🌖','🌗','🌘','🌙','🌚','🌛','🌜','🌡️','☀️','🌝','🌞','🪐','⭐','🌟','🌠','🌌','☁️','⛅','⛈️','🌤️','🌥️','🌦️','🌧️','🌨️','🌩️','🌪️','🌫️','🌬️','🌀','🌈','🌂','☂️','☔','⛱️','⚡','❄️','☃️','⛄','☄️','🔥','💧','🌊'];
            foreach (array_slice($emojis, 0, 80) as $e) : ?>
            <span style="cursor:pointer;" onclick="insertEmojiChar('<?php echo $e; ?>')"><?php echo $e; ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
var nonce = '<?php echo wp_create_nonce('raz_admin_nonce'); ?>';
var aulaId = <?php echo $aula_id ?: 0; ?>;
var moduloId = <?php echo $modulo_id; ?>;
var cursoId = <?php echo $curso_id; ?>;
var isLocked = <?php echo $is_locked ? 'true' : 'false'; ?>;
var autoSaveTimer = null;
var lastContent = '';

var editor = document.getElementById('editor');

// Comandos do editor
function execCmd(cmd, value) { document.execCommand(cmd, false, value || null); editor.focus(); }
function execFormat(tag) { if (tag) execCmd('formatBlock', '<' + tag + '>'); }
function execFont(font) { if (font) execCmd('fontName', font); }
function execFontSize(size) { if (size) execCmd('fontSize', size); }
function execColor(color) { execCmd('foreColor', color); }
function execHighlight(color) { execCmd('hiliteColor', color); }

function insertLink() {
    var url = prompt('URL do link:');
    if (url) execCmd('createLink', url);
}

function insertImage() {
    var url = prompt('URL da imagem:');
    if (url) execCmd('insertImage', url);
}

function insertTable() {
    var rows = prompt('Número de linhas:', '3');
    var cols = prompt('Número de colunas:', '3');
    if (rows && cols) {
        var table = '<table><tbody>';
        for (var i = 0; i < parseInt(rows); i++) {
            table += '<tr>';
            for (var j = 0; j < parseInt(cols); j++) {
                table += '<td>&nbsp;</td>';
            }
            table += '</tr>';
        }
        table += '</tbody></table>';
        execCmd('insertHTML', table);
    }
}

function insertHR() { execCmd('insertHTML', '<hr>'); }

function insertEmoji() { document.getElementById('emoji-modal').classList.add('open'); }
function closeEmoji() { document.getElementById('emoji-modal').classList.remove('open'); }
function insertEmojiChar(emoji) { execCmd('insertText', emoji); closeEmoji(); }

function toggleRotina() {
    document.getElementById('rotina-config').classList.toggle('open', document.getElementById('rotina_ativa').checked);
}

// Auto-save
editor.addEventListener('input', function() {
    if (autoSaveTimer) clearTimeout(autoSaveTimer);
    
    var indicator = document.getElementById('autosave-status');
    indicator.className = 'autosave-indicator';
    indicator.querySelector('span').textContent = 'Alterações não salvas';
    
    autoSaveTimer = setTimeout(function() {
        if (!aulaId) return;
        
        indicator.className = 'autosave-indicator saving';
        indicator.querySelector('span').textContent = 'Salvando...';
        
        var content = editor.innerHTML;
        var metaData = {
            video_url: document.getElementById('aula_video_url').value,
            video_provider: document.getElementById('aula_provider').value,
            duracao: document.getElementById('aula_duracao').value
        };
        
        fetch(ajaxurl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'action=raz_save_auto_draft&nonce=' + nonce + '&post_id=' + aulaId + '&content=' + encodeURIComponent(content) + '&meta_data=' + encodeURIComponent(JSON.stringify(metaData))
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) {
                indicator.className = 'autosave-indicator saved';
                indicator.querySelector('span').textContent = 'Rascunho salvo às ' + d.data.time;
            }
        });
    }, 3000);
});

function restoreDraft() {
    fetch(ajaxurl + '?action=raz_get_auto_draft&nonce=' + nonce + '&post_id=' + aulaId)
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) {
                editor.innerHTML = d.data.content;
                if (d.data.meta_data) {
                    if (d.data.meta_data.video_url) document.getElementById('aula_video_url').value = d.data.meta_data.video_url;
                    if (d.data.meta_data.video_provider) document.getElementById('aula_provider').value = d.data.meta_data.video_provider;
                    if (d.data.meta_data.duracao) document.getElementById('aula_duracao').value = d.data.meta_data.duracao;
                }
                document.getElementById('draft-alert').style.display = 'none';
            }
        });
}

function discardDraft() {
    document.getElementById('draft-alert').style.display = 'none';
}

// Preview
function showPreview() {
    document.getElementById('preview-modal').classList.add('open');
    updatePreview();
}

function closePreview() { document.getElementById('preview-modal').classList.remove('open'); }

function setPreviewSize(size) {
    document.querySelectorAll('.preview-toggle button').forEach(function(b) { b.classList.remove('active'); });
    event.target.classList.add('active');
    document.getElementById('preview-frame').className = 'preview-frame ' + size;
}

function updatePreview() {
    var content = editor.innerHTML;
    var title = document.getElementById('aula_title').value;
    var html = '<!DOCTYPE html><html><head><style>body{font-family:Inter,-apple-system,sans-serif;padding:20px;line-height:1.7;}img{max-width:100%;}table{border-collapse:collapse;width:100%;}th,td{border:1px solid #ddd;padding:8px;}</style></head><body><h1>' + title + '</h1>' + content + '</body></html>';
    var iframe = document.getElementById('preview-iframe');
    iframe.srcdoc = html;
}

// Versões
function showVersions() {
    document.getElementById('versions-modal').classList.add('open');
    loadVersions();
}

function closeVersions() { document.getElementById('versions-modal').classList.remove('open'); }

function loadVersions() {
    fetch(ajaxurl + '?action=raz_get_versions&nonce=' + nonce + '&post_id=' + aulaId)
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success && d.data.length > 0) {
                var html = '';
                d.data.forEach(function(v) {
                    html += '<div class="version-item">';
                    html += '<div class="version-info"><span class="date">' + v.date + '</span><br><span class="author">' + v.author + ' - ' + v.type + '</span></div>';
                    html += '<div><button class="btn btn-sm" onclick="viewVersion(' + v.id + ')">Ver</button> ';
                    html += '<button class="btn btn-sm btn-primary" onclick="restoreVersion(' + v.id + ')">Restaurar</button></div>';
                    html += '</div>';
                });
                document.getElementById('versions-list').innerHTML = html;
            } else {
                document.getElementById('versions-list').innerHTML = '<p style="text-align:center;color:var(--muted);">Nenhuma versão encontrada</p>';
            }
        });
}

function viewVersion(id) {
    fetch(ajaxurl + '?action=raz_view_version&nonce=' + nonce + '&version_id=' + id)
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) {
                alert('Conteúdo da versão:\n\n' + d.data.content.substring(0, 500) + '...');
            }
        });
}

function restoreVersion(id) {
    if (!confirm('Restaurar esta versão? O conteúdo atual será salvo como uma nova versão.')) return;
    
    fetch(ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=raz_restore_version&nonce=' + nonce + '&version_id=' + id
    })
    .then(function(r) { return r.json(); })
    .then(function(d) {
        if (d.success) {
            alert('Versão restaurada!');
            location.reload();
        }
    });
}

// Duplicar
function duplicateAula() {
    document.getElementById('duplicate-modal').classList.add('open');
}

function closeDuplicate() { document.getElementById('duplicate-modal').classList.remove('open'); }

document.getElementById('dup_destino').addEventListener('change', function() {
    document.getElementById('dup-outro').style.display = this.value === 'outro' ? 'block' : 'none';
    if (this.value === 'outro') loadDupModulos();
});

function loadDupModulos() {
    var cursoId = document.getElementById('dup_curso').value;
    fetch(ajaxurl + '?action=raz_get_curso_modulos&nonce=' + nonce + '&curso_id=' + cursoId)
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) {
                var html = '';
                d.data.forEach(function(m) {
                    html += '<option value="' + m.id + '">' + m.title + '</option>';
                });
                document.getElementById('dup_modulo').innerHTML = html;
            }
        });
}

function confirmDuplicate() {
    var destino = document.getElementById('dup_destino').value;
    var targetModulo = destino === 'outro' ? document.getElementById('dup_modulo').value : null;
    
    fetch(ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=raz_duplicate_aula&nonce=' + nonce + '&aula_id=' + aulaId + (targetModulo ? '&target_modulo_id=' + targetModulo : '')
    })
    .then(function(r) { return r.json(); })
    .then(function(d) {
        if (d.success) {
            alert('Aula duplicada com sucesso!');
            closeDuplicate();
        } else {
            alert('Erro: ' + (d.data ? d.data.message : 'Desconhecido'));
        }
    });
}

// Travar/Destravar
function toggleLock() {
    var newLock = !isLocked;
    
    fetch(ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=raz_toggle_lock&nonce=' + nonce + '&post_id=' + aulaId + '&lock=' + (newLock ? '1' : '0')
    })
    .then(function(r) { return r.json(); })
    .then(function(d) {
        if (d.success) {
            isLocked = newLock;
            location.reload();
        }
    });
}

// Materiais
function addMaterial() {
    if (typeof wp !== 'undefined' && wp.media) {
        var frame = wp.media({ multiple: false });
        frame.on('select', function() {
            var attachment = frame.state().get('selection').first().toJSON();
            var html = '<div class="material-item" style="display:flex;gap:8px;margin-bottom:8px;">';
            html += '<input type="text" value="' + attachment.filename + '" placeholder="Nome" style="flex:1;">';
            html += '<input type="hidden" value="' + attachment.url + '">';
            html += '<button type="button" class="btn btn-sm" style="color:var(--danger);" onclick="this.parentElement.remove()">×</button>';
            html += '</div>';
            document.getElementById('materiais-list').insertAdjacentHTML('beforeend', html);
        });
        frame.open();
    } else {
        var url = prompt('URL do arquivo:');
        if (url) {
            var nome = prompt('Nome do material:');
            var html = '<div class="material-item" style="display:flex;gap:8px;margin-bottom:8px;">';
            html += '<input type="text" value="' + (nome || 'Material') + '" placeholder="Nome" style="flex:1;">';
            html += '<input type="hidden" value="' + url + '">';
            html += '<button type="button" class="btn btn-sm" style="color:var(--danger);" onclick="this.parentElement.remove()">×</button>';
            html += '</div>';
            document.getElementById('materiais-list').insertAdjacentHTML('beforeend', html);
        }
    }
}

// Salvar
function saveAula() {
    if (isLocked) {
        alert('Esta aula está travada. Destrave-a primeiro.');
        return;
    }
    
    var title = document.getElementById('aula_title').value;
    if (!title) {
        alert('Digite o título da aula');
        return;
    }
    
    var materiais = [];
    document.querySelectorAll('#materiais-list .material-item').forEach(function(item) {
        var inputs = item.querySelectorAll('input');
        materiais.push({
            display_name: inputs[0].value,
            nome: inputs[0].value,
            url: inputs[1].value,
            tipo: inputs[1].value.split('.').pop()
        });
    });
    
    var rotina = {
        ativa: document.getElementById('rotina_ativa').checked,
        dias: document.getElementById('rotina_dias').value,
        mensagem: document.getElementById('rotina_msg').value
    };
    
    var data = {
        action: 'raz_save_aula',
        nonce: nonce,
        aula_id: aulaId,
        modulo_id: moduloId,
        title: title,
        content: editor.innerHTML,
        video_url: document.getElementById('aula_video_url').value,
        video_provider: document.getElementById('aula_provider').value,
        duracao: document.getElementById('aula_duracao').value,
        materiais: JSON.stringify(materiais),
        rotina: JSON.stringify(rotina)
    };
    
    var formData = new URLSearchParams();
    for (var key in data) {
        formData.append(key, data[key]);
    }
    
    fetch(ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData.toString()
    })
    .then(function(r) { return r.json(); })
    .then(function(d) {
        if (d.success) {
            alert('Aula salva com sucesso!');
            if (!aulaId && d.data.aula_id) {
                window.location.href = '?aula=' + d.data.aula_id + '&modulo=' + moduloId + '&curso=' + cursoId;
            }
        } else {
            alert('Erro: ' + (d.data ? d.data.message : 'Desconhecido'));
        }
    });
}
</script>
