<?php
/**
 * Admin: Relatórios - Com Paginação
 */
$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title'));
$curso_id = isset($_GET['curso']) ? intval($_GET['curso']) : ($cursos[0]->ID ?? 0);
$curso = get_post($curso_id);

// Paginação
$per_page = 20;
$page_aulas = isset($_GET['pa']) ? max(1, intval($_GET['pa'])) : 1;
$page_alunos = isset($_GET['pal']) ? max(1, intval($_GET['pal'])) : 1;

// Dados do curso
if ($curso) {
    // Estatísticas gerais
    global $wpdb;
    $total_alunos = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->usermeta} WHERE meta_key = %s",
        '_raz_curso_acesso_' . $curso_id
    ));
    
    $aulas = raz_lms_get_all_aulas($curso_id);
    $total_aulas = count($aulas);
    
    // Conclusões por aula (paginado)
    $offset_aulas = ($page_aulas - 1) * $per_page;
    $aulas_paginated = array_slice($aulas, $offset_aulas, $per_page);
    $total_pages_aulas = ceil(count($aulas) / $per_page);
    
    // Progresso dos alunos (paginado)
    $alunos_query = $wpdb->get_results($wpdb->prepare(
        "SELECT DISTINCT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s ORDER BY user_id LIMIT %d OFFSET %d",
        '_raz_curso_acesso_' . $curso_id,
        $per_page,
        ($page_alunos - 1) * $per_page
    ));
    $total_pages_alunos = ceil($total_alunos / $per_page);
    
    // Calcular taxa de conclusão
    $total_completed = 0;
    foreach ($aulas as $aula) {
        $completed = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value = '1'",
            '_raz_lesson_completed_' . $aula->ID
        ));
        $total_completed += $completed;
    }
    $completion_rate = $total_alunos > 0 && $total_aulas > 0 
        ? round(($total_completed / ($total_alunos * $total_aulas)) * 100, 1) 
        : 0;
}
?>

<div class="admin-header">
    <h2>Relatórios</h2>
    <div style="display:flex;gap:12px;align-items:center;">
        <select onchange="location.href='?curso='+this.value" style="padding:8px 12px;border:1px solid var(--border);border-radius:8px;">
            <?php foreach ($cursos as $c) : ?>
            <option value="<?php echo $c->ID; ?>" <?php selected($curso_id, $c->ID); ?>><?php echo esc_html($c->post_title); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>

<?php if ($curso) : ?>

<!-- Estatísticas Gerais -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:24px;">
    <div class="form-card" style="margin:0;text-align:center;">
        <div style="font-size:32px;font-weight:700;color:var(--primary);"><?php echo $total_alunos; ?></div>
        <div style="color:var(--muted);font-size:14px;">Total de Alunos</div>
    </div>
    <div class="form-card" style="margin:0;text-align:center;">
        <div style="font-size:32px;font-weight:700;color:var(--success);"><?php echo $total_aulas; ?></div>
        <div style="color:var(--muted);font-size:14px;">Total de Aulas</div>
    </div>
    <div class="form-card" style="margin:0;text-align:center;">
        <div style="font-size:32px;font-weight:700;color:var(--warning);"><?php echo $completion_rate; ?>%</div>
        <div style="color:var(--muted);font-size:14px;">Taxa de Conclusão</div>
    </div>
</div>

<!-- Conclusões por Aula -->
<div class="form-card">
    <h3 style="margin-bottom:16px;">📺 Conclusões por Aula</h3>
    <div class="table-card" style="margin:0;">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Aula</th>
                    <th style="width:120px;text-align:center;">Conclusões</th>
                    <th style="width:120px;text-align:center;">Taxa</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                global $wpdb;
                foreach ($aulas_paginated as $aula) :
                    $completed = $wpdb->get_var($wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value = '1'",
                        '_raz_lesson_completed_' . $aula->ID
                    ));
                    $rate = $total_alunos > 0 ? round(($completed / $total_alunos) * 100, 1) : 0;
                ?>
                <tr>
                    <td><?php echo esc_html($aula->post_title); ?></td>
                    <td style="text-align:center;"><?php echo $completed; ?></td>
                    <td style="text-align:center;">
                        <div style="background:#e2e8f0;border-radius:4px;height:8px;overflow:hidden;">
                            <div style="background:var(--success);height:100%;width:<?php echo $rate; ?>%;"></div>
                        </div>
                        <small><?php echo $rate; ?>%</small>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <?php if ($total_pages_aulas > 1) : ?>
    <div style="display:flex;justify-content:center;gap:8px;margin-top:16px;">
        <?php if ($page_aulas > 1) : ?>
        <a href="?curso=<?php echo $curso_id; ?>&pa=<?php echo $page_aulas - 1; ?>&pal=<?php echo $page_alunos; ?>" class="btn btn-secondary btn-sm">←</a>
        <?php endif; ?>
        <span style="padding:8px;color:var(--muted);font-size:12px;">Pág. <?php echo $page_aulas; ?>/<?php echo $total_pages_aulas; ?></span>
        <?php if ($page_aulas < $total_pages_aulas) : ?>
        <a href="?curso=<?php echo $curso_id; ?>&pa=<?php echo $page_aulas + 1; ?>&pal=<?php echo $page_alunos; ?>" class="btn btn-secondary btn-sm">→</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<!-- Progresso dos Alunos -->
<div class="form-card">
    <h3 style="margin-bottom:16px;">👥 Progresso dos Alunos</h3>
    <div class="table-card" style="margin:0;">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Aluno</th>
                    <th>Email</th>
                    <th style="width:200px;">Progresso</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($alunos_query as $row) :
                    $user = get_userdata($row->user_id);
                    if (!$user) continue;
                    $progress = raz_lms_get_course_progress($row->user_id, $curso_id);
                ?>
                <tr>
                    <td><?php echo esc_html($user->display_name); ?></td>
                    <td><?php echo esc_html($user->user_email); ?></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="flex:1;background:#e2e8f0;border-radius:4px;height:8px;overflow:hidden;">
                                <div style="background:var(--primary);height:100%;width:<?php echo $progress['percent']; ?>%;"></div>
                            </div>
                            <span style="font-size:12px;white-space:nowrap;"><?php echo $progress['completed']; ?>/<?php echo $progress['total']; ?></span>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <?php if ($total_pages_alunos > 1) : ?>
    <div style="display:flex;justify-content:center;gap:8px;margin-top:16px;">
        <?php if ($page_alunos > 1) : ?>
        <a href="?curso=<?php echo $curso_id; ?>&pa=<?php echo $page_aulas; ?>&pal=<?php echo $page_alunos - 1; ?>" class="btn btn-secondary btn-sm">←</a>
        <?php endif; ?>
        <span style="padding:8px;color:var(--muted);font-size:12px;">Pág. <?php echo $page_alunos; ?>/<?php echo $total_pages_alunos; ?></span>
        <?php if ($page_alunos < $total_pages_alunos) : ?>
        <a href="?curso=<?php echo $curso_id; ?>&pa=<?php echo $page_aulas; ?>&pal=<?php echo $page_alunos + 1; ?>" class="btn btn-secondary btn-sm">→</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<?php else : ?>
<div class="form-card" style="text-align:center;padding:40px;">
    <p style="color:var(--muted);">Nenhum curso encontrado</p>
</div>
<?php endif; ?>
