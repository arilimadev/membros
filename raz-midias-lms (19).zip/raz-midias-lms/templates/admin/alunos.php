<?php
/**
 * Admin: Alunos - CRUD Completo com Telefone e Auditoria Melhorada
 */
$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title'));

$filter_curso = isset($_GET['curso_id']) ? intval($_GET['curso_id']) : 0;
$filter_status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
$filter_origem = isset($_GET['origem']) ? sanitize_text_field($_GET['origem']) : '';
$search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
$current_page = isset($_GET['pag']) ? max(1, intval($_GET['pag'])) : 1;
$per_page = 20;

global $wpdb;
$where = "WHERE um.meta_key LIKE '_raz_curso_acesso_%'";
if ($filter_curso) {
    $where .= $wpdb->prepare(" AND um.meta_key = %s", '_raz_curso_acesso_' . $filter_curso);
}

$query = "SELECT DISTINCT um.user_id, u.user_email, u.display_name 
          FROM {$wpdb->usermeta} um 
          JOIN {$wpdb->users} u ON um.user_id = u.ID 
          {$where}";

if ($search) {
    $query .= $wpdb->prepare(" AND (u.user_email LIKE %s OR u.display_name LIKE %s)", '%' . $search . '%', '%' . $search . '%');
}

// Filtro por origem
if ($filter_origem) {
    $query .= " AND um.user_id IN (
        SELECT DISTINCT user_id FROM {$wpdb->usermeta} 
        WHERE meta_key LIKE '_raz_curso_acesso_%' 
        AND meta_value LIKE '%" . esc_sql($filter_origem) . "%'
    )";
}

$total = $wpdb->get_var(str_replace('SELECT DISTINCT um.user_id, u.user_email, u.display_name', 'SELECT COUNT(DISTINCT um.user_id)', $query));
$offset = ($current_page - 1) * $per_page;
$query .= " ORDER BY u.display_name ASC LIMIT {$per_page} OFFSET {$offset}";
$alunos = $wpdb->get_results($query);
$total_pages = ceil($total / $per_page);
?>

<style>
.filters-form { display: flex; gap: 12px; margin-bottom: 24px; flex-wrap: wrap; align-items: center; }
.filters-form input[type="text"], .filters-form select { padding: 10px 14px; border: 1px solid var(--border); border-radius: 8px; font-size: 14px; background: #fff; }
.filters-form input[type="text"] { flex: 1; min-width: 200px; }
.filters-form select { min-width: 140px; }

.aluno-modal { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: none; align-items: center; justify-content: center; z-index: 1000; padding: 20px; }
.aluno-modal.open { display: flex; }
.aluno-modal-content { background: #fff; border-radius: 12px; max-height: 90vh; overflow-y: auto; width: 100%; max-width: 600px; }
.aluno-modal-header { display: flex; justify-content: space-between; align-items: center; padding: 20px 24px; border-bottom: 1px solid var(--border); position: sticky; top: 0; background: #fff; z-index: 10; }
.aluno-modal-header h3 { margin: 0; font-size: 18px; }
.aluno-modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--muted); line-height: 1; }
.aluno-modal-body { padding: 24px; }
.aluno-modal-footer { display: flex; justify-content: flex-end; gap: 12px; padding: 16px 24px; border-top: 1px solid var(--border); position: sticky; bottom: 0; background: #fff; }

.audit-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; }
.audit-card { background: var(--bg); padding: 16px; border-radius: 8px; }
.audit-card h4 { font-size: 14px; margin-bottom: 10px; display: flex; align-items: center; gap: 6px; }
.audit-card p { font-size: 13px; color: var(--muted); margin-bottom: 6px; }
.audit-card .value { color: var(--text); font-weight: 500; }
.audit-table { width: 100%; font-size: 12px; }
.audit-table th, .audit-table td { padding: 10px 8px; text-align: left; border-bottom: 1px solid var(--border); }
.audit-table th { background: var(--bg); font-weight: 600; position: sticky; top: 0; }

.action-link { font-size: 12px; color: var(--primary); cursor: pointer; text-decoration: none; padding: 4px 8px; border-radius: 4px; white-space: nowrap; }
.action-link:hover { background: rgba(99, 102, 241, 0.1); }

.cursos-badge { cursor: pointer; background: var(--primary); color: #fff; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 500; }
.cursos-badge:hover { opacity: 0.9; }

.dias-sem-acesso { font-size: 11px; color: var(--muted); }
.dias-sem-acesso.alerta { color: var(--danger); font-weight: 500; }

.origem-badge { font-size: 10px; padding: 2px 6px; border-radius: 4px; text-transform: uppercase; }
.origem-badge.manual { background: #e0e7ff; color: #4338ca; }
.origem-badge.kiwify { background: #d1fae5; color: #065f46; }
.origem-badge.woocommerce { background: #fef3c7; color: #92400e; }

.cursos-list { margin-top: 12px; }
.curso-item { display: flex; justify-content: space-between; align-items: center; padding: 10px; background: var(--bg); border-radius: 6px; margin-bottom: 8px; }
.curso-item-name { font-weight: 500; font-size: 13px; }
.curso-item-exp { font-size: 11px; color: var(--muted); }
.curso-item-exp.vitalicio { color: var(--success); }
.curso-item-exp.expirado { color: var(--danger); }

.pagination-mini { display: flex; align-items: center; gap: 8px; justify-content: center; margin-top: 12px; }
.pagination-mini button { padding: 4px 10px; font-size: 11px; border: 1px solid var(--border); background: #fff; border-radius: 4px; cursor: pointer; }
.pagination-mini button:disabled { opacity: 0.5; cursor: not-allowed; }
.pagination-mini span { font-size: 11px; color: var(--muted); }

@media (max-width: 768px) {
    .filters-form { flex-direction: column; }
    .filters-form input[type="text"], .filters-form select { width: 100%; }
    .audit-grid { grid-template-columns: 1fr; }
    .aluno-modal-content { max-width: 100%; margin: 10px; }
}
</style>

<div class="admin-header">
    <h2>Alunos</h2>
    <button class="btn btn-primary" onclick="openAddModal()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Novo Aluno
    </button>
</div>

<form method="get" action="<?php echo home_url('/gestao-cursos/alunos/'); ?>" class="filters-form">
    <input type="text" name="s" placeholder="Buscar por nome ou email..." value="<?php echo esc_attr($search); ?>">
    <select name="curso_id">
        <option value="">Todos os cursos</option>
        <?php foreach ($cursos as $c) : ?>
        <option value="<?php echo $c->ID; ?>" <?php selected($filter_curso, $c->ID); ?>><?php echo esc_html($c->post_title); ?></option>
        <?php endforeach; ?>
    </select>
    <select name="status">
        <option value="">Todos status</option>
        <option value="ativo" <?php selected($filter_status, 'ativo'); ?>>Ativos</option>
        <option value="expirado" <?php selected($filter_status, 'expirado'); ?>>Expirados</option>
    </select>
    <select name="origem">
        <option value="">Todas origens</option>
        <option value="manual" <?php selected($filter_origem, 'manual'); ?>>Manual</option>
        <option value="kiwify" <?php selected($filter_origem, 'kiwify'); ?>>Kiwify</option>
        <option value="woocommerce" <?php selected($filter_origem, 'woocommerce'); ?>>WooCommerce</option>
    </select>
    <button type="submit" class="btn btn-secondary">Filtrar</button>
    <?php if ($search || $filter_curso || $filter_status || $filter_origem) : ?>
    <a href="<?php echo home_url('/gestao-cursos/alunos/'); ?>" class="btn btn-sm" style="color:var(--muted);">Limpar</a>
    <?php endif; ?>
</form>

<div class="table-card">
    <table class="data-table">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Telefone</th>
                <th>Cursos</th>
                <th>Último Acesso</th>
                <th style="width:180px;">Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($alunos)) : ?>
            <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:40px;">Nenhum aluno encontrado</td></tr>
            <?php else : ?>
            <?php foreach ($alunos as $aluno) :
                $user = get_userdata($aluno->user_id);
                $user_cursos = raz_lms_get_user_courses($aluno->user_id);
                $telefone = get_user_meta($aluno->user_id, '_raz_telefone', true);
                $last_timestamp = get_user_meta($aluno->user_id, '_raz_last_access_timestamp', true);
                
                $last_access_formatted = 'Nunca';
                $dias_sem_acesso = null;
                if ($last_timestamp) {
                    $timezone = wp_timezone();
                    $dt = new DateTime('@' . $last_timestamp);
                    $dt->setTimezone($timezone);
                    $last_access_formatted = $dt->format('d/m/Y H:i');
                    
                    $now = new DateTime('now', $timezone);
                    $diff = $now->diff($dt);
                    $dias_sem_acesso = $diff->days;
                }
                
                // Verificar origem do primeiro acesso
                $origem = 'manual';
                foreach ($user_cursos as $uc) {
                    $acesso = get_user_meta($aluno->user_id, '_raz_curso_acesso_' . $uc->ID, true);
                    if (isset($acesso['origem'])) {
                        $origem = $acesso['origem'];
                        break;
                    }
                }
            ?>
            <tr>
                <td>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <div style="width:36px;height:36px;background:var(--primary);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:600;font-size:14px;">
                            <?php echo raz_lms_get_initials($user->display_name); ?>
                        </div>
                        <div>
                            <span style="display:block;"><?php echo esc_html($user->display_name); ?></span>
                            <span class="origem-badge <?php echo $origem; ?>"><?php echo $origem; ?></span>
                        </div>
                    </div>
                </td>
                <td><?php echo esc_html($user->user_email); ?></td>
                <td><?php echo $telefone ? esc_html($telefone) : '<span style="color:var(--muted);">-</span>'; ?></td>
                <td>
                    <span class="cursos-badge" onclick="showUserCursos(<?php echo $aluno->user_id; ?>, '<?php echo esc_js($user->display_name); ?>')">
                        <?php echo count($user_cursos); ?> curso(s)
                    </span>
                </td>
                <td>
                    <div><?php echo $last_access_formatted; ?></div>
                    <?php if ($dias_sem_acesso !== null) : ?>
                    <span class="dias-sem-acesso <?php echo $dias_sem_acesso > 7 ? 'alerta' : ''; ?>">
                        <?php echo $dias_sem_acesso == 0 ? 'Hoje' : $dias_sem_acesso . ' dia(s) atrás'; ?>
                    </span>
                    <?php endif; ?>
                </td>
                <td>
                    <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;">
                        <span class="action-link" onclick="showUserAudit(<?php echo $aluno->user_id; ?>, '<?php echo esc_js($user->display_name); ?>')">Auditoria</span>
                        <span class="action-link" onclick="openEditModal(<?php echo $aluno->user_id; ?>)">Editar</span>
                        <span class="action-link" style="color:var(--danger);" onclick="deleteUser(<?php echo $aluno->user_id; ?>, '<?php echo esc_js($user->display_name); ?>')">Excluir</span>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php if ($total_pages > 1) : ?>
<div style="display:flex;justify-content:center;gap:8px;margin-top:20px;">
    <?php if ($current_page > 1) : ?>
    <a href="?pag=<?php echo $current_page - 1; ?>&curso_id=<?php echo $filter_curso; ?>&status=<?php echo $filter_status; ?>&origem=<?php echo $filter_origem; ?>&s=<?php echo urlencode($search); ?>" class="btn btn-secondary btn-sm">← Anterior</a>
    <?php endif; ?>
    <span style="padding:8px 12px;color:var(--muted);">Página <?php echo $current_page; ?> de <?php echo $total_pages; ?></span>
    <?php if ($current_page < $total_pages) : ?>
    <a href="?pag=<?php echo $current_page + 1; ?>&curso_id=<?php echo $filter_curso; ?>&status=<?php echo $filter_status; ?>&origem=<?php echo $filter_origem; ?>&s=<?php echo urlencode($search); ?>" class="btn btn-secondary btn-sm">Próxima →</a>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Modal Adicionar/Editar -->
<div class="aluno-modal" id="user-modal">
    <div class="aluno-modal-content">
        <div class="aluno-modal-header">
            <h3 id="modal-title">Novo Aluno</h3>
            <button class="aluno-modal-close" onclick="closeUserModal()">&times;</button>
        </div>
        <form id="user-form" class="aluno-modal-body">
            <input type="hidden" name="user_id" id="form_user_id">
            
            <div class="form-group">
                <label>Nome completo *</label>
                <input type="text" name="display_name" id="form_display_name" required>
            </div>
            
            <div class="form-group">
                <label>Email *</label>
                <input type="email" name="email" id="form_email" required>
            </div>
            
            <div class="form-group">
                <label>Telefone (WhatsApp)</label>
                <input type="tel" name="telefone" id="form_telefone" placeholder="(00) 00000-0000">
            </div>
            
            <div class="form-group" id="password-group">
                <label>Senha</label>
                <input type="password" name="password" id="form_password" placeholder="Deixe vazio para gerar automaticamente">
                <small style="color:var(--muted);">Mínimo 6 caracteres</small>
            </div>
            
            <div class="form-group">
                <label>Cursos com acesso</label>
                <div id="cursos-checkboxes" style="max-height:150px;overflow-y:auto;border:1px solid var(--border);border-radius:8px;padding:12px;">
                    <?php foreach ($cursos as $c) : ?>
                    <label style="display:flex;align-items:center;gap:8px;padding:6px 0;cursor:pointer;font-size:13px;">
                        <input type="checkbox" name="cursos[]" value="<?php echo $c->ID; ?>">
                        <?php echo esc_html($c->post_title); ?>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="form-group">
                <label>Tipo de acesso</label>
                <select name="acesso_tipo" id="form_acesso_tipo">
                    <option value="dias">Por período (dias)</option>
                    <option value="vitalicio">Vitalício</option>
                </select>
            </div>
            
            <div class="form-group" id="dias-group">
                <label>Dias de acesso</label>
                <input type="number" name="dias" id="form_dias" value="365" min="1">
            </div>
        </form>
        <div class="aluno-modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeUserModal()">Cancelar</button>
            <button type="button" class="btn btn-primary" onclick="saveUser()">Salvar</button>
        </div>
    </div>
</div>

<!-- Modal Cursos do Aluno -->
<div class="aluno-modal" id="cursos-modal">
    <div class="aluno-modal-content" style="max-width:500px;">
        <div class="aluno-modal-header">
            <h3 id="cursos-modal-title">Cursos do Aluno</h3>
            <button class="aluno-modal-close" onclick="closeCursosModal()">&times;</button>
        </div>
        <div id="cursos-content" class="aluno-modal-body">
            <p style="text-align:center;padding:20px;color:var(--muted);">Carregando...</p>
        </div>
    </div>
</div>

<!-- Modal Auditoria -->
<div class="aluno-modal" id="audit-modal">
    <div class="aluno-modal-content" style="max-width:800px;">
        <div class="aluno-modal-header">
            <h3 id="audit-modal-title">Auditoria do Aluno</h3>
            <button class="aluno-modal-close" onclick="closeAuditModal()">&times;</button>
        </div>
        <div id="audit-content" class="aluno-modal-body">
            <p style="text-align:center;padding:40px;color:var(--muted);">Carregando...</p>
        </div>
    </div>
</div>

<script>
var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
var nonce = '<?php echo wp_create_nonce('raz_admin_nonce'); ?>';

document.getElementById('form_acesso_tipo').addEventListener('change', function() {
    document.getElementById('dias-group').style.display = this.value === 'dias' ? 'block' : 'none';
});

// Máscara telefone
document.getElementById('form_telefone').addEventListener('input', function(e) {
    var v = e.target.value.replace(/\D/g, '');
    if (v.length > 11) v = v.slice(0, 11);
    if (v.length > 6) v = '(' + v.slice(0,2) + ') ' + v.slice(2,7) + '-' + v.slice(7);
    else if (v.length > 2) v = '(' + v.slice(0,2) + ') ' + v.slice(2);
    e.target.value = v;
});

function openAddModal() {
    document.getElementById('modal-title').textContent = 'Novo Aluno';
    document.getElementById('form_user_id').value = '';
    document.getElementById('form_display_name').value = '';
    document.getElementById('form_email').value = '';
    document.getElementById('form_telefone').value = '';
    document.getElementById('form_password').value = '';
    document.getElementById('form_acesso_tipo').value = 'dias';
    document.getElementById('form_dias').value = '365';
    document.getElementById('dias-group').style.display = 'block';
    document.getElementById('password-group').querySelector('label').textContent = 'Senha';
    document.querySelectorAll('#cursos-checkboxes input').forEach(function(c) { c.checked = false; });
    document.getElementById('user-modal').classList.add('open');
}

function openEditModal(userId) {
    document.getElementById('modal-title').textContent = 'Editar Aluno';
    document.getElementById('password-group').querySelector('label').textContent = 'Nova senha (opcional)';
    document.getElementById('user-modal').classList.add('open');
    
    fetch(ajaxurl + '?action=raz_get_user_data&nonce=' + nonce + '&user_id=' + userId)
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) {
                var u = d.data;
                document.getElementById('form_user_id').value = u.id;
                document.getElementById('form_display_name').value = u.name;
                document.getElementById('form_email').value = u.email;
                document.getElementById('form_telefone').value = u.telefone || '';
                document.getElementById('form_password').value = '';
                document.querySelectorAll('#cursos-checkboxes input').forEach(function(c) {
                    c.checked = u.cursos.includes(parseInt(c.value));
                });
            }
        });
}

function closeUserModal() { document.getElementById('user-modal').classList.remove('open'); }

function deleteUser(userId, userName) {
    if (!confirm('Tem certeza que deseja excluir o aluno "' + userName + '"?\n\nEsta ação removerá todos os acessos e dados do aluno.')) return;
    
    fetch(ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=raz_delete_user&nonce=' + nonce + '&user_id=' + userId
    })
    .then(function(r) { return r.json(); })
    .then(function(d) {
        if (d.success) { location.reload(); } else { alert('Erro: ' + (d.data ? d.data.message : 'Desconhecido')); }
    });
}

function saveUser() {
    var formData = new FormData(document.getElementById('user-form'));
    formData.append('action', 'raz_save_user');
    formData.append('nonce', nonce);
    
    fetch(ajaxurl, { method: 'POST', body: formData })
    .then(function(r) { return r.json(); })
    .then(function(d) {
        if (d.success) { location.reload(); } else { alert('Erro: ' + (d.data ? d.data.message : 'Desconhecido')); }
    });
}

function showUserCursos(userId, userName) {
    document.getElementById('cursos-modal-title').textContent = 'Cursos de ' + userName;
    document.getElementById('cursos-modal').classList.add('open');
    document.getElementById('cursos-content').innerHTML = '<p style="text-align:center;padding:20px;color:var(--muted);">Carregando...</p>';
    
    fetch(ajaxurl + '?action=raz_get_user_cursos&nonce=' + nonce + '&user_id=' + userId)
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success && d.data.length > 0) {
                var html = '<div class="cursos-list">';
                d.data.forEach(function(c) {
                    var expClass = c.vitalicio ? 'vitalicio' : (c.expirado ? 'expirado' : '');
                    var expText = c.vitalicio ? '♾️ Vitalício' : (c.expirado ? '❌ Expirado em ' + c.expiracao : '📅 Expira em ' + c.expiracao);
                    html += '<div class="curso-item">';
                    html += '<span class="curso-item-name">' + c.nome + '</span>';
                    html += '<span class="curso-item-exp ' + expClass + '">' + expText + '</span>';
                    html += '</div>';
                });
                html += '</div>';
                document.getElementById('cursos-content').innerHTML = html;
            } else {
                document.getElementById('cursos-content').innerHTML = '<p style="text-align:center;color:var(--muted);">Nenhum curso encontrado</p>';
            }
        })
        .catch(function() {
            document.getElementById('cursos-content').innerHTML = '<p style="text-align:center;color:var(--danger);">Erro ao carregar</p>';
        });
}

function closeCursosModal() { document.getElementById('cursos-modal').classList.remove('open'); }

var auditPage = 1;
var auditUserId = 0;

function showUserAudit(userId, userName) {
    auditUserId = userId;
    auditPage = 1;
    document.getElementById('audit-modal-title').textContent = 'Auditoria: ' + userName;
    document.getElementById('audit-modal').classList.add('open');
    loadAuditData();
}

function loadAuditData() {
    document.getElementById('audit-content').innerHTML = '<p style="text-align:center;padding:40px;color:var(--muted);">Carregando...</p>';
    
    fetch(ajaxurl + '?action=raz_get_user_audit&nonce=' + nonce + '&user_id=' + auditUserId + '&page=' + auditPage)
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) {
                var a = d.data;
                var html = '<div class="audit-grid">';
                
                // Card último acesso
                html += '<div class="audit-card"><h4>📅 Último Acesso</h4>';
                html += '<p>Data: <span class="value">' + a.last_access.date + '</span></p>';
                html += '<p>Dias sem acessar: <span class="value">' + (a.last_access.dias_sem_acesso || '0') + '</span></p>';
                html += '<p>Curso: <span class="value">' + (a.last_access.curso || '-') + '</span></p>';
                html += '<p>Aula: <span class="value">' + (a.last_access.aula || '-') + '</span></p></div>';
                
                // Card posição atual
                html += '<div class="audit-card"><h4>📍 Posição Atual</h4>';
                html += '<p>Módulo: <span class="value">' + (a.posicao.modulo || '-') + '</span></p>';
                html += '<p>Aula: <span class="value">' + (a.posicao.aula || '-') + '</span></p>';
                html += '<p>Progresso: <span class="value">' + (a.posicao.progresso || '0%') + '</span></p></div>';
                
                // Card dispositivo
                html += '<div class="audit-card"><h4>💻 Dispositivo</h4>';
                html += '<p>Navegador: <span class="value">' + (a.last_access.browser || '-') + '</span></p>';
                html += '<p>Sistema: <span class="value">' + (a.last_access.os || '-') + '</span></p>';
                html += '<p>IP: <span class="value">' + (a.last_access.ip || '-') + '</span></p></div>';
                
                // Card info
                html += '<div class="audit-card"><h4>👤 Informações</h4>';
                html += '<p>Cadastro: <span class="value">' + (a.user.registered || '-') + '</span></p>';
                html += '<p>Origem: <span class="value">' + (a.user.origem || 'manual') + '</span></p>';
                html += '<p>Total acessos: <span class="value">' + (a.total_acessos || '0') + '</span></p></div>';
                
                html += '</div>';
                
                // Tabela de histórico
                html += '<h4 style="margin:20px 0 12px;">📜 Histórico de Acessos</h4>';
                html += '<div style="max-height:300px;overflow-y:auto;border:1px solid var(--border);border-radius:8px;">';
                html += '<table class="audit-table"><thead><tr><th>Data/Hora</th><th>Curso</th><th>Módulo</th><th>Aula</th><th>IP</th></tr></thead><tbody>';
                
                if (a.history && a.history.length) {
                    a.history.forEach(function(h) {
                        html += '<tr><td>' + h.date + '</td><td>' + h.curso + '</td><td>' + h.modulo + '</td><td>' + h.aula + '</td><td>' + h.ip + '</td></tr>';
                    });
                } else {
                    html += '<tr><td colspan="5" style="text-align:center;color:var(--muted);padding:20px;">Nenhum acesso registrado</td></tr>';
                }
                
                html += '</tbody></table></div>';
                
                // Paginação
                if (a.total_pages > 1) {
                    html += '<div class="pagination-mini">';
                    html += '<button onclick="auditPrev()" ' + (auditPage <= 1 ? 'disabled' : '') + '>← Anterior</button>';
                    html += '<span>Página ' + auditPage + ' de ' + a.total_pages + '</span>';
                    html += '<button onclick="auditNext(' + a.total_pages + ')" ' + (auditPage >= a.total_pages ? 'disabled' : '') + '>Próxima →</button>';
                    html += '</div>';
                }
                
                document.getElementById('audit-content').innerHTML = html;
            } else {
                document.getElementById('audit-content').innerHTML = '<p style="text-align:center;color:var(--danger);">Erro ao carregar dados: ' + (d.data ? d.data.message : 'Desconhecido') + '</p>';
            }
        })
        .catch(function(e) {
            document.getElementById('audit-content').innerHTML = '<p style="text-align:center;color:var(--danger);">Erro de conexão</p>';
            console.error(e);
        });
}

function auditPrev() { if (auditPage > 1) { auditPage--; loadAuditData(); } }
function auditNext(max) { if (auditPage < max) { auditPage++; loadAuditData(); } }

function closeAuditModal() { document.getElementById('audit-modal').classList.remove('open'); }
</script>
