<?php
/**
 * Admin: Editar Curso com Drag & Drop e AJAX dinâmico
 */
$curso_id = $item_id;
$curso = $curso_id ? get_post($curso_id) : null;
$modulos = $curso_id ? raz_lms_get_modulos($curso_id) : array();
$kiwify_id = $curso_id ? get_post_meta($curso_id, '_raz_curso_kiwify_id', true) : '';
$dias_acesso = $curso_id ? (get_post_meta($curso_id, '_raz_curso_dias_acesso', true) ?: 365) : 365;
$vitalicio = $curso_id ? get_post_meta($curso_id, '_raz_curso_vitalicio', true) : '';
$thumb_id = $curso_id ? get_post_thumbnail_id($curso_id) : 0;
$thumb_url = $thumb_id ? wp_get_attachment_image_url($thumb_id, 'medium') : '';
$cor_header = $curso_id ? get_post_meta($curso_id, '_raz_curso_cor_header', true) : '#667eea';
$cor_controls = $curso_id ? get_post_meta($curso_id, '_raz_curso_cor_controls', true) : '#1e293b';
if (!$cor_header) $cor_header = '#667eea';
if (!$cor_controls) $cor_controls = '#1e293b';

// Tab ativa (vinda da URL)
$active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'info';
?>

<div class="admin-header">
    <h2><?php echo $curso_id ? 'Editar Curso' : 'Novo Curso'; ?></h2>
    <a href="<?php echo home_url('/gestao-cursos/cursos'); ?>" class="btn btn-secondary">← Voltar</a>
</div>

<div class="tabs">
    <div class="tab <?php echo $active_tab === 'info' ? 'active' : ''; ?>" onclick="showTab('info',this)">Informações</div>
    <?php if ($curso_id) : ?>
    <div class="tab <?php echo $active_tab === 'conteudo' ? 'active' : ''; ?>" onclick="showTab('conteudo',this)">Conteúdo</div>
    <div class="tab <?php echo $active_tab === 'config' ? 'active' : ''; ?>" onclick="showTab('config',this)">Configurações</div>
    <?php endif; ?>
</div>

<!-- Tab: Info -->
<div id="tab-info" class="tab-content" style="<?php echo $active_tab !== 'info' ? 'display:none;' : ''; ?>"">
    <div class="form-card" style="max-width:800px;">
        <form id="form-curso" enctype="multipart/form-data">
            <input type="hidden" name="curso_id" value="<?php echo $curso_id; ?>">
            
            <div class="form-group">
                <label>Imagem do Curso</label>
                <div style="display:flex;gap:16px;align-items:flex-start;">
                    <div id="thumb-preview" style="width:200px;height:125px;background:linear-gradient(135deg,<?php echo esc_attr($cor_header); ?>,#764ba2);border-radius:12px;overflow:hidden;flex-shrink:0;">
                        <?php if ($thumb_url) : ?>
                        <img src="<?php echo esc_url($thumb_url); ?>" style="width:100%;height:100%;object-fit:cover;">
                        <?php endif; ?>
                    </div>
                    <div>
                        <input type="file" name="thumbnail" id="thumbnail-input" accept="image/*" style="display:none;">
                        <input type="hidden" name="thumbnail_id" id="thumbnail_id" value="<?php echo $thumb_id; ?>">
                        <button type="button" class="btn btn-secondary" onclick="document.getElementById('thumbnail-input').click()">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                            Escolher Imagem
                        </button>
                        <p class="form-hint" style="margin-top:8px;">Recomendado: 800x500px</p>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label>Cor do Header do Curso</label>
                <div style="display:flex;gap:12px;align-items:center;">
                    <input type="color" name="cor_header" id="cor_header" value="<?php echo esc_attr($cor_header); ?>" style="width:60px;height:40px;padding:0;border:none;cursor:pointer;">
                    <input type="text" id="cor_header_hex" value="<?php echo esc_attr($cor_header); ?>" style="width:100px;" onchange="document.getElementById('cor_header').value=this.value">
                    <span class="form-hint">Cor de fundo do cabeçalho na página do curso</span>
                </div>
            </div>
            
            <div class="form-group">
                <label>Cor dos Controles do Player</label>
                <div style="display:flex;gap:12px;align-items:center;">
                    <input type="color" name="cor_controls" id="cor_controls" value="<?php echo esc_attr($cor_controls); ?>" style="width:60px;height:40px;padding:0;border:none;cursor:pointer;">
                    <input type="text" id="cor_controls_hex" value="<?php echo esc_attr($cor_controls); ?>" style="width:100px;" onchange="document.getElementById('cor_controls').value=this.value">
                    <span class="form-hint">Cor da barra de controles no player de aula</span>
                </div>
            </div>
            
            <div class="form-group">
                <label>Título do Curso *</label>
                <input type="text" name="titulo" value="<?php echo $curso ? esc_attr($curso->post_title) : ''; ?>" required>
            </div>
            
            <div class="form-group">
                <label>Descrição Curta</label>
                <textarea name="descricao" rows="3" placeholder="Uma breve descrição do curso..."><?php echo $curso ? esc_textarea($curso->post_excerpt) : ''; ?></textarea>
            </div>
            
            <button type="submit" class="btn btn-primary">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                Salvar Curso
            </button>
        </form>
    </div>
</div>

<?php if ($curso_id) : ?>
<!-- Tab: Conteúdo -->
<div id="tab-conteudo" class="tab-content" style="<?php echo $active_tab !== 'conteudo' ? 'display:none;' : ''; ?>">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
        <h3>Módulos e Aulas</h3>
        <button class="btn btn-primary" onclick="openModuloModal()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Novo Módulo
        </button>
    </div>
    
    <p style="color:var(--muted);margin-bottom:16px;font-size:14px;">💡 Arraste os módulos e aulas para reorganizar a ordem</p>
    
    <div class="item-list" id="modulos-list">
        <?php if (empty($modulos)) : ?>
        <div class="empty-state" id="empty-modulos" style="padding:40px;">
            <h3>Nenhum módulo</h3>
            <p>Clique em "Novo Módulo" para começar</p>
        </div>
        <?php else : foreach ($modulos as $index => $modulo) : $aulas = raz_lms_get_aulas($modulo->ID); ?>
        <div class="modulo-item sortable-item" data-id="<?php echo $modulo->ID; ?>">
            <div class="item-header" onclick="toggleModulo(this)">
                <div style="display:flex;align-items:center;gap:12px;">
                    <span class="item-drag" onclick="event.stopPropagation();">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
                    </span>
                    <strong><?php echo esc_html($modulo->post_title); ?></strong>
                    <span class="badge badge-primary aulas-count" data-modulo="<?php echo $modulo->ID; ?>"><?php echo count($aulas); ?> aulas</span>
                </div>
                <div style="display:flex;gap:8px;">
                    <button class="btn btn-sm btn-secondary" onclick="event.stopPropagation();editModulo(<?php echo $modulo->ID; ?>,'<?php echo esc_js($modulo->post_title); ?>')">Editar</button>
                    <a href="<?php echo home_url('/gestao-cursos/aula-editar/?modulo=' . $modulo->ID . '&curso=' . $curso_id); ?>" class="btn btn-sm btn-primary" onclick="event.stopPropagation();">+ Aula</a>
                    <button class="btn btn-sm btn-danger" onclick="event.stopPropagation();deleteItem(<?php echo $modulo->ID; ?>,'modulo',this)">×</button>
                </div>
            </div>
            <div class="item-content aulas-list" id="aulas-<?php echo $modulo->ID; ?>" style="display:none;">
                <?php if (empty($aulas)) : ?>
                <div class="aulas-empty" style="padding:20px;text-align:center;color:var(--muted);">Sem aulas neste módulo</div>
                <?php else : foreach ($aulas as $aula) : ?>
                <div class="item-row sortable-item" data-id="<?php echo $aula->ID; ?>">
                    <span class="item-drag">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
                    </span>
                    <span class="item-title"><?php echo esc_html($aula->post_title); ?></span>
                    <div class="item-actions">
                        <a href="<?php echo home_url('/gestao-cursos/aula-editar/' . $aula->ID . '?curso=' . $curso_id); ?>" class="btn btn-sm btn-secondary">Editar</a>
                        <button class="btn btn-sm btn-danger" onclick="deleteItem(<?php echo $aula->ID; ?>,'aula',this)">×</button>
                    </div>
                </div>
                <?php endforeach; endif; ?>
            </div>
        </div>
        <?php endforeach; endif; ?>
    </div>
</div>

<!-- Tab: Config -->
<div id="tab-config" class="tab-content" style="<?php echo $active_tab !== 'config' ? 'display:none;' : ''; ?>">
    <div class="form-card" style="max-width:700px;">
        <form id="form-config">
            <input type="hidden" name="curso_id" value="<?php echo $curso_id; ?>">
            
            <h3 style="margin-bottom:20px;">🔗 Integração com Kiwify</h3>
            
            <div style="background:var(--bg);padding:16px;border-radius:8px;margin-bottom:20px;">
                <p style="font-size:14px;color:var(--muted);margin-bottom:12px;">
                    <strong>Como funciona:</strong> Configure o ID do produto Kiwify para liberar acesso automaticamente quando um aluno comprar.
                </p>
                <ol style="font-size:13px;color:var(--muted);padding-left:20px;margin:0;">
                    <li>Copie o ID do produto na Kiwify (encontrado na URL do produto)</li>
                    <li>Cole no campo abaixo</li>
                    <li>Configure o webhook na Kiwify apontando para: <code style="background:#fff;padding:2px 6px;border-radius:4px;"><?php echo home_url('/wp-json/raz-lms/v1/webhook'); ?></code></li>
                    <li>Quando alguém comprar, o acesso será liberado automaticamente</li>
                </ol>
            </div>
            
            <div class="form-group">
                <label>ID do Produto Kiwify</label>
                <input type="text" name="kiwify_id" value="<?php echo esc_attr($kiwify_id); ?>" placeholder="Ex: abc123xyz">
            </div>
            
            <div style="background:#fef3c7;padding:16px;border-radius:8px;margin-bottom:24px;">
                <p style="font-size:14px;color:#92400e;margin:0;">
                    <strong>⚠️ Cancelamentos:</strong> Se o aluno pedir reembolso ou cancelar a assinatura, o acesso será <strong>revogado automaticamente</strong> pelo webhook.
                </p>
            </div>
            
            <h3 style="margin:32px 0 20px;">⏱️ Período de Acesso</h3>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Dias de Acesso</label>
                    <input type="number" name="dias_acesso" value="<?php echo intval($dias_acesso); ?>" min="1">
                    <p class="form-hint">Quantos dias o aluno terá acesso após a compra</p>
                </div>
                <div class="form-group">
                    <label>Tipo de Acesso</label>
                    <div style="background:var(--bg);padding:16px;border-radius:8px;margin-top:8px;">
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;">
                            <input type="checkbox" name="vitalicio" value="1" <?php checked($vitalicio,'1'); ?> style="width:20px;height:20px;">
                            <div>
                                <strong style="font-size:14px;">Acesso Vitalício</strong>
                                <p style="font-size:12px;color:var(--muted);margin:2px 0 0;">O aluno terá acesso para sempre</p>
                            </div>
                        </label>
                    </div>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary">Salvar Configurações</button>
        </form>
    </div>
</div>

<!-- Modal: Módulo -->
<div class="modal-overlay" id="modal-modulo">
    <div class="modal">
        <div class="modal-header">
            <h3 id="modal-modulo-title">Novo Módulo</h3>
            <span class="modal-close" onclick="closeModal('modal-modulo')">×</span>
        </div>
        <form id="form-modulo">
            <input type="hidden" name="modulo_id" id="modulo_id">
            <input type="hidden" name="curso_id" value="<?php echo $curso_id; ?>">
            <div class="form-group">
                <label>Nome do Módulo *</label>
                <input type="text" name="titulo" id="modulo_titulo" required>
            </div>
            <div style="display:flex;gap:12px;">
                <button type="submit" class="btn btn-primary">Salvar Módulo</button>
                <button type="button" class="btn btn-secondary" onclick="closeModal('modal-modulo')">Cancelar</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<script>
var cursoId = <?php echo $curso_id ?: 0; ?>;

// Cor picker sync
document.getElementById('cor_header').addEventListener('input', function() {
    document.getElementById('cor_header_hex').value = this.value;
});

// Thumbnail preview
document.getElementById('thumbnail-input').addEventListener('change', function(e) {
    var file = e.target.files[0];
    if (file) {
        var reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('thumb-preview').innerHTML = '<img src="' + e.target.result + '" style="width:100%;height:100%;object-fit:cover;">';
        };
        reader.readAsDataURL(file);
    }
});

function showTab(t,el){
    document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(x=>x.style.display='none');
    el.classList.add('active');
    document.getElementById('tab-'+t).style.display='block';
}

function toggleModulo(el){
    var content = el.nextElementSibling;
    content.style.display = content.style.display==='none'?'block':'none';
}

function openModuloModal(id, titulo) {
    document.getElementById('modulo_id').value = id || '';
    document.getElementById('modulo_titulo').value = titulo || '';
    document.getElementById('modal-modulo-title').textContent = id ? 'Editar Módulo' : 'Novo Módulo';
    openModal('modal-modulo');
    document.getElementById('modulo_titulo').focus();
}

function editModulo(id, titulo) {
    openModuloModal(id, titulo);
}

function deleteItem(id, tipo, btn) {
    if (!confirm('Excluir este ' + tipo + '?')) return;
    
    fetch(razAdmin.ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=raz_delete_item&nonce=' + razAdmin.nonce + '&item_id=' + id + '&tipo=' + tipo
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            showToast('Excluído!', 'success');
            // Remover elemento da DOM
            if (tipo === 'modulo') {
                btn.closest('.modulo-item').remove();
                // Verificar se ficou vazio
                if (document.querySelectorAll('.modulo-item').length === 0) {
                    document.getElementById('modulos-list').innerHTML = '<div class="empty-state" id="empty-modulos" style="padding:40px;"><h3>Nenhum módulo</h3><p>Clique em "Novo Módulo" para começar</p></div>';
                }
            } else {
                var aulaRow = btn.closest('.item-row');
                var aulasList = aulaRow.parentElement;
                var moduloId = aulasList.id.replace('aulas-', '');
                aulaRow.remove();
                // Atualizar contador
                updateAulasCount(moduloId);
                // Verificar se ficou vazio
                if (aulasList.querySelectorAll('.item-row').length === 0) {
                    aulasList.innerHTML = '<div class="aulas-empty" style="padding:20px;text-align:center;color:var(--muted);">Sem aulas neste módulo</div>';
                }
            }
        }
    });
}

function updateAulasCount(moduloId) {
    var list = document.getElementById('aulas-' + moduloId);
    var count = list ? list.querySelectorAll('.item-row').length : 0;
    var badge = document.querySelector('.aulas-count[data-modulo="' + moduloId + '"]');
    if (badge) badge.textContent = count + ' aulas';
}

// Form curso
document.getElementById('form-curso').onsubmit = function(e){
    e.preventDefault();
    var fd = new FormData(this);
    fd.append('action','raz_save_curso');
    fd.append('nonce',razAdmin.nonce);
    
    fetch(razAdmin.ajaxurl,{method:'POST',body:fd})
        .then(r=>r.json())
        .then(d=>{
            if(d.success){
                showToast('Curso salvo!','success');
                if(!cursoId){
                    window.location.href=razAdmin.homeUrl+'/gestao-cursos/curso-editar/'+d.data.curso_id;
                }
            }
        });
};

<?php if($curso_id):?>
// Form módulo
document.getElementById('form-modulo').onsubmit = function(e){
    e.preventDefault();
    var fd = new FormData(this);
    fd.append('action','raz_save_modulo');
    fd.append('nonce',razAdmin.nonce);
    
    var isEdit = !!document.getElementById('modulo_id').value;
    
    fetch(razAdmin.ajaxurl,{method:'POST',body:fd})
        .then(r=>r.json())
        .then(d=>{
            if(d.success){
                showToast('Módulo salvo!','success');
                closeModal('modal-modulo');
                
                if (isEdit) {
                    // Atualizar título na lista
                    var item = document.querySelector('.modulo-item[data-id="' + d.data.modulo_id + '"] strong');
                    if (item) item.textContent = document.getElementById('modulo_titulo').value;
                } else {
                    // Adicionar novo módulo à lista
                    var emptyState = document.getElementById('empty-modulos');
                    if (emptyState) emptyState.remove();
                    
                    var titulo = document.getElementById('modulo_titulo').value;
                    var html = '<div class="modulo-item sortable-item" data-id="' + d.data.modulo_id + '">';
                    html += '<div class="item-header" onclick="toggleModulo(this)">';
                    html += '<div style="display:flex;align-items:center;gap:12px;">';
                    html += '<span class="item-drag" onclick="event.stopPropagation();"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg></span>';
                    html += '<strong>' + titulo + '</strong>';
                    html += '<span class="badge badge-primary aulas-count" data-modulo="' + d.data.modulo_id + '">0 aulas</span>';
                    html += '</div>';
                    html += '<div style="display:flex;gap:8px;">';
                    html += '<button class="btn btn-sm btn-secondary" onclick="event.stopPropagation();editModulo(' + d.data.modulo_id + ',\'' + titulo.replace(/'/g, "\\'") + '\')">Editar</button>';
                    html += '<a href="' + razAdmin.homeUrl + '/gestao-cursos/aula-editar/?modulo=' + d.data.modulo_id + '&curso=' + cursoId + '" class="btn btn-sm btn-primary" onclick="event.stopPropagation();">+ Aula</a>';
                    html += '<button class="btn btn-sm btn-danger" onclick="event.stopPropagation();deleteItem(' + d.data.modulo_id + ',\'modulo\',this)">×</button>';
                    html += '</div></div>';
                    html += '<div class="item-content aulas-list" id="aulas-' + d.data.modulo_id + '" style="display:none;">';
                    html += '<div class="aulas-empty" style="padding:20px;text-align:center;color:var(--muted);">Sem aulas neste módulo</div>';
                    html += '</div></div>';
                    
                    document.getElementById('modulos-list').insertAdjacentHTML('beforeend', html);
                    initSortable();
                }
                
                document.getElementById('modulo_titulo').value = '';
                document.getElementById('modulo_id').value = '';
            }
        });
};

// Form config
document.getElementById('form-config').onsubmit = function(e){
    e.preventDefault();
    var fd = new FormData(this);
    fd.append('action','raz_save_curso');
    fd.append('nonce',razAdmin.nonce);
    
    fetch(razAdmin.ajaxurl,{method:'POST',body:fd})
        .then(r=>r.json())
        .then(d=>{
            if(d.success) showToast('Configurações salvas!','success');
        });
};

// Sortable
function initSortable() {
    if (typeof Sortable === 'undefined') return;
    
    var modulosList = document.getElementById('modulos-list');
    if (modulosList) {
        new Sortable(modulosList, {
            animation: 150,
            handle: '.item-drag',
            ghostClass: 'sortable-ghost',
            chosenClass: 'sortable-chosen',
            onEnd: function() {
                var items = [];
                modulosList.querySelectorAll('.modulo-item').forEach(function(el) {
                    items.push(el.dataset.id);
                });
                saveOrder(items, 'modulo');
            }
        });
        
        document.querySelectorAll('.aulas-list').forEach(function(list) {
            new Sortable(list, {
                animation: 150,
                handle: '.item-drag',
                ghostClass: 'sortable-ghost',
                chosenClass: 'sortable-chosen',
                onEnd: function() {
                    var items = [];
                    list.querySelectorAll('.item-row').forEach(function(el) {
                        items.push(el.dataset.id);
                    });
                    saveOrder(items, 'aula');
                }
            });
        });
    }
}

document.addEventListener('DOMContentLoaded', initSortable);

function saveOrder(items, tipo) {
    fetch(razAdmin.ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=raz_reorder&nonce=' + razAdmin.nonce + '&tipo=' + tipo + '&items=' + JSON.stringify(items)
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) showToast('Ordem atualizada!', 'success');
    });
}
<?php endif;?>
</script>
