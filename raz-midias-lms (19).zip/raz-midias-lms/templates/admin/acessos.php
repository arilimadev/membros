<?php
/**
 * Admin: Acessos com filtros e paginação
 */
$per_page = 20;
$current_page = isset($_GET['pag']) ? max(1, intval($_GET['pag'])) : 1;
$filter_status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'todos';
$offset = ($current_page - 1) * $per_page;

$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title'));

// Buscar todos os usuários para select com busca
$all_users = get_users(array('orderby' => 'display_name', 'order' => 'ASC', 'number' => 500));
?>

<div class="admin-header">
    <h2>Gerenciar Acessos</h2>
</div>

<!-- Tabs de status -->
<div class="tabs">
    <a href="<?php echo add_query_arg('status', 'todos', remove_query_arg('pag')); ?>" class="tab <?php echo $filter_status === 'todos' ? 'active' : ''; ?>">Todos</a>
    <a href="<?php echo add_query_arg('status', 'ativos', remove_query_arg('pag')); ?>" class="tab <?php echo $filter_status === 'ativos' ? 'active' : ''; ?>">Ativos</a>
    <a href="<?php echo add_query_arg('status', 'expirados', remove_query_arg('pag')); ?>" class="tab <?php echo $filter_status === 'expirados' ? 'active' : ''; ?>">Expirados</a>
</div>

<!-- Form Liberar Acesso -->
<div class="form-card" style="max-width:700px;margin-bottom:32px;">
    <h3 style="margin-bottom:20px;">Liberar Acesso Manual</h3>
    <form id="form-acesso">
        <div class="form-row">
            <div class="form-group">
                <label>Aluno *</label>
                <div class="searchable-select">
                    <input type="text" id="user-search" placeholder="Digite para buscar por email..." autocomplete="off">
                    <input type="hidden" name="user_id" id="user_id">
                    <div class="searchable-dropdown" id="user-dropdown"></div>
                </div>
            </div>
            <div class="form-group">
                <label>Curso *</label>
                <select name="curso_id" required>
                    <option value="">Selecione...</option>
                    <?php foreach ($cursos as $c) : ?>
                    <option value="<?php echo $c->ID; ?>"><?php echo esc_html($c->post_title); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Dias de Acesso</label>
                <input type="number" name="dias" value="365" min="1">
            </div>
            <div class="form-group">
                <label>&nbsp;</label>
                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;padding:12px 0;">
                    <input type="checkbox" name="vitalicio" value="1"> Acesso Vitalício
                </label>
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Liberar Acesso</button>
    </form>
</div>

<h3 style="margin-bottom:16px;">Acessos <?php echo $filter_status === 'ativos' ? 'Ativos' : ($filter_status === 'expirados' ? 'Expirados' : ''); ?></h3>

<?php
// Buscar acessos
global $wpdb;
$acessos_raw = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_curso_acesso_%' ORDER BY umeta_id DESC");

// Filtrar por status
$acessos_filtered = array();
foreach ($acessos_raw as $a) {
    $uid = $a->user_id;
    $cid = str_replace('_raz_curso_acesso_', '', $a->meta_key);
    $data = maybe_unserialize($a->meta_value);
    $u = get_userdata($uid);
    $c = get_post($cid);
    if (!$u || !$c) continue;
    
    $ativo = raz_lms_user_has_access($uid, $cid);
    
    if ($filter_status === 'ativos' && !$ativo) continue;
    if ($filter_status === 'expirados' && $ativo) continue;
    
    $acessos_filtered[] = array(
        'user' => $u,
        'curso' => $c,
        'data' => $data,
        'ativo' => $ativo
    );
}

$total_acessos = count($acessos_filtered);
$total_pages = ceil($total_acessos / $per_page);
$acessos_page = array_slice($acessos_filtered, $offset, $per_page);
?>

<?php if (empty($acessos_page)) : ?>
<div class="empty-state">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
    <h3>Nenhum acesso <?php echo $filter_status !== 'todos' ? $filter_status : ''; ?></h3>
</div>
<?php else : ?>
<table class="data-table">
    <thead>
        <tr>
            <th>Aluno</th>
            <th>Curso</th>
            <th>Início</th>
            <th>Expiração</th>
            <th>Status</th>
            <th>Ação</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($acessos_page as $acesso) : 
            $u = $acesso['user'];
            $c = $acesso['curso'];
            $data = $acesso['data'];
            $ativo = $acesso['ativo'];
        ?>
        <tr>
            <td>
                <strong><?php echo esc_html($u->display_name); ?></strong>
                <br><small style="color:var(--muted);"><?php echo esc_html($u->user_email); ?></small>
            </td>
            <td><?php echo esc_html($c->post_title); ?></td>
            <td style="color:var(--muted);"><?php echo isset($data['inicio']) ? date_i18n('d/m/Y', strtotime($data['inicio'])) : '-'; ?></td>
            <td>
                <?php if (isset($data['vitalicio']) && $data['vitalicio']) : ?>
                <span class="badge badge-success">Vitalício</span>
                <?php else : ?>
                <?php echo isset($data['expiracao']) ? date_i18n('d/m/Y', strtotime($data['expiracao'])) : '-'; ?>
                <?php endif; ?>
            </td>
            <td>
                <span class="badge <?php echo $ativo ? 'badge-success' : 'badge-danger'; ?>">
                    <?php echo $ativo ? 'Ativo' : 'Expirado'; ?>
                </span>
            </td>
            <td>
                <button class="btn btn-sm btn-danger" onclick="revokeAccess(<?php echo $u->ID; ?>,<?php echo $c->ID; ?>)">Revogar</button>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<!-- Pagination -->
<?php if ($total_pages > 1) : ?>
<div class="pagination">
    <?php if ($current_page > 1) : ?>
    <a href="<?php echo add_query_arg('pag', $current_page - 1); ?>" class="btn btn-sm btn-secondary">← Anterior</a>
    <?php endif; ?>
    
    <span class="pagination-info">Página <?php echo $current_page; ?> de <?php echo $total_pages; ?> (<?php echo $total_acessos; ?> registros)</span>
    
    <?php if ($current_page < $total_pages) : ?>
    <a href="<?php echo add_query_arg('pag', $current_page + 1); ?>" class="btn btn-sm btn-secondary">Próxima →</a>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php endif; ?>

<script>
// Searchable user select
var allUsers = <?php echo json_encode(array_map(function($u) {
    return array('id' => $u->ID, 'name' => $u->display_name, 'email' => $u->user_email);
}, $all_users)); ?>;

var userSearch = document.getElementById('user-search');
var userDropdown = document.getElementById('user-dropdown');
var userIdInput = document.getElementById('user_id');

userSearch.addEventListener('focus', function() {
    showUserDropdown('');
});

userSearch.addEventListener('input', function() {
    showUserDropdown(this.value.toLowerCase());
});

document.addEventListener('click', function(e) {
    if (!e.target.closest('.searchable-select')) {
        userDropdown.classList.remove('show');
    }
});

function showUserDropdown(filter) {
    var html = '';
    var count = 0;
    allUsers.forEach(function(u) {
        if (count >= 50) return;
        if (filter && !u.email.toLowerCase().includes(filter) && !u.name.toLowerCase().includes(filter)) return;
        html += '<div class="searchable-option" onclick="selectUser(' + u.id + ', \'' + escapeHtml(u.name) + '\', \'' + escapeHtml(u.email) + '\')">' + escapeHtml(u.name) + ' <small style="color:var(--muted);">(' + escapeHtml(u.email) + ')</small></div>';
        count++;
    });
    if (!html) html = '<div style="padding:10px 16px;color:var(--muted);">Nenhum usuário encontrado</div>';
    userDropdown.innerHTML = html;
    userDropdown.classList.add('show');
}

function selectUser(id, name, email) {
    userIdInput.value = id;
    userSearch.value = name + ' (' + email + ')';
    userDropdown.classList.remove('show');
}

function escapeHtml(str) {
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// Form submit
document.getElementById('form-acesso').onsubmit = function(e) {
    e.preventDefault();
    if (!userIdInput.value) {
        showToast('Selecione um aluno', 'error');
        return;
    }
    var fd = new FormData(this);
    fd.append('action', 'raz_grant_access');
    fd.append('nonce', razAdmin.nonce);
    
    fetch(razAdmin.ajaxurl, { method: 'POST', body: fd })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                showToast('Acesso liberado!', 'success');
                setTimeout(function() { location.reload(); }, 1000);
            } else {
                showToast(data.data.message || 'Erro', 'error');
            }
        });
};

function revokeAccess(userId, cursoId) {
    if (!confirm('Revogar acesso deste aluno?')) return;
    fetch(razAdmin.ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=raz_revoke_access&nonce=' + razAdmin.nonce + '&user_id=' + userId + '&curso_id=' + cursoId
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            showToast('Acesso revogado!', 'success');
            setTimeout(function() { location.reload(); }, 1000);
        }
    });
}
</script>
