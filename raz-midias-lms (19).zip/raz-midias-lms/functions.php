<?php
/**
 * Raz Midias LMS Theme Functions
 * @package RazMidiasLMS
 * @version 1.0.0
 */

defined('ABSPATH') || exit;

define('RAZ_LMS_VERSION', '1.0.0');
define('RAZ_LMS_DIR', get_template_directory());
define('RAZ_LMS_URI', get_template_directory_uri());

// Setup do tema
function raz_lms_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_image_size('raz-course-thumb', 800, 450, true);
    add_image_size('raz-course-card', 400, 225, true);
    add_theme_support('html5', array('search-form','comment-form','gallery','caption','style','script'));
    register_nav_menus(array('primary' => 'Menu Principal','footer' => 'Menu Rodapé'));
    add_theme_support('editor-styles');
    add_theme_support('responsive-embeds');
}
add_action('after_setup_theme', 'raz_lms_setup');

// Scripts e Styles
function raz_lms_scripts() {
    wp_enqueue_style('raz-google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap', array(), null);
    wp_enqueue_style('raz-lms-style', get_stylesheet_uri(), array(), RAZ_LMS_VERSION);
    wp_enqueue_script('raz-lms-main', RAZ_LMS_URI . '/assets/js/main.js', array('jquery'), RAZ_LMS_VERSION, true);
    
    if (is_singular('aula')) {
        wp_enqueue_script('raz-lms-player', RAZ_LMS_URI . '/assets/js/player.js', array('jquery'), RAZ_LMS_VERSION, true);
    }
    
    wp_localize_script('raz-lms-main', 'razLMS', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('raz_lms_nonce'),
        'strings' => array(
            'loading' => 'Carregando...',
            'error' => 'Ocorreu um erro. Tente novamente.',
            'lessonComplete' => 'Aula concluída!',
        ),
    ));
}
add_action('wp_enqueue_scripts', 'raz_lms_scripts');

// Registrar CPTs
function raz_lms_register_post_types() {
    // CPT: Cursos
    register_post_type('curso', array(
        'labels' => array(
            'name' => 'Cursos', 'singular_name' => 'Curso',
            'add_new' => 'Adicionar Novo', 'add_new_item' => 'Adicionar Novo Curso',
            'edit_item' => 'Editar Curso', 'new_item' => 'Novo Curso',
            'view_item' => 'Ver Curso', 'search_items' => 'Buscar Cursos',
            'not_found' => 'Nenhum curso encontrado', 'menu_name' => 'Cursos',
        ),
        'public' => true, 'has_archive' => true, 'show_in_menu' => true,
        'menu_position' => 5, 'menu_icon' => 'dashicons-welcome-learn-more',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'rewrite' => array('slug' => 'cursos'), 'show_in_rest' => true,
    ));
    
    // CPT: Módulos
    register_post_type('modulo', array(
        'labels' => array(
            'name' => 'Módulos', 'singular_name' => 'Módulo',
            'add_new' => 'Adicionar Novo', 'add_new_item' => 'Adicionar Novo Módulo',
            'edit_item' => 'Editar Módulo', 'menu_name' => 'Módulos',
        ),
        'public' => true, 'has_archive' => false,
        'show_in_menu' => 'edit.php?post_type=curso',
        'supports' => array('title'), 'rewrite' => array('slug' => 'modulos'),
        'show_in_rest' => true,
    ));
    
    // CPT: Aulas
    register_post_type('aula', array(
        'labels' => array(
            'name' => 'Aulas', 'singular_name' => 'Aula',
            'add_new' => 'Adicionar Nova', 'add_new_item' => 'Adicionar Nova Aula',
            'edit_item' => 'Editar Aula', 'menu_name' => 'Aulas',
        ),
        'public' => true, 'has_archive' => false,
        'show_in_menu' => 'edit.php?post_type=curso',
        'supports' => array('title', 'editor'), 'rewrite' => array('slug' => 'aulas'),
        'show_in_rest' => true,
    ));
}
add_action('init', 'raz_lms_register_post_types');

// Meta Boxes
function raz_lms_register_meta_boxes() {
    add_meta_box('raz_modulo_curso', 'Curso', 'raz_lms_modulo_curso_callback', 'modulo', 'side', 'high');
    add_meta_box('raz_modulo_ordem', 'Ordem', 'raz_lms_modulo_ordem_callback', 'modulo', 'side');
    add_meta_box('raz_aula_modulo', 'Módulo', 'raz_lms_aula_modulo_callback', 'aula', 'side', 'high');
    add_meta_box('raz_aula_tipo', 'Tipo de Aula', 'raz_lms_aula_tipo_callback', 'aula', 'normal', 'high');
    add_meta_box('raz_aula_conteudo', 'Conteúdo da Aula', 'raz_lms_aula_conteudo_callback', 'aula', 'normal', 'high');
    add_meta_box('raz_aula_ordem', 'Ordem', 'raz_lms_aula_ordem_callback', 'aula', 'side');
    add_meta_box('raz_curso_integracao', 'Integração e Configurações', 'raz_lms_curso_integracao_callback', 'curso', 'side');
}
add_action('add_meta_boxes', 'raz_lms_register_meta_boxes');

// Callback: Módulo -> Curso
function raz_lms_modulo_curso_callback($post) {
    wp_nonce_field('raz_lms_modulo_meta', 'raz_lms_modulo_nonce');
    $curso_id = get_post_meta($post->ID, '_raz_modulo_curso', true);
    $cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC'));
    
    echo '<select name="raz_modulo_curso" style="width:100%">';
    echo '<option value="">Selecione um curso</option>';
    foreach ($cursos as $curso) {
        echo '<option value="' . $curso->ID . '" ' . selected($curso_id, $curso->ID, false) . '>' . esc_html($curso->post_title) . '</option>';
    }
    echo '</select>';
}

// Callback: Ordem do Módulo
function raz_lms_modulo_ordem_callback($post) {
    $ordem = get_post_meta($post->ID, '_raz_modulo_ordem', true) ?: 0;
    echo '<input type="number" name="raz_modulo_ordem" value="' . intval($ordem) . '" min="0" style="width:100%">';
}

// Callback: Aula -> Módulo
function raz_lms_aula_modulo_callback($post) {
    wp_nonce_field('raz_lms_aula_meta', 'raz_lms_aula_nonce');
    $modulo_id = get_post_meta($post->ID, '_raz_aula_modulo', true);
    $cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC'));
    
    echo '<select name="raz_aula_modulo" style="width:100%">';
    echo '<option value="">Selecione um módulo</option>';
    foreach ($cursos as $curso) {
        $modulos = raz_lms_get_modulos($curso->ID);
        if (!empty($modulos)) {
            echo '<optgroup label="' . esc_attr($curso->post_title) . '">';
            foreach ($modulos as $modulo) {
                echo '<option value="' . $modulo->ID . '" ' . selected($modulo_id, $modulo->ID, false) . '>' . esc_html($modulo->post_title) . '</option>';
            }
            echo '</optgroup>';
        }
    }
    echo '</select>';
}

// Callback: Tipo de Aula
function raz_lms_aula_tipo_callback($post) {
    $tipo = get_post_meta($post->ID, '_raz_aula_tipo', true) ?: 'video';
    $tipos = array('video' => 'Vídeo + Texto', 'texto' => 'Apenas Texto', 'audio' => 'Áudio + Texto');
    
    echo '<div style="display:flex;gap:20px;padding:10px 0;">';
    foreach ($tipos as $value => $label) {
        echo '<label style="display:flex;align-items:center;gap:5px;cursor:pointer;">';
        echo '<input type="radio" name="raz_aula_tipo" value="' . $value . '" ' . checked($tipo, $value, false) . '>' . $label;
        echo '</label>';
    }
    echo '</div>';
}

// Callback: Conteúdo da Aula
function raz_lms_aula_conteudo_callback($post) {
    $tipo = get_post_meta($post->ID, '_raz_aula_tipo', true) ?: 'video';
    $video_url = get_post_meta($post->ID, '_raz_aula_video_url', true);
    $video_provider = get_post_meta($post->ID, '_raz_aula_video_provider', true) ?: 'youtube';
    $audio_url = get_post_meta($post->ID, '_raz_aula_audio_url', true);
    $duracao = get_post_meta($post->ID, '_raz_aula_duracao', true);
    ?>
    <div class="raz-conteudo-wrapper">
        <div class="raz-campo-video" style="<?php echo $tipo !== 'video' ? 'display:none;' : ''; ?>margin-bottom:20px;">
            <h4 style="margin:0 0 10px;">Configurações do Vídeo</h4>
            <p>
                <label><strong>Provedor de Vídeo:</strong></label><br>
                <select name="raz_aula_video_provider" style="width:100%;max-width:400px;">
                    <option value="youtube" <?php selected($video_provider, 'youtube'); ?>>YouTube</option>
                    <option value="vimeo" <?php selected($video_provider, 'vimeo'); ?>>Vimeo</option>
                    <option value="panda" <?php selected($video_provider, 'panda'); ?>>Panda Video</option>
                    <option value="bunny" <?php selected($video_provider, 'bunny'); ?>>Bunny Stream</option>
                    <option value="custom" <?php selected($video_provider, 'custom'); ?>>URL Direta (MP4)</option>
                </select>
            </p>
            <p>
                <label><strong>URL do Vídeo:</strong></label><br>
                <input type="url" name="raz_aula_video_url" value="<?php echo esc_url($video_url); ?>" style="width:100%;" placeholder="https://...">
            </p>
        </div>
        
        <div class="raz-campo-audio" style="<?php echo $tipo !== 'audio' ? 'display:none;' : ''; ?>margin-bottom:20px;">
            <h4 style="margin:0 0 10px;">Configurações do Áudio</h4>
            <p>
                <label><strong>URL do Áudio (MP3):</strong></label><br>
                <input type="url" name="raz_aula_audio_url" value="<?php echo esc_url($audio_url); ?>" style="width:100%;" placeholder="https://...">
            </p>
        </div>
        
        <div class="raz-campo-duracao" style="<?php echo $tipo === 'texto' ? 'display:none;' : ''; ?>">
            <p>
                <label><strong>Duração:</strong></label><br>
                <input type="text" name="raz_aula_duracao" value="<?php echo esc_attr($duracao); ?>" style="width:100px;" placeholder="00:00">
            </p>
        </div>
    </div>
    
    <script>
    jQuery(function($) {
        $('input[name="raz_aula_tipo"]').on('change', function() {
            var tipo = $(this).val();
            $('.raz-campo-video, .raz-campo-audio, .raz-campo-duracao').hide();
            if (tipo === 'video') { $('.raz-campo-video, .raz-campo-duracao').show(); }
            else if (tipo === 'audio') { $('.raz-campo-audio, .raz-campo-duracao').show(); }
        });
    });
    </script>
    <?php
}

// Callback: Ordem da Aula
function raz_lms_aula_ordem_callback($post) {
    $ordem = get_post_meta($post->ID, '_raz_aula_ordem', true) ?: 0;
    echo '<input type="number" name="raz_aula_ordem" value="' . intval($ordem) . '" min="0" style="width:100%">';
}

// Callback: Integração Curso
function raz_lms_curso_integracao_callback($post) {
    wp_nonce_field('raz_lms_curso_meta', 'raz_lms_curso_nonce');
    $kiwify_id = get_post_meta($post->ID, '_raz_curso_kiwify_id', true);
    $dias_acesso = get_post_meta($post->ID, '_raz_curso_dias_acesso', true) ?: 365;
    $vitalicio = get_post_meta($post->ID, '_raz_curso_vitalicio', true);
    ?>
    <p>
        <label><strong>ID do Produto Kiwify:</strong></label><br>
        <input type="text" name="raz_curso_kiwify_id" value="<?php echo esc_attr($kiwify_id); ?>" style="width:100%;">
    </p>
    <p>
        <label><strong>Dias de Acesso Padrão:</strong></label><br>
        <input type="number" name="raz_curso_dias_acesso" value="<?php echo intval($dias_acesso); ?>" min="1" style="width:100%;">
    </p>
    <p>
        <label><input type="checkbox" name="raz_curso_vitalicio" value="1" <?php checked($vitalicio, '1'); ?>> Acesso Vitalício</label>
    </p>
    <?php
}

// Salvar Meta Boxes
function raz_lms_save_meta_boxes($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    
    // Módulo
    if (isset($_POST['raz_lms_modulo_nonce']) && wp_verify_nonce($_POST['raz_lms_modulo_nonce'], 'raz_lms_modulo_meta')) {
        if (isset($_POST['raz_modulo_curso'])) update_post_meta($post_id, '_raz_modulo_curso', sanitize_text_field($_POST['raz_modulo_curso']));
        if (isset($_POST['raz_modulo_ordem'])) update_post_meta($post_id, '_raz_modulo_ordem', intval($_POST['raz_modulo_ordem']));
    }
    
    // Aula
    if (isset($_POST['raz_lms_aula_nonce']) && wp_verify_nonce($_POST['raz_lms_aula_nonce'], 'raz_lms_aula_meta')) {
        if (isset($_POST['raz_aula_modulo'])) update_post_meta($post_id, '_raz_aula_modulo', sanitize_text_field($_POST['raz_aula_modulo']));
        if (isset($_POST['raz_aula_ordem'])) update_post_meta($post_id, '_raz_aula_ordem', intval($_POST['raz_aula_ordem']));
        if (isset($_POST['raz_aula_tipo'])) update_post_meta($post_id, '_raz_aula_tipo', sanitize_text_field($_POST['raz_aula_tipo']));
        if (isset($_POST['raz_aula_video_url'])) update_post_meta($post_id, '_raz_aula_video_url', esc_url_raw($_POST['raz_aula_video_url']));
        if (isset($_POST['raz_aula_video_provider'])) update_post_meta($post_id, '_raz_aula_video_provider', sanitize_text_field($_POST['raz_aula_video_provider']));
        if (isset($_POST['raz_aula_audio_url'])) update_post_meta($post_id, '_raz_aula_audio_url', esc_url_raw($_POST['raz_aula_audio_url']));
        if (isset($_POST['raz_aula_duracao'])) update_post_meta($post_id, '_raz_aula_duracao', sanitize_text_field($_POST['raz_aula_duracao']));
    }
    
    // Curso
    if (isset($_POST['raz_lms_curso_nonce']) && wp_verify_nonce($_POST['raz_lms_curso_nonce'], 'raz_lms_curso_meta')) {
        if (isset($_POST['raz_curso_kiwify_id'])) update_post_meta($post_id, '_raz_curso_kiwify_id', sanitize_text_field($_POST['raz_curso_kiwify_id']));
        if (isset($_POST['raz_curso_dias_acesso'])) update_post_meta($post_id, '_raz_curso_dias_acesso', intval($_POST['raz_curso_dias_acesso']));
        update_post_meta($post_id, '_raz_curso_vitalicio', isset($_POST['raz_curso_vitalicio']) ? '1' : '');
    }
}
add_action('save_post', 'raz_lms_save_meta_boxes');

// Funções Auxiliares
function raz_lms_get_modulos($curso_id) {
    return get_posts(array(
        'post_type' => 'modulo', 'posts_per_page' => -1,
        'meta_query' => array(array('key' => '_raz_modulo_curso', 'value' => $curso_id)),
        'meta_key' => '_raz_modulo_ordem', 'orderby' => 'meta_value_num', 'order' => 'ASC',
    ));
}

function raz_lms_get_aulas($modulo_id) {
    return get_posts(array(
        'post_type' => 'aula', 'posts_per_page' => -1,
        'meta_query' => array(array('key' => '_raz_aula_modulo', 'value' => $modulo_id)),
        'meta_key' => '_raz_aula_ordem', 'orderby' => 'meta_value_num', 'order' => 'ASC',
    ));
}

function raz_lms_get_curso_from_aula($aula_id) {
    $modulo_id = get_post_meta($aula_id, '_raz_aula_modulo', true);
    if (!$modulo_id) return null;
    $curso_id = get_post_meta($modulo_id, '_raz_modulo_curso', true);
    return $curso_id ? get_post($curso_id) : null;
}

function raz_lms_get_modulo_from_aula($aula_id) {
    $modulo_id = get_post_meta($aula_id, '_raz_aula_modulo', true);
    return $modulo_id ? get_post($modulo_id) : null;
}

function raz_lms_get_all_aulas($curso_id) {
    $modulos = raz_lms_get_modulos($curso_id);
    $aulas = array();
    foreach ($modulos as $modulo) {
        $modulo_aulas = raz_lms_get_aulas($modulo->ID);
        foreach ($modulo_aulas as $aula) {
            $aula->modulo = $modulo;
            $aulas[] = $aula;
        }
    }
    return $aulas;
}

function raz_lms_get_adjacent_aulas($aula_id) {
    $curso = raz_lms_get_curso_from_aula($aula_id);
    if (!$curso) return array('prev' => null, 'next' => null);
    
    $todas_aulas = raz_lms_get_all_aulas($curso->ID);
    $prev = null; $next = null;
    
    foreach ($todas_aulas as $index => $aula) {
        if ($aula->ID == $aula_id) {
            if ($index > 0) $prev = $todas_aulas[$index - 1];
            if ($index < count($todas_aulas) - 1) $next = $todas_aulas[$index + 1];
            break;
        }
    }
    return array('prev' => $prev, 'next' => $next);
}

function raz_lms_count_aulas($curso_id) {
    return count(raz_lms_get_all_aulas($curso_id));
}

// Sistema de Progresso
function raz_lms_complete_lesson($user_id, $aula_id) {
    $completed = get_user_meta($user_id, '_raz_completed_lessons', true) ?: array();
    if (!in_array($aula_id, $completed)) {
        $completed[] = $aula_id;
        update_user_meta($user_id, '_raz_completed_lessons', $completed);
        
        // Verificar se completou o curso e enviar email
        $curso = raz_lms_get_curso_from_aula($aula_id);
        if ($curso && function_exists('raz_lms_check_completion_email')) {
            raz_lms_check_completion_email($user_id, $curso->ID);
        }
    }
    return true;
}

function raz_lms_is_lesson_completed($user_id, $aula_id) {
    $completed = get_user_meta($user_id, '_raz_completed_lessons', true);
    return is_array($completed) && in_array($aula_id, $completed);
}

function raz_lms_get_course_progress($user_id, $curso_id) {
    $aulas = raz_lms_get_all_aulas($curso_id);
    $total = count($aulas);
    if ($total == 0) return array('total' => 0, 'completed' => 0, 'percent' => 0);
    
    $completed = 0;
    foreach ($aulas as $aula) {
        if (raz_lms_is_lesson_completed($user_id, $aula->ID)) $completed++;
    }
    return array('total' => $total, 'completed' => $completed, 'percent' => round(($completed / $total) * 100));
}

function raz_lms_get_module_progress($user_id, $modulo_id) {
    $aulas = raz_lms_get_aulas($modulo_id);
    $total = count($aulas);
    if ($total == 0) return array('total' => 0, 'completed' => 0, 'percent' => 0);
    
    $completed = 0;
    foreach ($aulas as $aula) {
        if (raz_lms_is_lesson_completed($user_id, $aula->ID)) $completed++;
    }
    return array('total' => $total, 'completed' => $completed, 'percent' => round(($completed / $total) * 100));
}

// AJAX: Marcar aula concluída
function raz_lms_ajax_complete_lesson() {
    check_ajax_referer('raz_lms_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error(array('message' => 'Você precisa estar logado.'));
    
    $aula_id = isset($_POST['aula_id']) ? intval($_POST['aula_id']) : 0;
    if (!$aula_id || get_post_type($aula_id) !== 'aula') wp_send_json_error(array('message' => 'Aula inválida.'));
    
    raz_lms_complete_lesson(get_current_user_id(), $aula_id);
    $adjacent = raz_lms_get_adjacent_aulas($aula_id);
    
    wp_send_json_success(array(
        'message' => 'Aula concluída!',
        'next_url' => $adjacent['next'] ? get_permalink($adjacent['next']->ID) : '',
    ));
}
add_action('wp_ajax_raz_complete_lesson', 'raz_lms_ajax_complete_lesson');

// Sistema de Acesso por Tempo
function raz_lms_user_has_access($user_id, $curso_id) {
    if (user_can($user_id, 'manage_options')) return true;
    
    $acesso = get_user_meta($user_id, '_raz_curso_acesso_' . $curso_id, true);
    if (!$acesso) return false;
    if (isset($acesso['vitalicio']) && $acesso['vitalicio']) return true;
    if (isset($acesso['expiracao'])) {
        $expiracao = strtotime($acesso['expiracao']);
        if ($expiracao && $expiracao < time()) return false;
    }
    return true;
}

function raz_lms_get_access_expiration($user_id, $curso_id) {
    $acesso = get_user_meta($user_id, '_raz_curso_acesso_' . $curso_id, true);
    if (!$acesso) return null;
    if (isset($acesso['vitalicio']) && $acesso['vitalicio']) return 'vitalicio';
    return isset($acesso['expiracao']) ? $acesso['expiracao'] : null;
}

function raz_lms_grant_access($user_id, $curso_id, $dias = 365, $vitalicio = false) {
    $acesso = array('inicio' => date('Y-m-d'), 'vitalicio' => $vitalicio);
    if (!$vitalicio) $acesso['expiracao'] = date('Y-m-d', strtotime('+' . $dias . ' days'));
    update_user_meta($user_id, '_raz_curso_acesso_' . $curso_id, $acesso);
    
    // Disparar hook para email de boas-vindas
    do_action('raz_lms_access_granted', $user_id, $curso_id);
    
    return true;
}

function raz_lms_renew_access($user_id, $curso_id, $dias = 365) {
    $acesso = get_user_meta($user_id, '_raz_curso_acesso_' . $curso_id, true);
    if (!$acesso) return raz_lms_grant_access($user_id, $curso_id, $dias);
    if (isset($acesso['vitalicio']) && $acesso['vitalicio']) return true;
    
    $expiracao_atual = isset($acesso['expiracao']) ? strtotime($acesso['expiracao']) : time();
    if ($expiracao_atual < time()) $expiracao_atual = time();
    $acesso['expiracao'] = date('Y-m-d', strtotime('+' . $dias . ' days', $expiracao_atual));
    update_user_meta($user_id, '_raz_curso_acesso_' . $curso_id, $acesso);
    return true;
}

function raz_lms_revoke_access($user_id, $curso_id) {
    delete_user_meta($user_id, '_raz_curso_acesso_' . $curso_id);
    return true;
}

function raz_lms_get_user_courses($user_id) {
    $cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC'));
    $user_courses = array();
    
    foreach ($cursos as $curso) {
        if (raz_lms_user_has_access($user_id, $curso->ID)) {
            $curso->acesso = get_user_meta($user_id, '_raz_curso_acesso_' . $curso->ID, true);
            $curso->progresso = raz_lms_get_course_progress($user_id, $curso->ID);
            $user_courses[] = $curso;
        }
    }
    return $user_courses;
}

// Proteção de Conteúdo
function raz_lms_protect_content() {
    if (is_singular('aula') || is_singular('modulo')) {
        if (!is_user_logged_in()) {
            wp_redirect(wp_login_url(get_permalink()));
            exit;
        }
        
        global $post;
        $curso = null;
        
        if (is_singular('aula')) {
            $curso = raz_lms_get_curso_from_aula($post->ID);
        } elseif (is_singular('modulo')) {
            $curso_id = get_post_meta($post->ID, '_raz_modulo_curso', true);
            $curso = $curso_id ? get_post($curso_id) : null;
        }
        
        if ($curso && !raz_lms_user_has_access(get_current_user_id(), $curso->ID)) {
            include(RAZ_LMS_DIR . '/templates/access-blocked.php');
            exit;
        }
    }
}
add_action('template_redirect', 'raz_lms_protect_content');

// Incluir arquivos
require_once RAZ_LMS_DIR . '/inc/helpers.php';
require_once RAZ_LMS_DIR . '/inc/shortcodes.php';
require_once RAZ_LMS_DIR . '/inc/ajax-handlers.php';
require_once RAZ_LMS_DIR . '/inc/frontend-admin.php';
require_once RAZ_LMS_DIR . '/inc/woocommerce.php';
require_once RAZ_LMS_DIR . '/inc/emails.php';
require_once RAZ_LMS_DIR . '/inc/user-tracking.php';
require_once RAZ_LMS_DIR . '/inc/kiwify-webhook.php';
require_once RAZ_LMS_DIR . '/inc/notifications.php';
require_once RAZ_LMS_DIR . '/inc/email-reminders.php';
require_once RAZ_LMS_DIR . '/inc/content-versioning.php';
require_once RAZ_LMS_DIR . '/inc/course-tools.php';

if (is_admin()) {
    require_once RAZ_LMS_DIR . '/inc/admin.php';
}

// AJAX: Buscar dados da aula (para edição)
function raz_lms_ajax_get_aula() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $aula_id = intval($_GET['aula_id']);
    $aula = get_post($aula_id);
    
    if (!$aula || $aula->post_type !== 'aula') {
        wp_send_json_error(array('message' => 'Aula não encontrada'));
    }
    
    wp_send_json_success(array(
        'id' => $aula->ID,
        'titulo' => $aula->post_title,
        'conteudo' => $aula->post_content,
        'modulo_id' => get_post_meta($aula_id, '_raz_aula_modulo', true),
        'ordem' => get_post_meta($aula_id, '_raz_aula_ordem', true) ?: 0,
        'tipo' => get_post_meta($aula_id, '_raz_aula_tipo', true) ?: 'video',
        'video_url' => get_post_meta($aula_id, '_raz_aula_video_url', true),
        'video_provider' => get_post_meta($aula_id, '_raz_aula_video_provider', true) ?: 'youtube',
        'audio_url' => get_post_meta($aula_id, '_raz_aula_audio_url', true),
        'duracao' => get_post_meta($aula_id, '_raz_aula_duracao', true),
    ));
}
add_action('wp_ajax_raz_get_aula', 'raz_lms_ajax_get_aula');

// AJAX: Revogar acesso
function raz_lms_ajax_revoke_access() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $user_id = intval($_POST['user_id']);
    $curso_id = intval($_POST['curso_id']);
    
    raz_lms_revoke_access($user_id, $curso_id);
    
    wp_send_json_success(array('message' => 'Acesso revogado!'));
}
add_action('wp_ajax_raz_revoke_access', 'raz_lms_ajax_revoke_access');

// Webhook Kiwify
add_action('rest_api_init', function() {
    register_rest_route('raz-lms/v1', '/kiwify', array(
        'methods' => 'POST',
        'callback' => 'raz_lms_kiwify_webhook',
        'permission_callback' => '__return_true',
    ));
});

function raz_lms_kiwify_webhook() {
    $payload = json_decode(file_get_contents('php://input'), true);
    if (!$payload) return new WP_REST_Response(array('error' => 'Invalid payload'), 400);
    
    $event = isset($payload['event']) ? $payload['event'] : '';
    
    if (in_array($event, array('order_approved', 'subscription_renewed'))) {
        raz_lms_process_kiwify_purchase($payload);
    } elseif (in_array($event, array('subscription_canceled', 'refund'))) {
        raz_lms_process_kiwify_cancel($payload);
    }
    
    return new WP_REST_Response(array('success' => true), 200);
}

function raz_lms_process_kiwify_purchase($payload) {
    $customer = isset($payload['Customer']) ? $payload['Customer'] : array();
    $product = isset($payload['Product']) ? $payload['Product'] : array();
    
    $email = isset($customer['email']) ? sanitize_email($customer['email']) : '';
    $nome = isset($customer['full_name']) ? sanitize_text_field($customer['full_name']) : '';
    $product_id = isset($product['product_id']) ? sanitize_text_field($product['product_id']) : '';
    
    if (!$email) return false;
    
    $user = get_user_by('email', $email);
    
    if (!$user) {
        $username = sanitize_user(strtok($email, '@'));
        $password = wp_generate_password(12, false);
        $counter = 1;
        $original = $username;
        while (username_exists($username)) { $username = $original . $counter++; }
        
        $user_id = wp_create_user($username, $password, $email);
        if (is_wp_error($user_id)) return false;
        
        wp_update_user(array('ID' => $user_id, 'display_name' => $nome));
        wp_new_user_notification($user_id, null, 'user');
    } else {
        $user_id = $user->ID;
    }
    
    // Buscar curso pelo ID Kiwify
    $cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => 1, 'meta_key' => '_raz_curso_kiwify_id', 'meta_value' => $product_id));
    
    if (!empty($cursos)) {
        $curso_id = $cursos[0]->ID;
        $dias = get_post_meta($curso_id, '_raz_curso_dias_acesso', true) ?: 365;
        $vitalicio = get_post_meta($curso_id, '_raz_curso_vitalicio', true);
        
        if (raz_lms_user_has_access($user_id, $curso_id)) {
            raz_lms_renew_access($user_id, $curso_id, $dias);
        } else {
            raz_lms_grant_access($user_id, $curso_id, $dias, $vitalicio);
        }
    }
    return true;
}

function raz_lms_process_kiwify_cancel($payload) {
    $customer = isset($payload['Customer']) ? $payload['Customer'] : array();
    $product = isset($payload['Product']) ? $payload['Product'] : array();
    
    $email = isset($customer['email']) ? sanitize_email($customer['email']) : '';
    $product_id = isset($product['product_id']) ? sanitize_text_field($product['product_id']) : '';
    
    if (!$email) return false;
    
    $user = get_user_by('email', $email);
    if (!$user) return false;
    
    $cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => 1, 'meta_key' => '_raz_curso_kiwify_id', 'meta_value' => $product_id));
    
    if (!empty($cursos)) {
        raz_lms_revoke_access($user->ID, $cursos[0]->ID);
    }
    return true;
}

// Flush rewrite rules
function raz_lms_activate() {
    raz_lms_register_post_types();
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'raz_lms_activate');

// Redirecionar login padrão para página customizada
function raz_lms_login_redirect() {
    global $pagenow;
    if ($pagenow === 'wp-login.php' && !isset($_GET['action'])) {
        $login_page = get_page_by_path('login');
        if ($login_page) {
            wp_redirect(get_permalink($login_page->ID));
            exit;
        }
    }
}
add_action('init', 'raz_lms_login_redirect');

// Redirecionar após login
function raz_lms_redirect_after_login($redirect_to, $request, $user) {
    if (isset($user->roles) && is_array($user->roles)) {
        if (in_array('administrator', $user->roles)) {
            return home_url('/gestao-cursos/');
        }
        return home_url('/meus-cursos/');
    }
    return $redirect_to;
}
add_filter('login_redirect', 'raz_lms_redirect_after_login', 10, 3);

/**
 * Esconder admin bar para todos os usuários
 */
add_filter('show_admin_bar', '__return_false');
