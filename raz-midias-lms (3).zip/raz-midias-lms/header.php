<?php
/**
 * Header Template
 * @package RazMidiasLMS
 */

// Define cor padrão para botões no header público
$header_btn_color = '#667eea'; 
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
    
    <style>
        /* CSS DOS MODAIS DE PERFIL E SENHA */
        .raz-custom-modal {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.7);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 999999;
            backdrop-filter: blur(4px);
        }
        .raz-modal-content {
            background: #fff;
            width: 90%;
            max-width: 400px;
            border-radius: 16px;
            padding: 30px;
            position: relative;
            color: #333;
            box-shadow: 0 20px 40px rgba(0,0,0,0.3);
            animation: razFadeUp 0.3s ease-out;
        }
        @keyframes razFadeUp {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        .raz-modal-close {
            position: absolute;
            top: 15px; right: 15px;
            cursor: pointer;
            font-size: 24px;
            color: #999;
            line-height: 1;
        }
        .raz-modal-title {
            font-size: 1.25rem;
            font-weight: 700;
            margin-bottom: 20px;
            text-align: center;
            color: #111;
        }
        .raz-modal-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            padding: 12px;
            margin-bottom: 12px;
            border-radius: 8px;
            text-decoration: none !important;
            font-weight: 600;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: 0.2s;
        }
        .btn-modal-primary { background: #0891b2; color: #fff !important; }
        .btn-modal-secondary { background: #f1f5f9; color: #475569 !important; }
        .btn-modal-outline { background: transparent; color: #ef4444 !important; border: 1px solid #fee2e2; }
        
        .raz-form-field { margin-bottom: 15px; position: relative; }
        .raz-form-field label { display: block; font-size: 13px; margin-bottom: 6px; color: #64748b; font-weight: 600; }
        .raz-form-field input { 
            width: 100%; padding: 12px; border: 1px solid #e2e8f0; border-radius: 8px; 
            font-size: 14px; box-sizing: border-box;
            padding-right: 40px;
        }
        .raz-password-toggle {
            position: absolute; 
            right: 12px; 
            top: 36px; 
            cursor: pointer; 
            color: #94a3b8;
        }
        .raz-profile-trigger { cursor: pointer; transition: 0.2s; }
        .raz-profile-trigger:hover { opacity: 0.8; }
    </style>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php 
/* LÓGICA DE EXIBIÇÃO DOS CABEÇALHOS */

if ( is_singular('aula') ) {
    // Cenário 1: Player de Aula -> Sem header global
    
} elseif ( is_page_template('page-meus-cursos.php') || is_singular('curso') ) {
    // Cenário 2: HEADER DO ALUNO (DASHBOARD)
    $user = wp_get_current_user();
?>
    <div class="raz-dashboard-header">
        <div class="raz-dashboard-header-content">
            <div class="raz-dashboard-logo">
                <?php
                if (has_custom_logo()) {
                    the_custom_logo();
                } else {
                    echo '<a href="' . home_url() . '" class="site-title-link">' . get_bloginfo('name') . '</a>';
                }
                ?>
            </div>

            <button class="raz-menu-toggle" onclick="toggleDashboardMenu()" aria-label="Abrir menu">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
            </button>

            <div class="raz-dashboard-user-wrapper" id="dashboard-menu">
                <div class="raz-dashboard-user-info raz-profile-trigger" onclick="razOpenModal('razModalProfile')">
                    <div class="raz-user-details">
                        <span class="raz-user-name"><?php echo esc_html($user->display_name); ?></span>
                        <span class="raz-user-email"><?php echo esc_html($user->user_email); ?></span>
                    </div>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-left:5px; color:#94a3b8;"><polyline points="6 9 12 15 18 9"></polyline></svg>
                </div>
                
                <nav class="raz-dashboard-nav">
                    <a href="<?php echo home_url('/meus-cursos'); ?>" class="raz-nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg>
                        Meus Cursos
                    </a>

                    <a href="javascript:void(0)" class="raz-nav-link raz-mobile-only" onclick="razOpenModal('razModalProfile')" style="display:none;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                        Meu Perfil
                    </a>
                    
                    <a href="<?php echo wp_logout_url(home_url()); ?>" class="raz-logout-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                        Sair
                    </a>
                </nav>
            </div>
        </div>
    </div>

    <div id="razModalProfile" class="raz-custom-modal" onclick="if(event.target == this) razCloseModal('razModalProfile')">
        <div class="raz-modal-content">
            <span class="raz-modal-close" onclick="razCloseModal('razModalProfile')">&times;</span>
            <div class="raz-modal-title">Configurações de Perfil</div>
            
            <div style="text-align:center; margin-bottom: 25px;">
                <div style="font-weight:700; font-size:18px; color:#111;"><?php echo esc_html($user->display_name); ?></div>
                <div style="font-size:14px; color:#64748b;"><?php echo esc_html($user->user_email); ?></div>
            </div>

             
            
            <button type="button" class="raz-modal-btn btn-modal-primary" onclick="razOpenPasswordFromProfile()">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                Alterar Minha Senha
            </button>

            <a href="<?php echo wp_logout_url(home_url()); ?>" class="raz-modal-btn btn-modal-outline">Sair da Conta</a>
        </div>
    </div>

    <div id="razModalPassword" class="raz-custom-modal" onclick="if(event.target == this) razCloseModal('razModalPassword')">
        <div class="raz-modal-content">
            <span class="raz-modal-close" onclick="razCloseModal('razModalPassword')">&times;</span>
            <div class="raz-modal-title">Alterar Senha</div>
            
            <form id="razFormPassword">
                <div class="raz-form-field">
                    <label>Nova Senha</label>
                    <input type="password" id="raz_new_pass" required minlength="6" placeholder="Mínimo 6 caracteres">
                    <span class="raz-password-toggle" onclick="razTogglePass('raz_new_pass', this)">
                        <i class="dashicons dashicons-visibility"></i>
                    </span>
                </div>
                <div class="raz-form-field">
                    <label>Confirmar Nova Senha</label>
                    <input type="password" id="raz_confirm_pass" required minlength="6" placeholder="Repita a senha">
                    <span class="raz-password-toggle" onclick="razTogglePass('raz_confirm_pass', this)">
                        <i class="dashicons dashicons-visibility"></i>
                    </span>
                </div>
                <div id="razPassMsg" style="display:none; font-size:13px; margin-bottom:15px; text-align:center; padding:10px; border-radius:6px;"></div>
                <button type="submit" class="raz-modal-btn btn-modal-primary" id="razBtnSavePass">Salvar Nova Senha</button>
            </form>
        </div>
    </div>

    <script>
        function toggleDashboardMenu() {
            var menu = document.getElementById('dashboard-menu');
            if(menu) menu.classList.toggle('open');
        }

        function razOpenModal(id) {
            document.getElementById(id).style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }

        function razCloseModal(id) {
            document.getElementById(id).style.display = 'none';
            document.body.style.overflow = 'auto';
        }

        function razOpenPasswordFromProfile() {
            razCloseModal('razModalProfile');
            setTimeout(() => razOpenModal('razModalPassword'), 100);
        }

        function razTogglePass(id, el) {
            const input = document.getElementById(id);
            const icon = el.querySelector('i');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('dashicons-visibility', 'dashicons-hidden');
            } else {
                input.type = 'password';
                icon.classList.replace('dashicons-hidden', 'dashicons-visibility');
            }
        }

        document.addEventListener('click', function(event) {
            var menu = document.getElementById('dashboard-menu');
            var toggle = document.querySelector('.raz-menu-toggle');
            if (menu && menu.classList.contains('open') && !menu.contains(event.target) && !toggle.contains(event.target)) {
                menu.classList.remove('open');
            }
        });

        jQuery(document).ready(function($) {
            $('#razFormPassword').on('submit', function(e) {
                e.preventDefault();
                const p1 = $('#raz_new_pass').val();
                const p2 = $('#raz_confirm_pass').val();
                const $msg = $('#razPassMsg');
                const $btn = $('#razBtnSavePass');

                if (p1 !== p2) {
                    $msg.css({'color': '#b91c1c', 'background': '#fef2f2', 'display': 'block'}).text('As senhas não coincidem.');
                    return;
                }

                $btn.text('Processando...').prop('disabled', true);

                $.ajax({
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    type: 'POST',
                    data: {
                        action: 'raz_change_user_password',
                        nonce: '<?php echo wp_create_nonce('raz_pass_nonce'); ?>',
                        password: p1
                    },
                    success: function(res) {
                        if (res.success) {
                            $msg.css({'color': '#15803d', 'background': '#f0fdf4', 'display': 'block'}).text('Senha alterada com sucesso!');
                            setTimeout(() => location.reload(), 1500);
                        } else {
                            $msg.css({'color': '#b91c1c', 'background': '#fef2f2', 'display': 'block'}).text(res.data.message || 'Erro ao salvar.');
                            $btn.text('Salvar Nova Senha').prop('disabled', false);
                        }
                    },
                    error: function() {
                        $msg.css({'color': '#b91c1c', 'background': '#fef2f2', 'display': 'block'}).text('Erro na requisição (400).');
                        $btn.text('Salvar Nova Senha').prop('disabled', false);
                    }
                });
            });
        });
    </script>

    <style>
        .raz-dashboard-header { background: #fff; border-bottom: 1px solid #e2e8f0; position: sticky; top: 0; z-index: 999; }
        .raz-dashboard-header-content { max-width: 1200px; margin: 0 auto; padding: 0 20px; display: flex; justify-content: space-between; align-items: center; height: 70px; }
        .site-title-link { font-weight: 700; font-size: 1.5rem; color: #000 !important; text-decoration: none; }
        .raz-menu-toggle { display: none; background: none; border: none; color: #000; cursor: pointer; padding: 8px; }
        .raz-dashboard-user-wrapper { display: flex; align-items: center; gap: 24px; }
        .raz-dashboard-user-info { display: flex; align-items: center; gap: 12px; padding: 6px 12px; border-radius: 8px; background: #f8fafc; }
        .raz-user-details { display: flex; flex-direction: column; align-items: flex-start; line-height: 1.3; }
        .raz-user-name { font-weight: 600; color: #000; font-size: 14px; }
        .raz-user-email { font-size: 11px; color: #94a3b8; }
        .raz-dashboard-nav { display: flex; align-items: center; gap: 16px; }
        .raz-nav-link, .raz-logout-btn { display: flex; align-items: center; gap: 6px; text-decoration: none; font-size: 14px; font-weight: 500; }
        @media (min-width: 769px) {
            .raz-nav-link { background-color: #0891b2; color: #fff !important; padding: 8px 16px; border-radius: 6px; }
            .raz-nav-link:hover { background-color: #0e7490; transform: translateY(-1px); }
        }
        .raz-logout-btn { color: #ef4444; }
        @media (max-width: 768px) {
            .raz-menu-toggle { display: block; }
            .raz-mobile-only { display: flex !important; }
            .raz-dashboard-user-wrapper { display: none; position: absolute; top: 70px; left: 0; width: 100%; background: #fff; flex-direction: column; padding: 20px; gap: 16px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
            .raz-dashboard-user-wrapper.open { display: flex; }
            .raz-dashboard-user-info { display: none; }
            .raz-dashboard-nav { flex-direction: column; width: 100%; }
            .raz-nav-link, .raz-logout-btn { padding: 12px; border-radius: 6px; background: #f8fafc; color: #475569 !important; width: 100%; }
        }
    </style>

<?php 
} else { 
?>
    <header class="raz-site-header">
        <div class="raz-header-content">
            <div class="raz-header-logo">
                <?php if (has_custom_logo()) : the_custom_logo(); else : ?>
                    <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a>
                <?php endif; ?>
            </div>
            <div class="raz-header-actions">
                <?php if (is_user_logged_in()) : ?>
                    <a href="<?php echo esc_url(home_url('/meus-cursos/')); ?>" class="raz-header-btn" style="background:<?php echo esc_attr($header_btn_color); ?>; color:#fff; padding:8px 16px; border-radius:6px; text-decoration:none;">Meus Cursos</a>
                    <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" style="margin-left:10px; color:#666; text-decoration:none;">Sair</a>
                <?php else : ?>
                    <a href="<?php echo esc_url(wp_login_url()); ?>" class="raz-header-btn" style="background:<?php echo esc_attr($header_btn_color); ?>; color:#fff; padding:8px 16px; border-radius:6px; text-decoration:none;">Entrar</a>
                <?php endif; ?>
            </div>
        </div>
    </header>
<?php } ?>