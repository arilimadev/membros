<?php
/**
 * Admin: Configurações Gerais
 * Design: Premium UX/UI
 */
$login_logo = get_option('raz_lms_login_logo', '');
$login_bg_color = get_option('raz_lms_login_bg_color', '#667eea');
$login_btn_color = get_option('raz_lms_login_btn_color', '#4f46e5');

$mensagem_sucesso = '';
if (isset($_POST['save_config']) && wp_verify_nonce($_POST['config_nonce'], 'raz_save_config')) {
    update_option('raz_lms_login_logo', esc_url_raw($_POST['login_logo']));
    update_option('raz_lms_login_bg_color', sanitize_hex_color($_POST['login_bg_color']));
    update_option('raz_lms_login_btn_color', sanitize_hex_color($_POST['login_btn_color']));
    
    $login_logo = get_option('raz_lms_login_logo', '');
    $login_bg_color = get_option('raz_lms_login_bg_color', '#667eea');
    $login_btn_color = get_option('raz_lms_login_btn_color', '#4f46e5');
    
    $mensagem_sucesso = '
    <div class="raz-alert raz-alert-success">
        <div class="raz-alert-icon"><svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg></div>
        <div class="raz-alert-content">Configurações salvas com sucesso!</div>
    </div>';
}
?>

<style>
    :root {
        --raz-primary: #0891b2;
        --raz-primary-hover: #0e7490;
        --raz-bg: #f8fafc;
        --raz-surface: #ffffff;
        --raz-border: #e2e8f0;
        --raz-text: #1e293b;
        --raz-text-muted: #64748b;
        --raz-text-light: #94a3b8;
        --raz-success-bg: #ecfdf5;
        --raz-success-text: #059669;
        --raz-success-border: #10b981;
        --raz-danger-text: #dc2626;
        --raz-radius: 8px;
        --raz-radius-lg: 12px;
        --raz-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        --transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .raz-admin-container {
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        color: var(--raz-text);
        max-width: 800px;
        margin: 20px auto 60px;
    }

    /* Headings */
    .raz-page-header {
        margin-bottom: 32px;
        padding-bottom: 20px;
        border-bottom: 1px solid var(--raz-border);
    }
    .raz-page-title {
        font-size: 24px;
        font-weight: 700;
        color: var(--raz-text);
        margin: 0 0 8px 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .raz-page-title svg { color: var(--raz-primary); }
    .raz-page-desc { font-size: 14px; color: var(--raz-text-muted); margin: 0; }

    /* Alerts */
    .raz-alert {
        padding: 16px;
        border-radius: var(--raz-radius);
        margin-bottom: 24px;
        display: flex;
        align-items: center;
        gap: 12px;
        border-left: 4px solid transparent;
        animation: slideIn 0.3s ease-out;
    }
    .raz-alert-success { background: var(--raz-success-bg); border-left-color: var(--raz-success-border); color: #064e3b; }
    @keyframes slideIn { from { transform: translateY(-10px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

    /* Cards */
    .raz-card {
        background: var(--raz-surface);
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius-lg);
        padding: 24px;
        box-shadow: var(--raz-shadow);
        margin-bottom: 24px;
    }
    .raz-section-title {
        font-size: 16px;
        font-weight: 700;
        color: var(--raz-text);
        margin: 0 0 20px 0;
        display: flex;
        align-items: center;
        gap: 8px;
        padding-bottom: 12px;
        border-bottom: 1px solid #f1f5f9;
    }

    /* Form Elements */
    .raz-form-group { margin-bottom: 24px; }
    .raz-label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 8px; color: var(--raz-text); }
    
    .raz-input {
        width: 100%; padding: 10px 12px;
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius);
        font-size: 14px; background: #fff;
        transition: var(--transition);
        color: var(--raz-text);
    }
    .raz-input:focus { border-color: var(--raz-primary); outline: none; box-shadow: 0 0 0 3px rgba(8, 145, 178, 0.15); }

    /* Color Picker Component */
    .raz-color-picker-wrapper {
        display: flex;
        align-items: center;
        gap: 12px;
        background: #f8fafc;
        padding: 8px;
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius);
    }
    .raz-color-input {
        width: 48px; height: 38px;
        padding: 0; border: none;
        background: none; cursor: pointer;
        border-radius: 4px;
    }
    .raz-color-text {
        flex: 1;
        border: none;
        background: transparent;
        font-family: monospace;
        font-size: 14px;
        color: var(--raz-text);
        text-transform: uppercase;
    }
    .raz-color-text:focus { outline: none; }

    /* Logo Upload Component */
    .raz-logo-wrapper {
        display: flex;
        gap: 20px;
        align-items: flex-start;
    }
    .raz-logo-preview {
        width: 200px; height: 100px;
        background-color: #f1f5f9;
        border: 2px dashed #cbd5e1;
        border-radius: var(--raz-radius);
        display: flex; align-items: center; justify-content: center;
        overflow: hidden;
        position: relative;
        transition: var(--transition);
        background-image: linear-gradient(45deg, #f1f5f9 25%, #fff 25%, #fff 75%, #f1f5f9 75%, #f1f5f9), linear-gradient(45deg, #f1f5f9 25%, #fff 25%, #fff 75%, #f1f5f9 75%, #f1f5f9);
        background-position: 0 0, 10px 10px;
        background-size: 20px 20px;
    }
    .raz-logo-preview img { max-width: 100%; max-height: 100%; object-fit: contain; }
    .raz-logo-preview.has-image { border-style: solid; border-color: var(--raz-border); background: #fff; }
    
    .raz-logo-actions { display: flex; flex-direction: column; gap: 8px; }

    /* Buttons */
    .raz-btn {
        display: inline-flex; align-items: center; justify-content: center;
        padding: 10px 20px; font-size: 14px; font-weight: 600;
        border-radius: var(--raz-radius); cursor: pointer;
        border: 1px solid transparent; transition: var(--transition);
        gap: 8px; text-decoration: none;
    }
    .raz-btn-primary { background: var(--raz-primary); color: white; box-shadow: 0 1px 2px rgba(0,0,0,0.1); }
    .raz-btn-primary:hover { background: var(--raz-primary-hover); transform: translateY(-1px); }
    
    .raz-btn-secondary { background: white; border-color: var(--raz-border); color: var(--raz-text); }
    .raz-btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; color: var(--raz-primary); }
    
    .raz-btn-text-danger { background: none; color: var(--raz-danger-text); font-size: 13px; padding: 4px; height: auto; }
    .raz-btn-text-danger:hover { text-decoration: underline; }

    .raz-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
</style>

<div class="raz-admin-container">
    
    <div class="raz-page-header">
        <h2 class="raz-page-title">
            <svg width="28" height="28" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
            Configurações do Sistema
        </h2>
        <p class="raz-page-desc">Personalize a aparência da área de login e outros aspectos visuais da sua plataforma.</p>
    </div>

    <?php echo $mensagem_sucesso; ?>

    <form method="post">
        <?php wp_nonce_field('raz_save_config', 'config_nonce'); ?>
        
        <div class="raz-card">
            <div class="raz-section-title">
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                Personalização Visual (Login)
            </div>
            
            <div class="raz-form-group">
                <label class="raz-label">Logo da Área de Login</label>
                <div class="raz-logo-wrapper">
                    <div class="raz-logo-preview <?php echo $login_logo ? 'has-image' : ''; ?>" id="logo-preview-box">
                        <?php if ($login_logo) : ?>
                            <img src="<?php echo esc_url($login_logo); ?>" alt="Logo">
                        <?php else : ?>
                            <span style="color:var(--raz-text-muted);font-size:12px;">Sem logo definida</span>
                        <?php endif; ?>
                    </div>
                    <div class="raz-logo-actions">
                        <input type="hidden" name="login_logo" id="login_logo" value="<?php echo esc_url($login_logo); ?>">
                        <button type="button" class="raz-btn raz-btn-secondary" onclick="selectLogo()">
                            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path></svg>
                            Selecionar Imagem
                        </button>
                        <?php if ($login_logo) : ?>
                            <button type="button" class="raz-btn-text-danger" id="remove-logo-btn" onclick="removeLogo()">Remover logo</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="raz-grid-2">
                <div class="raz-form-group">
                    <label class="raz-label">Cor de Fundo da Página</label>
                    <div class="raz-color-picker-wrapper">
                        <input type="color" name="login_bg_color" id="login_bg_color" value="<?php echo esc_attr($login_bg_color); ?>" class="raz-color-input">
                        <input type="text" value="<?php echo esc_attr($login_bg_color); ?>" class="raz-color-text" onchange="document.getElementById('login_bg_color').value=this.value" id="login_bg_hex">
                    </div>
                </div>
                
                <div class="raz-form-group">
                    <label class="raz-label">Cor do Botão de Login</label>
                    <div class="raz-color-picker-wrapper">
                        <input type="color" name="login_btn_color" id="login_btn_color" value="<?php echo esc_attr($login_btn_color); ?>" class="raz-color-input">
                        <input type="text" value="<?php echo esc_attr($login_btn_color); ?>" class="raz-color-text" onchange="document.getElementById('login_btn_color').value=this.value" id="login_btn_hex">
                    </div>
                </div>
            </div>
        </div>
        
        <div style="text-align:right;">
            <button type="submit" name="save_config" class="raz-btn raz-btn-primary">
                <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                Salvar Configurações
            </button>
        </div>
    </form>
</div>

<script>
// Sincronização de Cores
document.getElementById('login_bg_color').addEventListener('input', function() {
    document.getElementById('login_bg_hex').value = this.value;
});
document.getElementById('login_btn_color').addEventListener('input', function() {
    document.getElementById('login_btn_hex').value = this.value;
});

// Lógica de Upload de Mídia
var mediaFrame = null;

function selectLogo() {
    if (typeof wp === 'undefined' || typeof wp.media === 'undefined') {
        alert('A biblioteca de mídia do WordPress não carregou corretamente. Por favor, recarregue a página.');
        return;
    }
    
    if (!mediaFrame) {
        mediaFrame = wp.media({
            title: 'Selecionar Logo para Login',
            button: { text: 'Usar esta imagem' },
            multiple: false,
            library: { type: 'image' }
        });
        
        mediaFrame.on('select', function() {
            var att = mediaFrame.state().get('selection').first().toJSON();
            document.getElementById('login_logo').value = att.url;
            
            var previewBox = document.getElementById('logo-preview-box');
            previewBox.innerHTML = '<img src="' + att.url + '" style="max-height:100%;max-width:100%;">';
            previewBox.classList.add('has-image');
            
            // Mostrar botão remover se não existir
            if(!document.getElementById('remove-logo-btn')) {
                var btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'raz-btn-text-danger';
                btn.id = 'remove-logo-btn';
                btn.innerText = 'Remover logo';
                btn.onclick = removeLogo;
                document.querySelector('.raz-logo-actions').appendChild(btn);
            }
        });
    }
    
    mediaFrame.open();
}

function removeLogo() {
    document.getElementById('login_logo').value = '';
    var previewBox = document.getElementById('logo-preview-box');
    previewBox.innerHTML = '<span style="color:var(--raz-text-muted);font-size:12px;">Sem logo definida</span>';
    previewBox.classList.remove('has-image');
    
    var btn = document.getElementById('remove-logo-btn');
    if(btn) btn.remove();
}
</script>