<?php
/**
 * Admin: Acessos com filtros e paginação
 * @package RazMidiasLMS
 */

// Verifica permissão básica
if (!current_user_can('manage_options')) {
    wp_die('Acesso negado.');
}

// URL Base Limpa (Para redirecionamentos e links)
global $wp;
$current_url = home_url(add_query_arg(array(), $wp->request));
// Se estiver em uma subpasta/slug, pegamos a URI atual sem parâmetros
$base_url = strtok($_SERVER["REQUEST_URI"], '?');

// ==============================================================================
// 1. LÓGICA DE PROCESSAMENTO (SALVAR E REVOGAR)
// ==============================================================================

$mensagem_feedback = '';

// --- A. ADICIONAR ACESSO (LIBERAR) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['raz_action']) && $_POST['raz_action'] == 'add_access_manual') {
    
    if (isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'raz_grant_access_manual')) {
        
        $email_user = sanitize_email($_POST['user_email']); 
        $curso_id = intval($_POST['curso_id']);
        $tipo_acesso = sanitize_text_field($_POST['tipo']);
        $dias = intval($_POST['dias']);
        
        $user = get_user_by('email', $email_user);
        
        if ($user && $curso_id) {
            // 1. Salvar o Acesso ao Curso
            $cursos_atuais = get_user_meta($user->ID, '_raz_user_cursos', true);
            if (!is_array($cursos_atuais)) $cursos_atuais = array();
            
            if (!in_array($curso_id, $cursos_atuais)) {
                $cursos_atuais[] = $curso_id;
                update_user_meta($user->ID, '_raz_user_cursos', $cursos_atuais);
            }

            // 2. Salvar Detalhes
            $dados_acesso = [
                'inicio' => current_time('mysql'),
                'tipo' => $tipo_acesso,
                'vitalicio' => ($tipo_acesso === 'vitalicio')
            ];
            
            if ($tipo_acesso !== 'vitalicio') {
                $dados_acesso['expiracao'] = date('Y-m-d H:i:s', strtotime("+$dias days"));
            }
            update_user_meta($user->ID, '_raz_curso_acesso_' . $curso_id, $dados_acesso);

            // 3. Salvar Grupos (CORREÇÃO: Usando estrutura V2)
            $grupos_keys = [];
            if (isset($_POST['grupos_selecionados']) && is_array($_POST['grupos_selecionados'])) {
                $grupos_keys = array_map('sanitize_text_field', $_POST['grupos_selecionados']);
            }

            if (function_exists('raz_set_user_grupos_in_curso')) {
                // Usa a função oficial do sistema de grupos
                raz_set_user_grupos_in_curso($user->ID, $curso_id, $grupos_keys);
            } else {
                // Fallback manual caso a função não esteja carregada
                $all_grupos = get_user_meta($user->ID, '_raz_user_grupos_cursos', true);
                if (!is_array($all_grupos)) $all_grupos = [];
                
                if (empty($grupos_keys)) {
                    unset($all_grupos['curso_' . $curso_id]);
                } else {
                    $all_grupos['curso_' . $curso_id] = $grupos_keys;
                }
                update_user_meta($user->ID, '_raz_user_grupos_cursos', $all_grupos);
            }

            // Remove meta antigo para evitar conflitos visuais
            delete_user_meta($user->ID, '_raz_user_grupos_' . $curso_id);

            // 4. Disparar e-mail de boas-vindas
            do_action('raz_lms_access_granted', $user->ID, $curso_id, null);

            $mensagem_feedback = '
            <div class="raz-alert raz-alert-success">
                <div class="raz-alert-icon"><svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></div>
                <div class="raz-alert-content">
                    <strong>Sucesso!</strong>
                    <p>Acesso liberado para <strong>' . esc_html($user->display_name) . '</strong> e e-mail enviado.</p>
                </div>
            </div>';
        } else {
            $mensagem_feedback = '
            <div class="raz-alert raz-alert-error">
                <div class="raz-alert-icon"><svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></div>
                <div class="raz-alert-content">
                    <strong>Erro!</strong>
                    <p>Usuário não encontrado ou curso inválido.</p>
                </div>
            </div>';
        }
    }
}

// --- B. REVOGAR ACESSO (CORRIGIDO) ---
if (isset($_GET['action']) && $_GET['action'] == 'revoke' && isset($_GET['user']) && isset($_GET['curso'])) {
    
    if (isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'revoke_access')) {
        $r_user_id = intval($_GET['user']);
        $r_curso_id = intval($_GET['curso']);
        
        $cursos_atuais = get_user_meta($r_user_id, '_raz_user_cursos', true);
        
        // Remove do array de cursos
        if (is_array($cursos_atuais)) {
            $pos = array_search($r_curso_id, $cursos_atuais);
            if ($pos !== false) {
                unset($cursos_atuais[$pos]);
                update_user_meta($r_user_id, '_raz_user_cursos', array_values($cursos_atuais));
            }
        }
        
        // Remove metadados de acesso
        delete_user_meta($r_user_id, '_raz_curso_acesso_' . $r_curso_id);
        
        // Remove grupos (Estrutura V2)
        if (function_exists('raz_set_user_grupos_in_curso')) {
            raz_set_user_grupos_in_curso($r_user_id, $r_curso_id, []);
        } else {
            $all_grupos = get_user_meta($r_user_id, '_raz_user_grupos_cursos', true);
            if (is_array($all_grupos) && isset($all_grupos['curso_' . $r_curso_id])) {
                unset($all_grupos['curso_' . $r_curso_id]);
                update_user_meta($r_user_id, '_raz_user_grupos_cursos', $all_grupos);
            }
        }
        
        // Remove metadados antigos (limpeza)
        delete_user_meta($r_user_id, '_raz_user_grupos_' . $r_curso_id);
        
        // Força um redirect via JS para limpar a URL e evitar loop ou erro
        echo '<script>window.location.href="' . esc_url($base_url) . '?status=revogado";</script>';
        exit;
    }
}

if (isset($_GET['status']) && $_GET['status'] == 'revogado') {
    $mensagem_feedback = '
    <div class="raz-alert raz-alert-success">
        <div class="raz-alert-icon"><svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></div>
        <div class="raz-alert-content">
            <strong>Ação Realizada!</strong>
            <p>O acesso foi revogado com sucesso.</p>
        </div>
    </div>';
}

// ==============================================================================
// 2. PREPARAÇÃO DE DADOS 
// ==============================================================================

$per_page = 10;
$current_page = isset($_GET['pag']) ? max(1, intval($_GET['pag'])) : 1;
$filter_status = isset($_GET['status_filter']) ? sanitize_text_field($_GET['status_filter']) : 'todos';
$search_term = isset($_GET['s_acesso']) ? sanitize_text_field($_GET['s_acesso']) : '';
$offset = ($current_page - 1) * $per_page;

$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC'));

// --- MAPA DE GRUPOS ---
$mapa_cursos_grupos = [];
foreach ($cursos as $curso) {
    $grupos_meta = get_post_meta($curso->ID, '_raz_curso_grupos', true);
    $grupos_meta = maybe_unserialize($grupos_meta);

    if (!empty($grupos_meta) && is_array($grupos_meta)) {
        foreach ($grupos_meta as $key => $data) {
            $nome_grupo = isset($data['nome']) ? $data['nome'] : ucfirst($key);
            $mapa_cursos_grupos[$curso->ID][] = [
                'id' => $key,
                'nome' => $nome_grupo
            ];
        }
    }
}

$all_users = get_users(array('orderby' => 'display_name', 'order' => 'ASC', 'number' => 500));
?>

<style>
    :root {
        --raz-primary: #0891b2;
        --raz-primary-hover: #0e7490;
        --raz-bg: #f8fafc;
        --raz-surface: #ffffff;
        --raz-border: #e2e8f0;
        --raz-text: #1e293b;
        --raz-text-muted: #64748b;
        --raz-text-light: #94a3b8;
        --raz-success-bg: #ecfdf5;
        --raz-success-text: #059669;
        --raz-success-border: #10b981;
        --raz-danger-bg: #fef2f2;
        --raz-danger-text: #dc2626;
        --raz-danger-border: #ef4444;
        --raz-info-bg: #f0f9ff;
        --raz-info-text: #0284c7;
        --raz-radius: 8px;
        --raz-radius-lg: 12px;
        --raz-shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        --raz-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        --transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .raz-admin-container {
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        color: var(--raz-text);
        max-width: 1100px;
        margin: 20px auto 60px;
    }

    /* Headings */
    .raz-page-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 24px;
        padding-bottom: 16px;
        border-bottom: 1px solid var(--raz-border);
    }
    .raz-page-title {
        font-size: 24px;
        font-weight: 700;
        color: var(--raz-text);
        margin: 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .raz-page-title svg { color: var(--raz-primary); }

    /* Alerts */
    .raz-alert {
        padding: 16px;
        border-radius: var(--raz-radius);
        margin-bottom: 24px;
        display: flex;
        align-items: flex-start;
        gap: 16px;
        box-shadow: var(--raz-shadow-sm);
        border-left: 4px solid transparent;
        animation: slideIn 0.3s ease-out;
    }
    @keyframes slideIn { from { transform: translateY(-10px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    
    .raz-alert-success { background: var(--raz-success-bg); border-left-color: var(--raz-success-border); }
    .raz-alert-success .raz-alert-icon { color: var(--raz-success-text); }
    .raz-alert-success .raz-alert-content { color: #064e3b; }
    
    .raz-alert-error { background: var(--raz-danger-bg); border-left-color: var(--raz-danger-border); }
    .raz-alert-error .raz-alert-icon { color: var(--raz-danger-text); }
    .raz-alert-error .raz-alert-content { color: #7f1d1d; }
    
    .raz-alert-content p { margin: 4px 0 0; font-size: 14px; }
    .raz-alert-content strong { display: block; font-size: 15px; }

    /* Tabs */
    .raz-nav-tabs {
        display: flex;
        gap: 4px;
        margin-bottom: 24px;
        border-bottom: 2px solid var(--raz-border);
    }
    .raz-nav-link {
        padding: 12px 24px;
        text-decoration: none;
        color: var(--raz-text-muted);
        font-weight: 600;
        font-size: 14px;
        border-bottom: 2px solid transparent;
        margin-bottom: -2px;
        transition: var(--transition);
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 8px;
        border-radius: 6px 6px 0 0;
    }
    .raz-nav-link:hover { color: var(--raz-primary); background: #f1f5f9; }
    .raz-nav-link.active { color: var(--raz-primary); border-bottom-color: var(--raz-primary); background: transparent; }
    .raz-nav-link svg { width: 18px; height: 18px; opacity: 0.7; }
    .raz-nav-link.active svg { opacity: 1; }

    /* Cards */
    .raz-card {
        background: var(--raz-surface);
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius-lg);
        padding: 24px;
        box-shadow: var(--raz-shadow);
        margin-bottom: 32px;
    }
    .raz-section-title {
        font-size: 18px;
        font-weight: 600;
        margin: 0 0 20px 0;
        color: var(--raz-text);
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .raz-section-title svg { color: var(--raz-text-muted); width: 20px; height: 20px; }

    /* Form Elements */
    .raz-form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 24px; margin-bottom: 24px; }
    .raz-form-group { margin-bottom: 0; position: relative; }
    .raz-label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 8px; color: var(--raz-text); }
    
    .raz-input-wrapper { position: relative; }
    .raz-input-icon {
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--raz-text-light);
        pointer-events: none;
    }
    
    .raz-input, .raz-select {
        width: 100%;
        padding: 10px 12px 10px 36px; /* Space for icon */
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius);
        font-size: 14px;
        background: #fff;
        transition: var(--transition);
        box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        height: 42px;
    }
    .raz-select { padding-left: 12px; /* Selects usually don't have icons inside */ }
    
    .raz-input:focus, .raz-select:focus {
        border-color: var(--raz-primary);
        outline: none;
        box-shadow: 0 0 0 3px rgba(8, 145, 178, 0.15);
    }

    /* Internal Tabs (Pills) */
    .raz-pills {
        display: inline-flex;
        background: #f1f5f9;
        padding: 4px;
        border-radius: 10px;
        margin-bottom: 24px;
        border: 1px solid var(--raz-border);
    }
    .raz-pill {
        padding: 8px 20px;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        color: var(--raz-text-muted);
        transition: var(--transition);
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .raz-pill:hover { color: var(--raz-text); }
    .raz-pill.active {
        background: white;
        color: var(--raz-primary);
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    
    .access-tab-content { display: none; animation: fadeIn 0.3s ease; }
    .access-tab-content.active { display: block; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }

    /* Buttons */
    .raz-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 10px 24px;
        font-size: 14px;
        font-weight: 600;
        border-radius: var(--raz-radius);
        cursor: pointer;
        border: 1px solid transparent;
        transition: var(--transition);
        text-decoration: none;
        gap: 8px;
        height: 42px;
    }
    .raz-btn svg { width: 18px; height: 18px; }
    
    .raz-btn-primary { 
        background: var(--raz-primary); 
        color: white; 
        box-shadow: 0 1px 2px rgba(0,0,0,0.1);
    }
    .raz-btn-primary:hover { 
        background: var(--raz-primary-hover); 
        transform: translateY(-1px);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    }
    
    .raz-btn-secondary { background: white; border-color: var(--raz-border); color: var(--raz-text); }
    .raz-btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; color: var(--raz-primary); }
    
    .raz-btn-danger { background: #fff; color: var(--raz-danger-text); border: 1px solid var(--raz-danger-bg); font-size: 13px; padding: 6px 14px; height: 32px; }
    .raz-btn-danger:hover { background: var(--raz-danger-bg); border-color: var(--raz-danger-border); }

    /* Search Component */
    .searchable-select { position: relative; }
    .searchable-dropdown {
        display: none;
        position: absolute;
        top: calc(100% + 6px);
        left: 0;
        right: 0;
        background: white;
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius);
        max-height: 260px;
        overflow-y: auto;
        z-index: 50;
        box-shadow: var(--raz-shadow);
    }
    .searchable-dropdown.show { display: block; }
    .searchable-option {
        padding: 12px 16px;
        font-size: 14px;
        cursor: pointer;
        border-bottom: 1px solid #f8fafc;
        display: flex;
        flex-direction: column;
        transition: background 0.15s;
    }
    .searchable-option:hover { background: #f0f9ff; }
    .searchable-option strong { color: var(--raz-text); font-weight: 500; }
    .searchable-option small { color: var(--raz-text-muted); font-size: 12px; margin-top: 2px; }

    /* Table */
    .raz-table-wrapper {
        background: white;
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius-lg);
        overflow: hidden;
        box-shadow: var(--raz-shadow-sm);
    }
    .raz-table { width: 100%; border-collapse: collapse; }
    .raz-table th {
        background: #f8fafc;
        padding: 16px 24px;
        text-align: left;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--raz-text-muted);
        border-bottom: 1px solid var(--raz-border);
    }
    .raz-table td {
        padding: 16px 24px;
        border-bottom: 1px solid var(--raz-border);
        color: var(--raz-text);
        font-size: 14px;
        vertical-align: middle;
    }
    .raz-table tr:last-child td { border-bottom: none; }
    .raz-table tr:hover { background: #fbfbfc; }
    
    /* Status Badges */
    .raz-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 10px;
        border-radius: 9999px;
        font-size: 12px;
        font-weight: 600;
        line-height: 1;
        letter-spacing: 0.02em;
    }
    .raz-badge svg { width: 12px; height: 12px; }
    
    .raz-badge-success { background: var(--raz-success-bg); color: var(--raz-success-text); border: 1px solid rgba(16, 185, 129, 0.2); }
    .raz-badge-danger { background: var(--raz-danger-bg); color: var(--raz-danger-text); border: 1px solid rgba(239, 68, 68, 0.2); }
    .raz-badge-info { background: var(--raz-info-bg); color: var(--raz-info-text); border: 1px solid rgba(2, 132, 199, 0.2); }
    
    .raz-user-info { display: flex; align-items: center; gap: 12px; }
    .raz-avatar-placeholder {
        width: 36px; height: 36px;
        background: #e2e8f0;
        color: #64748b;
        border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-size: 14px; font-weight: 600;
    }

    /* Utilities */
    .u-muted { color: var(--raz-text-muted); font-size: 13px; }
    .u-bold { font-weight: 600; color: var(--raz-text); }
    .u-flex-center { display: flex; align-items: center; }
    
    .pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 16px;
        margin-top: 32px;
    }
    .pagination-info { font-size: 14px; color: var(--raz-text-muted); font-variant-numeric: tabular-nums; }
    
    .empty-state {
        text-align: center;
        padding: 80px 20px;
        color: var(--raz-text-muted);
        background: white;
        border-radius: var(--raz-radius-lg);
        border: 2px dashed var(--raz-border);
    }
    .empty-state svg { width: 48px; height: 48px; color: #cbd5e1; margin-bottom: 16px; }

    /* Custom Scrollbar for dropdown */
    .searchable-dropdown::-webkit-scrollbar { width: 6px; }
    .searchable-dropdown::-webkit-scrollbar-track { background: transparent; }
    .searchable-dropdown::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }
</style>

<div class="raz-admin-container">
    
    <div class="raz-page-header">
        <h2 class="raz-page-title">
            <svg width="28" height="28" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
            Gerenciar Acessos
        </h2>
        <div class="raz-actions">
            </div>
    </div>

    <?php echo $mensagem_feedback; ?>

    <div class="raz-nav-tabs">
        <a href="?status_filter=todos" class="raz-nav-link <?php echo $filter_status === 'todos' ? 'active' : ''; ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16"></path></svg>
            Todos
        </a>
        <a href="?status_filter=ativos" class="raz-nav-link <?php echo $filter_status === 'ativos' ? 'active' : ''; ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            Ativos
        </a>
        <a href="?status_filter=expirados" class="raz-nav-link <?php echo $filter_status === 'expirados' ? 'active' : ''; ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            Expirados
        </a>
    </div>

    <div class="raz-card">
        <div class="raz-pills">
            <div class="raz-pill active" onclick="switchAccessTab('liberar')">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                Liberar Acesso
            </div>
            <div class="raz-pill" onclick="switchAccessTab('pesquisar')">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                Pesquisar Usuário
            </div>
        </div>

        <div id="tab-liberar" class="access-tab-content active">
            <h3 class="raz-section-title">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11.536 11l-2.414 4.145A2 2 0 017.382 16H6a2 2 0 01-2-2v-1.382a2 2 0 01.553-1.447l4.145-2.414L9 6.257A6 6 0 1115 7z"></path></svg>
                Liberar Acesso Manual
            </h3>
            
            <form id="form-acesso-manual" method="POST" action="">
                <input type="hidden" name="raz_action" value="add_access_manual">
                <?php wp_nonce_field('raz_grant_access_manual'); ?>

                <div class="raz-form-grid">
                    <div class="raz-form-group">
                        <label class="raz-label">Aluno *</label>
                        <div class="searchable-select">
                            <div class="raz-input-wrapper">
                                <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                                <input type="text" id="user-search" class="raz-input" placeholder="Digite nome ou email..." autocomplete="off" required>
                            </div>
                            <input type="hidden" name="user_email" id="user_email_input">
                            <div class="searchable-dropdown" id="user-dropdown"></div>
                        </div>
                    </div>
                    <div class="raz-form-group">
                        <label class="raz-label">Curso *</label>
                        <select name="curso_id" id="select-curso-manual" class="raz-select" required onchange="renderizarGruposManual(this.value)">
                            <option value="">Selecione um curso...</option>
                            <?php foreach ($cursos as $c) : ?>
                                <option value="<?php echo $c->ID; ?>"><?php echo esc_html($c->post_title); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div id="container-grupos-manual" style="margin-bottom: 24px; padding: 20px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; display:none;">
                    <label style="font-size:13px; font-weight:700; color:#475569; display:block; margin-bottom:12px;">Selecione os Grupos de Acesso (Opcional):</label>
                    <div id="lista-grupos-checkboxes" style="display:flex; flex-direction:column; gap:8px;"></div>
                </div>

                <div class="raz-form-grid">
                    <div class="raz-form-group" id="group-dias">
                        <label class="raz-label">Dias de Acesso</label>
                        <div class="raz-input-wrapper">
                            <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                            <input type="number" name="dias" id="input-dias" class="raz-input" value="365" min="1">
                        </div>
                    </div>

                    <div class="raz-form-group">
                        <label class="raz-label">Tipo de Acesso</label>
                        <select name="tipo" id="input-tipo" class="raz-select">
                            <option value="avulso">Avulso (Dias Corridos)</option>
                            <option value="vitalicio">Vitalício</option>
                            <option value="assinatura">Assinatura (Recorrente)</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="raz-btn raz-btn-primary">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    Confirmar Liberação
                </button>
            </form>
        </div>

        <div id="tab-pesquisar" class="access-tab-content">
            <h3 class="raz-section-title">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                Pesquisar Usuário (Base Global)
            </h3>
            <div class="search-user-container">
                <div class="raz-form-group">
                    <label class="raz-label">E-mail ou Nome do Usuário</label>
                    <div class="raz-input-wrapper">
                        <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                        <input type="text" id="global-user-search" class="raz-input" placeholder="Digite para buscar na base completa...">
                    </div>
                </div>
                <div id="global-search-results" style="margin-top: 15px; border: 1px solid var(--raz-border); border-radius: 8px; overflow: hidden; display:none;"></div>
            </div>
        </div>
    </div>

    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
        <h3 class="raz-section-title" style="margin:0;">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16"></path></svg>
            Lista de Acessos
        </h3>
    </div>

    <form method="get" action="" style="display:flex; gap:10px; margin-bottom:24px; max-width:650px;">
        <input type="hidden" name="status_filter" value="<?php echo esc_attr($filter_status); ?>">
        <div class="raz-input-wrapper" style="flex:1;">
            <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"></path></svg>
            <input type="text" name="s_acesso" class="raz-input" placeholder="Filtrar nesta lista por nome ou e-mail..." value="<?php echo esc_attr($search_term); ?>">
        </div>
        <button type="submit" class="raz-btn raz-btn-secondary">
            Filtrar
        </button>
        <?php if ($search_term) : ?>
            <a href="?status_filter=<?php echo $filter_status; ?>" class="raz-btn raz-btn-secondary" style="color: var(--raz-danger-text); border-color: #fecaca;">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                Limpar
            </a>
        <?php endif; ?>
    </form>

    <?php
    // Buscar acessos
    global $wpdb;
    $acessos_raw = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_curso_acesso_%' ORDER BY umeta_id DESC LIMIT 500");

    $acessos_filtered = array();
    foreach ($acessos_raw as $a) {
        $uid = $a->user_id;
        $cid = str_replace('_raz_curso_acesso_', '', $a->meta_key);
        $data = maybe_unserialize($a->meta_value);
        $u = get_userdata($uid);
        $c = get_post($cid);
        if (!$u || !$c) continue;

        if ($search_term) {
            $found_name = stripos($u->display_name, $search_term) !== false;
            $found_email = stripos($u->user_email, $search_term) !== false;
            if (!$found_name && !$found_email) continue;
        }

        $ativo = raz_lms_user_has_access($uid, $cid);

        if ($filter_status === 'ativos' && !$ativo) continue;
        if ($filter_status === 'expirados' && $ativo) continue;

        $acessos_filtered[] = array(
            'user' => $u,
            'curso' => $c,
            'data' => $data,
            'ativo' => $ativo
        );
    }

    $total_acessos = count($acessos_filtered);
    $total_pages = ceil($total_acessos / $per_page);
    $acessos_page = array_slice($acessos_filtered, $offset, $per_page);
    ?>

    <?php if (empty($acessos_page)) : ?>
        <div class="empty-state">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <h3>Nenhum acesso encontrado</h3>
            <p>Tente ajustar os filtros ou pesquisar por outro termo.</p>
        </div>
    <?php else : ?>
        <div class="raz-table-wrapper">
            <table class="raz-table">
                <thead>
                    <tr>
                        <th width="30%">Aluno</th>
                        <th width="25%">Curso</th>
                        <th>Início</th>
                        <th>Expiração / Tipo</th>
                        <th>Status</th>
                        <th style="text-align:right;">Ação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($acessos_page as $acesso) :
                        $u = $acesso['user'];
                        $c = $acesso['curso'];
                        $data = $acesso['data'];
                        $ativo = $acesso['ativo'];

                        $tipo_label = 'Avulso';
                        $is_vitalicio = isset($data['vitalicio']) && $data['vitalicio'];
                        $is_assinatura = isset($data['tipo']) && $data['tipo'] === 'assinatura';
                        
                        // Avatar com Iniciais
                        $iniciais = strtoupper(substr($u->display_name, 0, 1));
                    ?>
                        <tr>
                            <td>
                                <div class="raz-user-info">
                                    <div class="raz-avatar-placeholder"><?php echo $iniciais; ?></div>
                                    <div>
                                        <div class="u-bold"><?php echo esc_html($u->display_name); ?></div>
                                        <div class="u-muted"><?php echo esc_html($u->user_email); ?></div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="u-bold"><?php echo esc_html($c->post_title); ?></div>
                                <?php 
                                // CORREÇÃO: Leitura correta dos grupos (formato V2)
                                $grupos_aluno_keys = [];
                                if (function_exists('raz_get_user_grupos_in_curso')) {
                                    $grupos_aluno_keys = raz_get_user_grupos_in_curso($u->ID, $c->ID);
                                } else {
                                    $all_grupos = get_user_meta($u->ID, '_raz_user_grupos_cursos', true);
                                    if (is_array($all_grupos) && isset($all_grupos['curso_' . $c->ID])) {
                                        $grupos_aluno_keys = $all_grupos['curso_' . $c->ID];
                                    }
                                }

                                $todos_grupos_curso = get_post_meta($c->ID, '_raz_curso_grupos', true);
                                $todos_grupos_curso = maybe_unserialize($todos_grupos_curso);

                                if (!empty($grupos_aluno_keys) && is_array($grupos_aluno_keys) && !empty($todos_grupos_curso)) {
                                    $nomes_grupos = [];
                                    foreach ($grupos_aluno_keys as $key) {
                                        if (isset($todos_grupos_curso[$key]) && isset($todos_grupos_curso[$key]['nome'])) {
                                            $nomes_grupos[] = $todos_grupos_curso[$key]['nome'];
                                        } elseif ($key === 'padrao') {
                                            $nomes_grupos[] = 'Padrão';
                                        }
                                    }
                                    if (!empty($nomes_grupos)) {
                                        echo '<div style="margin-top:6px; font-size:12px; color:#475569; background:#f1f5f9; padding:2px 8px; border-radius:4px; display:inline-block; border:1px solid #e2e8f0;">';
                                        echo '<svg width="10" height="10" style="margin-right:4px; display:inline-block;" fill="currentColor" viewBox="0 0 20 20"><path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"></path></svg>';
                                        echo implode(', ', $nomes_grupos);
                                        echo '</div>';
                                    }
                                }
                                ?>
                            </td>
                            <td class="u-muted">
                                <?php echo isset($data['inicio']) ? date_i18n('d/m/Y', strtotime($data['inicio'])) : '-'; ?>
                            </td>
                            <td>
                                <?php if ($is_vitalicio) : ?>
                                    <span class="raz-badge raz-badge-success">
                                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                                        Vitalício
                                    </span>
                                <?php elseif ($is_assinatura) : ?>
                                    <span class="raz-badge raz-badge-info">
                                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
                                        Assinatura
                                    </span>
                                    <div class="u-muted" style="margin-top:4px; font-size:11px;">Renova: <?php echo isset($data['expiracao']) ? date_i18n('d/m/Y', strtotime($data['expiracao'])) : '-'; ?></div>
                                <?php else : ?>
                                    <span style="font-size:13px; font-variant-numeric: tabular-nums;">
                                        <?php echo isset($data['expiracao']) ? date_i18n('d/m/Y', strtotime($data['expiracao'])) : '-'; ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="raz-badge <?php echo $ativo ? 'raz-badge-success' : 'raz-badge-danger'; ?>">
                                    <?php if($ativo): ?>
                                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                        Ativo
                                    <?php else: ?>
                                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                        Expirado
                                    <?php endif; ?>
                                </span>
                            </td>
                            <td style="text-align:right;">
                                <?php 
                                $revoke_url = add_query_arg([
                                    'action' => 'revoke',
                                    'user' => $u->ID,
                                    'curso' => $c->ID,
                                    '_wpnonce' => wp_create_nonce('revoke_access')
                                ]);
                                ?>
                                <a href="<?php echo esc_url($revoke_url); ?>" 
                                   class="raz-btn raz-btn-danger"
                                   title="Revogar Acesso"
                                   onclick="return confirm('Tem certeza que deseja revogar o acesso deste aluno? Esta ação não pode ser desfeita.');">
                                   <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"></path></svg>
                                   Revogar
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1) : ?>
            <div class="pagination">
                <?php if ($current_page > 1) : ?>
                    <a href="?pag=<?php echo $current_page - 1; ?>&status_filter=<?php echo $filter_status; ?>&s_acesso=<?php echo $search_term; ?>" class="raz-btn raz-btn-secondary">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
                        Anterior
                    </a>
                <?php endif; ?>

                <span class="pagination-info">Página <strong><?php echo $current_page; ?></strong> de <?php echo $total_pages; ?></span>

                <?php if ($current_page < $total_pages) : ?>
                    <a href="?pag=<?php echo $current_page + 1; ?>&status_filter=<?php echo $filter_status; ?>&s_acesso=<?php echo $search_term; ?>" class="raz-btn raz-btn-secondary">
                        Próxima
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>

</div>

<script>
    // Dados PHP -> JS
    var mapaCursosGrupos = <?php echo json_encode($mapa_cursos_grupos); ?>;
    var allUsers = <?php echo json_encode(array_map(function($u) {
        return array('id' => $u->ID, 'name' => $u->display_name, 'email' => $u->user_email);
    }, $all_users)); ?>;

    function renderizarGruposManual(cursoId) {
        var container = document.getElementById('container-grupos-manual');
        var lista = document.getElementById('lista-grupos-checkboxes');
        lista.innerHTML = '';

        if (!cursoId || !mapaCursosGrupos || !mapaCursosGrupos[cursoId]) {
            container.style.display = 'none';
            return;
        }

        container.style.display = 'block';

        mapaCursosGrupos[cursoId].forEach(function(grupo) {
            var wrapper = document.createElement('div');
            wrapper.style.display = 'flex';
            wrapper.style.alignItems = 'center';
            wrapper.style.gap = '10px';
            wrapper.style.padding = '8px 12px';
            wrapper.style.background = 'white';
            wrapper.style.borderRadius = '6px';
            wrapper.style.border = '1px solid #e2e8f0';

            var checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.name = 'grupos_selecionados[]'; 
            checkbox.value = grupo.id;
            checkbox.id = 'grupo_manual_' + grupo.id;
            checkbox.checked = true;
            
            checkbox.style.width = '16px';
            checkbox.style.height = '16px';
            checkbox.style.flexShrink = '0';
            checkbox.style.margin = '0';
            checkbox.style.cursor = 'pointer';
            checkbox.style.accentColor = 'var(--raz-primary)';

            var label = document.createElement('label');
            label.htmlFor = 'grupo_manual_' + grupo.id;
            label.innerText = grupo.nome;
            label.style.fontSize = '14px';
            label.style.color = '#1e293b';
            label.style.lineHeight = '1.3';
            label.style.cursor = 'pointer';
            label.style.flex = '1';

            wrapper.appendChild(checkbox);
            wrapper.appendChild(label);
            lista.appendChild(wrapper);
        });
    }

    function switchAccessTab(tab) {
        document.querySelectorAll('.raz-pill').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.access-tab-content').forEach(content => content.classList.remove('active'));

        if (tab === 'liberar') {
            document.querySelector('.raz-pill:nth-child(1)').classList.add('active');
            document.getElementById('tab-liberar').classList.add('active');
        } else {
            document.querySelector('.raz-pill:nth-child(2)').classList.add('active');
            document.getElementById('tab-pesquisar').classList.add('active');
        }
    }

    var userSearch = document.getElementById('user-search');
    var userDropdown = document.getElementById('user-dropdown');
    var userEmailInput = document.getElementById('user_email_input');

    if(userSearch) {
        userSearch.addEventListener('focus', function() { showUserDropdown(''); });
        userSearch.addEventListener('input', function() { showUserDropdown(this.value.toLowerCase()); });
    }

    var globalUserSearch = document.getElementById('global-user-search');
    var globalSearchResults = document.getElementById('global-search-results');

    if(globalUserSearch) {
        globalUserSearch.addEventListener('input', function() {
            var filter = this.value.toLowerCase();
            if (filter.length < 2) {
                globalSearchResults.style.display = 'none';
                return;
            }
            var html = '';
            var found = 0;
            allUsers.forEach(function(u) {
                if (found >= 10) return;
                if (u.email.toLowerCase().includes(filter) || u.name.toLowerCase().includes(filter)) {
                    html += '<div class="searchable-option">';
                    html += '<div><strong>' + escapeHtml(u.name) + '</strong><br><small>' + escapeHtml(u.email) + '</small></div>';
                    html += '<button type="button" class="raz-btn raz-btn-secondary" style="padding:4px 10px; font-size:12px; height:auto;" onclick="selectUserForGrant(\'' + escapeHtml(u.email) + '\', \'' + escapeHtml(u.name) + '\')">Selecionar</button>';
                    html += '</div>';
                    found++;
                }
            });
            if (html) {
                globalSearchResults.innerHTML = html;
                globalSearchResults.style.display = 'block';
            } else {
                globalSearchResults.innerHTML = '<div style="padding:15px;text-align:center;color:var(--raz-text-muted);">Nenhum usuário encontrado</div>';
                globalSearchResults.style.display = 'block';
            }
        });
    }

    function selectUserForGrant(email, name) {
        selectUser(email, name);
        switchAccessTab('liberar');
        globalUserSearch.value = '';
        globalSearchResults.style.display = 'none';
    }

    document.addEventListener('click', function(e) {
        if (!e.target.closest('.searchable-select')) {
            if(userDropdown) userDropdown.classList.remove('show');
        }
    });

    function showUserDropdown(filter) {
        if(!userDropdown) return;
        var html = '';
        var count = 0;
        allUsers.forEach(function(u) {
            if (count >= 50) return;
            if (filter && !u.email.toLowerCase().includes(filter) && !u.name.toLowerCase().includes(filter)) return;
            html += '<div class="searchable-option" onclick="selectUser(\'' + escapeHtml(u.email) + '\', \'' + escapeHtml(u.name) + '\')">';
            html += '<strong>' + escapeHtml(u.name) + '</strong>';
            html += '<small>' + escapeHtml(u.email) + '</small>';
            html += '</div>';
            count++;
        });
        if (!html) html = '<div style="padding:12px 16px;color:var(--raz-text-muted);font-size:13px;">Nenhum usuário encontrado</div>';
        userDropdown.innerHTML = html;
        userDropdown.classList.add('show');
    }

    function selectUser(email, name) {
        if(userEmailInput) userEmailInput.value = email;
        if(userSearch) userSearch.value = name + ' (' + email + ')';
        if(userDropdown) userDropdown.classList.remove('show');
    }

    function escapeHtml(str) {
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    var inputTipo = document.getElementById('input-tipo');
    var groupDias = document.getElementById('group-dias');

    if (inputTipo) {
        inputTipo.addEventListener('change', function() {
            if (this.value === 'vitalicio') {
                groupDias.style.display = 'none';
            } else {
                groupDias.style.display = 'block';
            }
        });
    }
</script>