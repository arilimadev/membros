<?php
/**
 * Admin: Exportar Dados
 * Design: Premium UX/UI
 */
global $wpdb;

// 1. Parametros e Filtros
$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title'));

$filter_curso = isset($_GET['curso']) ? intval($_GET['curso']) : 0;
$filter_periodo_de = isset($_GET['periodo_de']) ? sanitize_text_field($_GET['periodo_de']) : '';
$filter_periodo_ate = isset($_GET['periodo_ate']) ? sanitize_text_field($_GET['periodo_ate']) : '';
$current_page_slug = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : 'gestao-cursos';
?>

<style>
    :root {
        --raz-primary: #0891b2;
        --raz-primary-hover: #0e7490;
        --raz-bg: #f8fafc;
        --raz-surface: #ffffff;
        --raz-border: #e2e8f0;
        --raz-text: #1e293b;
        --raz-text-muted: #64748b;
        --raz-text-light: #94a3b8;
        --raz-success-bg: #ecfdf5;
        --raz-success-text: #059669;
        --raz-radius: 8px;
        --raz-radius-lg: 12px;
        --raz-shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        --raz-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        --transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .raz-admin-container {
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        color: var(--raz-text);
        max-width: 1100px;
        margin: 20px auto 60px;
    }

    /* Headings */
    .raz-page-header {
        display: flex;
        flex-direction: column;
        margin-bottom: 32px;
        padding-bottom: 20px;
        border-bottom: 1px solid var(--raz-border);
    }
    .raz-page-title {
        font-size: 24px;
        font-weight: 700;
        color: var(--raz-text);
        margin: 0 0 8px 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .raz-page-title svg { color: var(--raz-primary); }
    .raz-page-desc {
        font-size: 14px;
        color: var(--raz-text-muted);
        margin: 0;
        max-width: 600px;
    }

    /* Cards */
    .raz-card {
        background: var(--raz-surface);
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius-lg);
        padding: 24px;
        box-shadow: var(--raz-shadow);
        margin-bottom: 32px;
    }
    
    .raz-section-title {
        font-size: 16px;
        font-weight: 600;
        color: var(--raz-text);
        margin: 0 0 20px 0;
        display: flex;
        align-items: center;
        gap: 8px;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        font-size: 12px;
        color: var(--raz-text-muted);
    }

    /* Form Grid */
    .raz-form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        align-items: end;
    }

    /* Inputs */
    .raz-label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 8px; color: var(--raz-text); }
    .raz-input-wrapper { position: relative; }
    .raz-input-icon {
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--raz-text-light);
        pointer-events: none;
    }
    
    .raz-input, .raz-select {
        width: 100%;
        padding: 10px 12px 10px 36px;
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius);
        font-size: 14px;
        background: #fff;
        transition: var(--transition);
        box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        height: 42px;
    }
    
    .raz-input:focus, .raz-select:focus {
        border-color: var(--raz-primary);
        outline: none;
        box-shadow: 0 0 0 3px rgba(8, 145, 178, 0.15);
    }

    /* Buttons */
    .raz-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 10px 20px;
        font-size: 14px;
        font-weight: 600;
        border-radius: var(--raz-radius);
        cursor: pointer;
        border: 1px solid transparent;
        transition: var(--transition);
        text-decoration: none;
        gap: 8px;
        height: 42px;
    }
    
    .raz-btn-primary { 
        background: var(--raz-primary); 
        color: white; 
        box-shadow: 0 1px 2px rgba(0,0,0,0.1);
    }
    .raz-btn-primary:hover { 
        background: var(--raz-primary-hover); 
        transform: translateY(-1px);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }
    
    .raz-btn-secondary { background: white; border-color: var(--raz-border); color: var(--raz-text); }
    .raz-btn-secondary:hover { background: #f8fafc; border-color: #cbd5e1; color: var(--raz-primary); }

    .raz-btn-success { background: var(--raz-success-text); color: white; }
    .raz-btn-success:hover { background: #047857; transform: translateY(-1px); }

    /* Export Grid Cards */
    .raz-export-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 24px;
    }

    .raz-export-card {
        background: var(--raz-surface);
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius-lg);
        padding: 24px;
        display: flex;
        flex-direction: column;
        transition: var(--transition);
        position: relative;
        overflow: hidden;
    }

    .raz-export-card:hover {
        transform: translateY(-4px);
        box-shadow: var(--raz-shadow);
        border-color: var(--raz-primary);
    }

    .raz-export-icon-bg {
        width: 48px; height: 48px;
        background: #f0f9ff;
        color: var(--raz-primary);
        border-radius: 12px;
        display: flex; align-items: center; justify-content: center;
        margin-bottom: 16px;
    }

    .raz-export-title { font-size: 16px; font-weight: 700; color: var(--raz-text); margin-bottom: 8px; }
    .raz-export-desc { font-size: 13px; color: var(--raz-text-muted); margin-bottom: 24px; line-height: 1.5; flex-grow: 1; }

    .raz-card-highlight { border-top: 4px solid var(--raz-primary); }
</style>

<div class="raz-admin-container">
    
    <div class="raz-page-header">
        <h2 class="raz-page-title">
            <svg width="28" height="28" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
            Exportar Relatórios
        </h2>
        <p class="raz-page-desc">Gere e baixe dados estratégicos em formato CSV para análise avançada no Excel ou Google Sheets.</p>
    </div>

    <div class="raz-card">
        <div class="raz-section-title">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"></path></svg>
            Configurar Filtros de Exportação
        </div>
        <form method="get" class="raz-form-grid">
            <input type="hidden" name="page" value="<?php echo esc_attr($current_page_slug); ?>">
            <input type="hidden" name="tab" value="exportar">

            <div>
                <label class="raz-label">Curso</label>
                <div class="raz-input-wrapper">
                    <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                    <select name="curso" id="filter-curso" class="raz-select">
                        <option value="">Todos os cursos</option>
                        <?php foreach ($cursos as $c) : ?>
                        <option value="<?php echo $c->ID; ?>" <?php selected($filter_curso, $c->ID); ?>><?php echo esc_html($c->post_title); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div>
                <label class="raz-label">Data Inicial</label>
                <div class="raz-input-wrapper">
                    <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                    <input type="date" name="periodo_de" id="periodo_de" class="raz-input" value="<?php echo esc_attr($filter_periodo_de); ?>">
                </div>
            </div>

            <div>
                <label class="raz-label">Data Final</label>
                <div class="raz-input-wrapper">
                    <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                    <input type="date" name="periodo_ate" id="periodo_ate" class="raz-input" value="<?php echo esc_attr($filter_periodo_ate); ?>">
                </div>
            </div>

            <div style="display:flex; gap:10px;">
                <button type="submit" class="raz-btn raz-btn-primary" style="flex:1;">
                    Aplicar Filtros
                </button>
                <a href="?page=<?php echo esc_attr($current_page_slug); ?>&tab=exportar" class="raz-btn raz-btn-secondary" title="Limpar Filtros">
                    <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </a>
            </div>
        </form>
    </div>

    <div class="raz-export-grid">
        
        <div class="raz-export-card">
            <div class="raz-export-icon-bg">
                <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
            </div>
            <div class="raz-export-title">Lista de Alunos</div>
            <div class="raz-export-desc">Dados cadastrais completos: Nome, Email, Telefone, Status da conta e Origem do cadastro.</div>
            <button class="raz-btn raz-btn-secondary" onclick="exportAlunos()">
                <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                Baixar CSV
            </button>
        </div>

        <div class="raz-export-card">
            <div class="raz-export-icon-bg">
                <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
            </div>
            <div class="raz-export-title">Progresso Acadêmico</div>
            <div class="raz-export-desc">Relatório de engajamento: Porcentagem de conclusão por aluno, total de aulas e último acesso.</div>
            <button class="raz-btn raz-btn-secondary" onclick="exportProgresso()">
                <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                Baixar CSV
            </button>
        </div>

        <div class="raz-export-card">
            <div class="raz-export-icon-bg">
                <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path></svg>
            </div>
            <div class="raz-export-title">Métricas por Aula</div>
            <div class="raz-export-desc">Análise de conteúdo: Total de conclusões por videoaula e taxa de retenção por módulo.</div>
            <button class="raz-btn raz-btn-secondary" onclick="exportConclusoes()">
                <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                Baixar CSV
            </button>
        </div>

        <div class="raz-export-card raz-card-highlight">
            <div class="raz-export-icon-bg" style="background:#ecfdf5; color:#059669;">
                <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
            </div>
            <div class="raz-export-title">Relatório Geral</div>
            <div class="raz-export-desc">Consolidado estratégico contendo todas as variáveis do sistema em um único arquivo mestre.</div>
            <button class="raz-btn raz-btn-success" onclick="exportCompleto()">
                <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                Baixar CSV Completo
            </button>
        </div>

    </div>
</div>

<script>
    var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
    var nonce = '<?php echo wp_create_nonce('raz_admin_nonce'); ?>';

    function getFilters() {
        return {
            curso: document.getElementById('filter-curso').value,
            periodo_de: document.getElementById('periodo_de').value,
            periodo_ate: document.getElementById('periodo_ate').value
        };
    }

    function exportAlunos() {
        var f = getFilters();
        window.location.href = ajaxurl + '?action=raz_export_alunos&nonce=' + nonce + 
            '&curso=' + f.curso + '&periodo_de=' + f.periodo_de + '&periodo_ate=' + f.periodo_ate;
    }

    function exportProgresso() {
        var f = getFilters();
        window.location.href = ajaxurl + '?action=raz_export_progresso&nonce=' + nonce + 
            '&curso=' + f.curso + '&periodo_de=' + f.periodo_de + '&periodo_ate=' + f.periodo_ate;
    }

    function exportConclusoes() {
        var f = getFilters();
        window.location.href = ajaxurl + '?action=raz_export_conclusoes&nonce=' + nonce + 
            '&curso=' + f.curso;
    }

    function exportCompleto() {
        var f = getFilters();
        window.location.href = ajaxurl + '?action=raz_export_completo&nonce=' + nonce + 
            '&curso=' + f.curso + '&periodo_de=' + f.periodo_de + '&periodo_ate=' + f.periodo_ate;
    }
</script>