<?php
/**
 * Admin: Alunos - VERSÃO CORRIGIDA
 * - Botões de fechar modal com type="button"
 * - Grupos de acesso funcionando
 */
$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title'));

$filter_curso = isset($_GET['curso_id']) ? intval($_GET['curso_id']) : 0;
$filter_status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
$filter_origem = isset($_GET['origem']) ? sanitize_text_field($_GET['origem']) : '';
$search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
$current_page = isset($_GET['pag']) ? max(1, intval($_GET['pag'])) : 1;
$per_page = 10;

global $wpdb;

$where = "WHERE 1=1";

if ($search) {
    $where .= $wpdb->prepare(" AND (u.user_email LIKE %s OR u.display_name LIKE %s)", '%' . $search . '%', '%' . $search . '%');
}

if ($filter_curso) {
    $where .= $wpdb->prepare(" AND u.ID IN (SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s)", '_raz_curso_acesso_' . $filter_curso);
}

if ($filter_origem) {
    $where .= $wpdb->prepare(" AND u.ID IN (SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_curso_acesso_%' AND meta_value LIKE %s)", '%' . $filter_origem . '%');
}

$query_base = "FROM {$wpdb->users} u {$where}";
$total = $wpdb->get_var("SELECT COUNT(u.ID) {$query_base}");

$offset = ($current_page - 1) * $per_page;
$total_pages = ceil($total / $per_page);

$alunos = $wpdb->get_results("SELECT u.ID as user_id, u.user_email, u.display_name {$query_base} ORDER BY u.display_name ASC LIMIT {$per_page} OFFSET {$offset}");
?>

<style>
/* ========== HEADER & STATS ========== */
.admin-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
.admin-header h2 { margin: 0; display: flex; align-items: center; gap: 12px; }
.admin-header h2 .total-badge { font-size: 13px; font-weight: 500; background: #e0e7ff; color: #4338ca; padding: 4px 12px; border-radius: 20px; }

/* ========== FILTERS ========== */
.filters-form { display: flex; gap: 12px; margin-bottom: 24px; flex-wrap: wrap; align-items: center; background: #f8fafc; padding: 16px; border-radius: 12px; border: 1px solid #e2e8f0; }
.filters-form input[type="text"], .filters-form select { padding: 10px 14px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 14px; background: #fff; transition: all 0.2s; }
.filters-form input[type="text"]:focus, .filters-form select:focus { border-color: #0284c7; outline: none; box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.1); }
.filters-form input[type="text"] { flex: 1; min-width: 220px; }
.filters-form select { min-width: 150px; cursor: pointer; }
.filters-form .btn { padding: 10px 20px; }
.filters-active-indicator { display: flex; align-items: center; gap: 6px; font-size: 12px; color: #0284c7; background: #e0f2fe; padding: 6px 12px; border-radius: 6px; }
.filters-active-indicator svg { width: 14px; height: 14px; }
.clear-filters-btn { font-size: 12px; color: #64748b; text-decoration: none; padding: 6px 12px; border-radius: 6px; transition: all 0.2s; display: inline-flex; align-items: center; gap: 4px; }
.clear-filters-btn:hover { background: #fee2e2; color: #dc2626; }

/* ========== TABLE ========== */
.table-card { background: #fff; border-radius: 12px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
.data-table { width: 100%; border-collapse: collapse; }
.data-table thead { background: #f8fafc; }
.data-table th { padding: 14px 16px; text-align: left; font-weight: 600; font-size: 12px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #e2e8f0; }
.data-table td { padding: 16px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
.data-table tbody tr { transition: background 0.15s; }
.data-table tbody tr:hover { background: #f8fafc; }
.data-table tbody tr:last-child td { border-bottom: none; }

/* User cell */
.user-cell { display: flex; flex-direction: column; gap: 4px; }
.user-cell .user-name { font-weight: 600; color: #1e293b; font-size: 14px; }
.user-cell .user-email-mobile { display: none; font-size: 12px; color: #64748b; }

/* Badges */
.origem-badge { font-size: 10px; padding: 3px 8px; border-radius: 4px; text-transform: uppercase; font-weight: 600; letter-spacing: 0.3px; }
.origem-badge.manual { background: #e0e7ff; color: #4338ca; }
.origem-badge.kiwify { background: #d1fae5; color: #065f46; }
.origem-badge.woocommerce { background: #fef3c7; color: #92400e; }

.cursos-badge { cursor: pointer; background: linear-gradient(135deg, #0284c7, #0369a1); color: #fff; padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s; box-shadow: 0 2px 4px rgba(2, 132, 199, 0.2); }
.cursos-badge:hover { transform: translateY(-1px); box-shadow: 0 4px 8px rgba(2, 132, 199, 0.3); }
.cursos-badge svg { width: 14px; height: 14px; }
.cursos-badge-empty { font-size: 12px; color: #94a3b8; background: #f1f5f9; padding: 6px 12px; border-radius: 20px; }

/* Last access */
.last-access-cell { display: flex; flex-direction: column; gap: 2px; }
.last-access-cell .date { font-size: 13px; color: #334155; }
.dias-sem-acesso { font-size: 11px; color: #64748b; display: inline-flex; align-items: center; gap: 4px; }
.dias-sem-acesso.alerta { color: #dc2626; font-weight: 600; background: #fef2f2; padding: 2px 8px; border-radius: 4px; }
.dias-sem-acesso.recente { color: #059669; }

/* Actions */
.actions-cell { display: flex; gap: 4px; flex-wrap: wrap; }
.action-link { font-size: 12px; color: #0284c7; cursor: pointer; text-decoration: none; padding: 6px 10px; border-radius: 6px; white-space: nowrap; transition: all 0.2s; display: inline-flex; align-items: center; gap: 4px; background: #f0f9ff; }
.action-link:hover { background: #0284c7; color: #fff; }
.action-link.danger { color: #dc2626; background: #fef2f2; }
.action-link.danger:hover { background: #dc2626; color: #fff; }

/* ========== PAGINATION ========== */
.pagination { display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; background: #f8fafc; border-radius: 0 0 12px 12px; border-top: 1px solid #e2e8f0; margin-top: -1px; }
.pagination-info { font-size: 13px; color: #64748b; }
.pagination-controls { display: flex; align-items: center; gap: 8px; }
.pagination .btn-sm { padding: 8px 16px; font-size: 13px; border-radius: 6px; }

/* ========== EMPTY STATE ========== */
.empty-state { text-align: center; padding: 60px 20px; }
.empty-state-icon { width: 80px; height: 80px; background: linear-gradient(135deg, #e0e7ff, #c7d2fe); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; }
.empty-state-icon svg { width: 40px; height: 40px; color: #4338ca; }
.empty-state h3 { font-size: 18px; color: #1e293b; margin-bottom: 8px; }
.empty-state p { font-size: 14px; color: #64748b; margin-bottom: 20px; }

/* ========== MODALS ========== */
.aluno-modal { position: fixed; inset: 0; background: rgba(15, 23, 42, 0.6); backdrop-filter: blur(4px); display: none; align-items: center; justify-content: center; z-index: 1000; padding: 20px; }
.aluno-modal.open { display: flex; animation: fadeIn 0.2s ease; }
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
.aluno-modal-content { background: #fff; border-radius: 16px; max-height: 90vh; overflow-y: auto; width: 100%; max-width: 750px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); animation: slideUp 0.3s ease; }
@keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
.aluno-modal-header { display: flex; justify-content: space-between; align-items: center; padding: 20px 24px; border-bottom: 1px solid #e2e8f0; position: sticky; top: 0; background: #fff; z-index: 10; border-radius: 16px 16px 0 0; }
.aluno-modal-header h3 { margin: 0; font-size: 18px; font-weight: 600; color: #1e293b; display: flex; align-items: center; gap: 10px; }
.aluno-modal-close { width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; background: #f1f5f9; border: none; border-radius: 8px; font-size: 20px; cursor: pointer; color: #64748b; transition: all 0.2s; }
.aluno-modal-close:hover { background: #fee2e2; color: #dc2626; }
.aluno-modal-body { padding: 24px; }
.aluno-modal-footer { display: flex; justify-content: flex-end; gap: 12px; padding: 16px 24px; border-top: 1px solid #e2e8f0; position: sticky; bottom: 0; background: #f8fafc; border-radius: 0 0 16px 16px; }

/* Form sections */
.form-section { margin-bottom: 24px; padding-bottom: 24px; border-bottom: 1px solid #e2e8f0; }
.form-section:last-child { border-bottom: none; margin-bottom: 0; padding-bottom: 0; }
.form-section-title { font-size: 13px; font-weight: 600; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 16px; display: flex; align-items: center; gap: 8px; }
.form-section-title svg { width: 16px; height: 16px; }

.form-group { margin-bottom: 18px; }
.form-group label { display: block; margin-bottom: 6px; font-weight: 500; font-size: 13px; color: #334155; }
.form-group input, .form-group select, .form-group textarea { width: 100%; padding: 11px 14px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 14px; transition: all 0.2s; }
.form-group input:focus, .form-group select:focus { border-color: #0284c7; outline: none; box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.1); }
.form-group small { font-size: 11px; color: #94a3b8; display: block; margin-top: 6px; }
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }

/* Curso checkboxes - melhorado */
.curso-checkbox-wrapper { padding: 0; border-radius: 10px; transition: all 0.2s; border: 1px solid transparent; margin-bottom: 6px; }
.curso-checkbox-wrapper:hover { background: #f1f5f9; }
.curso-checkbox-wrapper:has(input:checked) { background: #eff6ff; border-color: #bfdbfe; }
.curso-checkbox-wrapper label { display: flex !important; align-items: center !important; gap: 12px !important; padding: 14px 16px !important; margin: 0 !important; cursor: pointer; border-radius: 10px; min-height: 52px; }
.curso-checkbox-wrapper input[type="checkbox"] { width: 20px !important; height: 20px !important; margin: 0 !important; cursor: pointer; accent-color: #0284c7; flex-shrink: 0; border-radius: 4px; }
.curso-checkbox-wrapper label span { font-size: 14px !important; font-weight: 500 !important; color: #334155 !important; line-height: 1.4 !important; }
.curso-checkbox-wrapper:has(input:checked) label span { color: #0369a1 !important; font-weight: 600 !important; }

.grupos-por-curso { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px 16px; margin: 8px 16px 12px 16px; border-left: 3px solid #0284c7; }
.grupos-por-curso h5 { margin: 0 0 10px 0; font-size: 11px; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
.grupo-checkbox-mini { display: inline-flex; align-items: center; padding: 8px 14px; background: #fff; border: 1px solid #e2e8f0; border-radius: 20px; margin-right: 6px; margin-bottom: 6px; cursor: pointer; transition: all 0.2s; font-size: 13px; }
.grupo-checkbox-mini:hover { border-color: #0284c7; background: #eff6ff; }
.grupo-checkbox-mini.checked { background: #0284c7; border-color: #0284c7; color: #fff; }
.grupo-checkbox-mini input { width: 14px !important; height: 14px !important; margin: 0 8px 0 0 !important; cursor: pointer; }
.grupo-checkbox-mini.checked input { accent-color: #fff; }

#cursos-checkboxes { background: #fafbfc; padding: 10px !important; }

/* Audit styles */
.audit-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px; }
.audit-card { background: #f8fafc; padding: 18px; border-radius: 10px; border: 1px solid #e2e8f0; }
.audit-card h4 { font-size: 14px; margin-bottom: 14px; display: flex; align-items: center; gap: 8px; color: #334155; font-weight: 600; }
.audit-card p { font-size: 13px; color: #64748b; margin-bottom: 8px; display: flex; justify-content: space-between; }
.audit-card .value { color: #1e293b; font-weight: 500; }
.audit-table { width: 100%; font-size: 12px; }
.audit-table th, .audit-table td { padding: 12px 10px; text-align: left; border-bottom: 1px solid #e2e8f0; }
.audit-table th { background: #f8fafc; font-weight: 600; color: #64748b; text-transform: uppercase; font-size: 11px; }
.audit-table tbody tr:hover { background: #f8fafc; }

/* Cursos list no modal */
.cursos-list { margin-top: 8px; }
.curso-item { display: flex; flex-direction: column; gap: 8px; padding: 14px 16px; background: #f8fafc; border-radius: 10px; margin-bottom: 8px; border: 1px solid #e2e8f0; transition: all 0.2s; }
.curso-item:hover { border-color: #cbd5e1; }
.curso-item-header { display: flex; justify-content: space-between; align-items: center; }
.curso-item-name { font-weight: 600; font-size: 14px; color: #1e293b; }
.curso-item-exp { font-size: 12px; color: #64748b; display: flex; align-items: center; gap: 6px; }
.curso-item-exp.vitalicio { color: #059669; font-weight: 500; }
.curso-item-exp.expirado { color: #dc2626; font-weight: 500; }

/* Grupos no modal de cursos */
.curso-item-grupos { display: flex; flex-wrap: wrap; gap: 6px; padding-top: 8px; border-top: 1px dashed #e2e8f0; }
.curso-item-grupos-label { font-size: 11px; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: 0.3px; width: 100%; margin-bottom: 4px; display: flex; align-items: center; gap: 4px; }
.curso-item-grupos-label svg { width: 12px; height: 12px; }
.grupo-tag { display: inline-flex; align-items: center; gap: 4px; font-size: 11px; padding: 4px 10px; background: #e0e7ff; color: #4338ca; border-radius: 12px; font-weight: 500; }
.grupo-tag.default { background: #fef3c7; color: #92400e; }
.grupo-tag svg { width: 10px; height: 10px; }
.no-grupos { font-size: 11px; color: #94a3b8; font-style: italic; }

.pagination-mini { display: flex; align-items: center; gap: 8px; justify-content: center; margin-top: 16px; padding-top: 16px; border-top: 1px solid #e2e8f0; }
.pagination-mini button { padding: 6px 14px; font-size: 12px; border: 1px solid #e2e8f0; background: #fff; border-radius: 6px; cursor: pointer; transition: all 0.2s; }
.pagination-mini button:hover:not(:disabled) { background: #f1f5f9; border-color: #cbd5e1; }
.pagination-mini button:disabled { opacity: 0.5; cursor: not-allowed; }
.pagination-mini span { font-size: 12px; color: #64748b; }

/* ========== RESPONSIVE ========== */
@media (max-width: 1024px) {
    .data-table th:nth-child(3), .data-table td:nth-child(3) { display: none; }
}

@media (max-width: 768px) {
    .filters-form { flex-direction: column; padding: 12px; }
    .filters-form input[type="text"], .filters-form select { width: 100%; min-width: unset; }
    .audit-grid { grid-template-columns: 1fr; }
    .aluno-modal-content { max-width: 100%; margin: 10px; border-radius: 12px; }
    .aluno-modal-header, .aluno-modal-footer { border-radius: 0; }
    .form-row { grid-template-columns: 1fr; }
    
    .data-table th:nth-child(2), .data-table td:nth-child(2) { display: none; }
    .user-cell .user-email-mobile { display: block; }
    
    .actions-cell { flex-direction: column; gap: 6px; }
    .action-link { justify-content: center; }
    
    .pagination { flex-direction: column; gap: 12px; text-align: center; }
}
</style>

<div class="admin-header">
    <h2>
        Alunos
        <span class="total-badge"><?php echo $total; ?> aluno<?php echo $total != 1 ? 's' : ''; ?></span>
    </h2>
    <button class="btn btn-primary" onclick="openAddModal()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Novo Aluno
    </button>
</div>

<form method="get" action="<?php echo home_url('/gestao-cursos/alunos/'); ?>" class="filters-form">
    <input type="text" name="s" placeholder="🔍 Buscar por nome ou email..." value="<?php echo esc_attr($search); ?>">
    <select name="curso_id">
        <option value="">Todos os cursos</option>
        <?php foreach ($cursos as $c) : ?>
        <option value="<?php echo $c->ID; ?>" <?php selected($filter_curso, $c->ID); ?>><?php echo esc_html($c->post_title); ?></option>
        <?php endforeach; ?>
    </select>
    <select name="status">
        <option value="">Todos status</option>
        <option value="ativo" <?php selected($filter_status, 'ativo'); ?>>✅ Ativos</option>
        <option value="expirado" <?php selected($filter_status, 'expirado'); ?>>❌ Expirados</option>
    </select>
    <button type="submit" class="btn btn-primary">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><polygon points="22,3 2,3 10,12.46 10,19 14,21 14,12.46"/></svg>
        Filtrar
    </button>
    <?php 
    $has_filters = $search || $filter_curso || $filter_status || $filter_origem;
    if ($has_filters) : 
        $filter_count = ($search ? 1 : 0) + ($filter_curso ? 1 : 0) + ($filter_status ? 1 : 0) + ($filter_origem ? 1 : 0);
    ?>
    <span class="filters-active-indicator">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="22,3 2,3 10,12.46 10,19 14,21 14,12.46"/></svg>
        <?php echo $filter_count; ?> filtro<?php echo $filter_count > 1 ? 's' : ''; ?> ativo<?php echo $filter_count > 1 ? 's' : ''; ?>
    </span>
    <a href="<?php echo home_url('/gestao-cursos/alunos/'); ?>" class="clear-filters-btn">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        Limpar
    </a>
    <?php endif; ?>
</form>

<div class="table-card">
    <table class="data-table">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Telefone</th>
                <th>Cursos</th>
                <th>Último Acesso</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($alunos) : ?>
                <?php foreach ($alunos as $a) :
                    $user_id = $a->user_id;
                    
                    // Tenta buscar último acesso em diferentes meta_keys possíveis
                    $ultimo_acesso = get_user_meta($user_id, '_raz_ultimo_acesso', true);
                    
                    if (empty($ultimo_acesso)) {
                        $ultimo_acesso = get_user_meta($user_id, '_raz_last_login', true);
                    }
                    
                    if (empty($ultimo_acesso)) {
                        $ultimo_acesso = get_user_meta($user_id, 'last_login', true);
                    }
                    
                    if ($ultimo_acesso && is_numeric($ultimo_acesso)) {
                        $last_date = date('d/m/Y H:i', $ultimo_acesso);
                        $dias_sem_acesso = floor((time() - $ultimo_acesso) / 86400);
                    } elseif ($ultimo_acesso && strtotime($ultimo_acesso)) {
                        $last_date = date('d/m/Y H:i', strtotime($ultimo_acesso));
                        $dias_sem_acesso = floor((time() - strtotime($ultimo_acesso)) / 86400);
                    } else {
                        // Se nenhum último acesso, verifica se tem algum curso e pega a data de registro
                        $tem_cursos = $wpdb->get_var($wpdb->prepare(
                            "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key LIKE '_raz_curso_acesso_%'",
                            $user_id
                        ));
                        
                        if ($tem_cursos > 0) {
                            $user_obj = get_userdata($user_id);
                            $last_date = date('d/m/Y H:i', strtotime($user_obj->user_registered));
                            $dias_sem_acesso = floor((time() - strtotime($user_obj->user_registered)) / 86400);
                        } else {
                            $last_date = 'Nunca';
                            $dias_sem_acesso = null;
                        }
                    }
                    
                    $telefone = get_user_meta($user_id, '_raz_user_telefone', true) ?: '-';
                    
                    $cursos_count = $wpdb->get_var($wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key LIKE '_raz_curso_acesso_%'",
                        $user_id
                    ));
                    
                    $origem_meta = get_user_meta($user_id, '_raz_user_origem', true);
                    $origem = $origem_meta ?: 'manual';
                    $origem_class = 'manual';
                    if (strpos($origem, 'kiwify') !== false) $origem_class = 'kiwify';
                    if (strpos($origem, 'woocommerce') !== false) $origem_class = 'woocommerce';
                ?>
                <tr>
                    <td>
                        <div class="user-cell">
                            <span class="user-name"><?php echo esc_html($a->display_name); ?></span>
                            <span class="user-email-mobile"><?php echo esc_html($a->user_email); ?></span>
                        </div>
                    </td>
                    <td><?php echo esc_html($a->user_email); ?></td>
                    <td><?php echo esc_html($telefone); ?></td>
                    <td>
                        <?php if ($cursos_count > 0) : ?>
                        <span class="cursos-badge" onclick="showUserCursos(<?php echo $user_id; ?>, '<?php echo esc_js($a->display_name); ?>')">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
                            <?php echo $cursos_count; ?> curso<?php echo $cursos_count > 1 ? 's' : ''; ?>
                        </span>
                        <?php else : ?>
                        <span class="cursos-badge-empty">Nenhum</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="last-access-cell">
                            <span class="date"><?php echo $last_date; ?></span>
                            <?php if ($dias_sem_acesso !== null && $dias_sem_acesso >= 0) : ?>
                            <span class="dias-sem-acesso <?php echo $dias_sem_acesso > 30 ? 'alerta' : ($dias_sem_acesso <= 7 ? 'recente' : ''); ?>">
                                <?php if ($dias_sem_acesso == 0) : ?>
                                    ● Hoje
                                <?php elseif ($dias_sem_acesso <= 7) : ?>
                                    ● <?php echo $dias_sem_acesso; ?> dia<?php echo $dias_sem_acesso > 1 ? 's' : ''; ?>
                                <?php else : ?>
                                    ⚠ <?php echo $dias_sem_acesso; ?> dias atrás
                                <?php endif; ?>
                            </span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td>
                        <div class="actions-cell">
                            <a href="javascript:void(0)" class="action-link" onclick="editUser(<?php echo $user_id; ?>)">✏️ Editar</a>
                            <a href="javascript:void(0)" class="action-link" onclick="showUserAudit(<?php echo $user_id; ?>, '<?php echo esc_js($a->display_name); ?>')">📊 Auditoria</a>
                            <a href="javascript:void(0)" class="action-link danger" onclick="deleteUser(<?php echo $user_id; ?>)">🗑️ Excluir</a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr>
                    <td colspan="6">
                        <div class="empty-state">
                            <div class="empty-state-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                            </div>
                            <h3>Nenhum aluno encontrado</h3>
                            <p>Não encontramos alunos com os filtros selecionados.<br>Tente ajustar os filtros ou cadastre um novo aluno.</p>
                            <button class="btn btn-primary" onclick="openAddModal()">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                                Cadastrar Aluno
                            </button>
                        </div>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php 
$base_url = home_url('/gestao-cursos/alunos/');
$query_params = array();
if ($search) $query_params['s'] = $search;
if ($filter_curso) $query_params['curso_id'] = $filter_curso;
if ($filter_status) $query_params['status'] = $filter_status;
if ($filter_origem) $query_params['origem'] = $filter_origem;
?>

<?php if ($total_pages > 1) : ?>
<div class="pagination">
    <span class="pagination-info">
        Mostrando <?php echo min($offset + 1, $total); ?>-<?php echo min($offset + $per_page, $total); ?> de <?php echo $total; ?> alunos
    </span>
    <div class="pagination-controls">
        <?php
        if ($current_page > 1) :
            $prev_params = $query_params;
            $prev_params['pag'] = $current_page - 1;
            $prev_url = add_query_arg($prev_params, $base_url);
        ?>
        <a href="<?php echo esc_url($prev_url); ?>" class="btn btn-sm">← Anterior</a>
        <?php else : ?>
        <span class="btn btn-sm" style="opacity:0.5;pointer-events:none;">← Anterior</span>
        <?php endif; ?>
        
        <span style="padding:0 12px;font-size:13px;color:#64748b;font-weight:500;">
            <?php echo $current_page; ?> / <?php echo $total_pages; ?>
        </span>
        
        <?php if ($current_page < $total_pages) :
            $next_params = $query_params;
            $next_params['pag'] = $current_page + 1;
            $next_url = add_query_arg($next_params, $base_url);
        ?>
        <a href="<?php echo esc_url($next_url); ?>" class="btn btn-sm">Próxima →</a>
        <?php else : ?>
        <span class="btn btn-sm" style="opacity:0.5;pointer-events:none;">Próxima →</span>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<!-- Modal: Adicionar/Editar Aluno -->
<div id="user-modal" class="aluno-modal">
    <div class="aluno-modal-content">
        <div class="aluno-modal-header">
            <h3 id="modal-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                Novo Aluno
            </h3>
            <button type="button" class="aluno-modal-close" onclick="closeUserModal()">&times;</button>
        </div>
        <div class="aluno-modal-body">
            <form id="user-form">
                <input type="hidden" name="user_id" id="user_id">
                
                <div class="form-section">
                    <div class="form-section-title">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                        Dados Pessoais
                    </div>
                    
                    <div class="form-group">
                        <label>Nome Completo *</label>
                        <input type="text" name="user_name" id="user_name" required placeholder="Digite o nome completo">
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Email *</label>
                            <input type="email" name="user_email" id="user_email" required placeholder="email@exemplo.com">
                        </div>
                        
                        <div class="form-group">
                            <label>Telefone (WhatsApp)</label>
                            <input type="tel" name="user_telefone" id="user_telefone" placeholder="(00) 00000-0000">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Senha <small style="font-weight:400;color:#94a3b8;">(deixe em branco para manter/gerar automática)</small></label>
                        <input type="password" name="user_password" id="user_password" placeholder="••••••••">
                    </div>
                </div>
                
                <div class="form-section">
                    <div class="form-section-title">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                        Configuração de Acesso
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Tipo de Acesso</label>
                            <select name="acesso_tipo" id="form_acesso_tipo" onchange="toggleDiasField()">
                                <option value="dias">📅 Por Período (Dias)</option>
                                <option value="assinatura">🔄 Assinatura (Recorrente)</option>
                                <option value="vitalicio">♾️ Vitalício</option>
                            </select>
                        </div>
                        
                        <div class="form-group" id="dias-group">
                            <label>Dias de Acesso</label>
                            <input type="number" name="dias_acesso" id="form_dias" value="365" min="1">
                            <small>Quantidade de dias de acesso aos cursos</small>
                        </div>
                    </div>
                </div>
                
                <div class="form-section">
                    <div class="form-section-title">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
                        Cursos com Acesso
                    </div>
                    
                    <div id="cursos-checkboxes" style="max-height:280px; overflow-y:auto; border:1px solid #e2e8f0; border-radius:10px; padding:12px;">
                        <?php foreach ($cursos as $curso) : ?>
                        <div class="curso-checkbox-wrapper">
                            <label style="display: flex; align-items: center; gap: 10px; padding: 6px 0;">
                                <input 
                                    type="checkbox" 
                                    name="user_cursos[]" 
                                    value="<?php echo $curso->ID; ?>"
                                    data-curso-id="<?php echo $curso->ID; ?>"
                                    data-curso-nome="<?php echo esc_attr($curso->post_title); ?>"
                                    onchange="toggleGruposCurso(this)"
                                style="width: 18px; height: 18px; flex-shrink: 0; cursor: pointer; margin: 0; accent-color: var(--primary);"> 
                                <span style="font-size: 14px; color: var(--text-primary); line-height: 1.3;">
                                    <?php echo esc_html($curso->post_title); ?>
                                </span>
                            </label>
                            
                            
                            
                            <!-- Container de grupos deste curso -->
                            <div id="grupos-curso-<?php echo $curso->ID; ?>" class="grupos-por-curso" style="display:none;">
                                <h5>🔐 Grupos de Acesso:</h5>
                                <div id="grupos-list-<?php echo $curso->ID; ?>">
                                    <!-- Será preenchido dinamicamente -->
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </form>
        </div>
        <div class="aluno-modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeUserModal()">Cancelar</button>
            <button type="button" class="btn btn-primary" onclick="saveUser()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                Salvar Aluno
            </button>
        </div>
    </div>
</div>

<!-- Modal: Ver Cursos -->
<div id="cursos-modal" class="aluno-modal">
    <div class="aluno-modal-content" style="max-width:520px;">
        <div class="aluno-modal-header">
            <h3 id="cursos-modal-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
                Cursos do Aluno
            </h3>
            <button type="button" class="aluno-modal-close" onclick="closeCursosModal()">&times;</button>
        </div>
        <div class="aluno-modal-body">
            <div id="cursos-content"></div>
        </div>
    </div>
</div>

<!-- Modal: Auditoria -->
<div id="audit-modal" class="aluno-modal">
    <div class="aluno-modal-content" style="max-width:920px;">
        <div class="aluno-modal-header">
            <h3 id="audit-modal-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
                Auditoria
            </h3>
            <button type="button" class="aluno-modal-close" onclick="closeAuditModal()">&times;</button>
        </div>
        <div class="aluno-modal-body">
            <div id="audit-content"></div>
        </div>
    </div>
</div>

<script>
var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
var nonce = '<?php echo wp_create_nonce('raz_admin_nonce'); ?>';
var currentEditUserId = 0;
var cursosGrupos = {}; // Cache de grupos por curso

function toggleDiasField() {
    var tipo = document.getElementById('form_acesso_tipo').value;
    var diasGroup = document.getElementById('dias-group');
    diasGroup.style.display = (tipo === 'vitalicio') ? 'none' : 'block';
}

// Mostra/oculta grupos quando seleciona curso
function toggleGruposCurso(checkbox) {
    var cursoId = checkbox.getAttribute('data-curso-id');
    var gruposContainer = document.getElementById('grupos-curso-' + cursoId);
    
    if (checkbox.checked) {
        gruposContainer.style.display = 'block';
        // Carregar grupos do curso se ainda não carregou
        if (!cursosGrupos[cursoId]) {
            loadGruposCurso(cursoId);
        }
    } else {
        gruposContainer.style.display = 'none';
    }
}

// Carrega grupos de um curso específico
function loadGruposCurso(cursoId) {
    var container = document.getElementById('grupos-list-' + cursoId);
    container.innerHTML = '<p style="font-size:12px;color:var(--muted);">Carregando...</p>';
    
    console.log('Carregando grupos do curso:', cursoId);
    
    fetch(ajaxurl + '?action=raz_get_curso_grupos&nonce=' + nonce + '&curso_id=' + cursoId)
        .then(r => r.json())
        .then(data => {
            console.log('Resposta grupos curso ' + cursoId + ':', data);
            
            if (data.success && data.data && data.data.grupos) {
                cursosGrupos[cursoId] = data.data.grupos;
                renderGruposCurso(cursoId, data.data.grupos);
            } else {
                console.error('Grupos não encontrados para curso', cursoId, data);
                container.innerHTML = '<p style="font-size:11px;color:var(--muted);font-style:italic;">Nenhum grupo configurado para este curso</p>';
            }
        })
        .catch(err => {
            console.error('Erro ao carregar grupos:', err);
            container.innerHTML = '<p style="font-size:11px;color:var(--danger);">Erro ao carregar grupos</p>';
        });
}

// Renderiza checkboxes de grupos
function renderGruposCurso(cursoId, grupos) {
    var container = document.getElementById('grupos-list-' + cursoId);
    var html = '';
    
    Object.keys(grupos).forEach(slug => {
        var grupo = grupos[slug];
        var modulosCount = (grupo.modulos || []).length;
        var isDefault = grupo.is_default || false;
        
        html += '<label class="grupo-checkbox-mini" onclick="toggleGrupoCheckbox(this, event)">';
        html += '<input type="checkbox" name="user_grupos[' + cursoId + '][]" value="' + slug + '" onclick="event.stopPropagation()">';
        html += '<span style="font-size:12px;">' + grupo.nome;
        if (isDefault) html += ' <span style="color:#92400e;">★</span>';
        html += ' (' + modulosCount + ' módulo' + (modulosCount !== 1 ? 's' : '') + ')</span>';
        html += '</label>';
    });
    
    container.innerHTML = html || '<p style="font-size:11px;color:var(--muted);">Nenhum grupo</p>';
}

function toggleGrupoCheckbox(label, event) {
    if (event) event.preventDefault();
    var checkbox = label.querySelector('input[type="checkbox"]');
    if (checkbox) {
        checkbox.checked = !checkbox.checked;
    }
    
    if (label.classList.contains('checked')) {
        label.classList.remove('checked');
    } else {
        label.classList.add('checked');
    }
}

function openAddModal() {
    currentEditUserId = 0;
    document.getElementById('modal-title').textContent = 'Novo Aluno';
    document.getElementById('user-form').reset();
    document.getElementById('user_id').value = '';
    document.getElementById('user-modal').classList.add('open');
    
    // Oculta todos os grupos
    document.querySelectorAll('.grupos-por-curso').forEach(el => el.style.display = 'none');
    
    toggleDiasField();
}

function closeUserModal() {
    var modal = document.getElementById('user-modal');
    if (modal) {
        modal.classList.remove('open');
    }
}

function closeCursosModal() { 
    var modal = document.getElementById('cursos-modal');
    if (modal) {
        modal.classList.remove('open');
    }
}

function closeAuditModal() { 
    var modal = document.getElementById('audit-modal');
    if (modal) {
        modal.classList.remove('open');
    }
}

function editUser(userId) {
    currentEditUserId = userId;
    document.getElementById('modal-title').textContent = 'Editar Aluno';
    document.getElementById('user-modal').classList.add('open');
    
    fetch(ajaxurl + '?action=raz_get_user&nonce=' + nonce + '&user_id=' + userId)
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                var u = d.data;
                document.getElementById('user_id').value = userId;
                document.getElementById('user_name').value = u.name;
                document.getElementById('user_email').value = u.email;
                document.getElementById('user_telefone').value = u.telefone || '';
                document.getElementById('user_password').value = '';
                
                if (u.acesso_tipo) {
                    document.getElementById('form_acesso_tipo').value = u.acesso_tipo;
                }
                
                if (u.dias_acesso) {
                    document.getElementById('form_dias').value = u.dias_acesso;
                }
                
                toggleDiasField();
                
                // Marca cursos e mostra grupos
                var checkboxes = document.querySelectorAll('input[name="user_cursos[]"]');
                checkboxes.forEach(cb => {
                    var cursoId = cb.getAttribute('data-curso-id');
                    if (u.cursos.indexOf(parseInt(cursoId)) > -1) {
                        cb.checked = true;
                        toggleGruposCurso(cb);
                    }
                });
                
                // Carrega grupos do usuário
                setTimeout(() => loadUserGrupos(userId), 500);
            } else {
                alert('Erro: ' + (d.data ? d.data.message : 'Usuário não encontrado'));
                closeModal();
            }
        })
        .catch(e => {
            console.error(e);
            alert('Erro ao carregar dados do usuário');
            closeModal();
        });
}

// Carrega grupos que o usuário já pertence
function loadUserGrupos(userId) {
    fetch(ajaxurl + '?action=raz_get_user_grupos_data&nonce=' + nonce + '&user_id=' + userId)
        .then(r => r.json())
        .then(d => {
            if (d.success && d.data) {
                Object.keys(d.data).forEach(cursoKey => {
                    var cursoId = cursoKey.replace('curso_', '');
                    var gruposUser = d.data[cursoKey];
                    
                    gruposUser.forEach(slug => {
                        var checkbox = document.querySelector('input[name="user_grupos[' + cursoId + '][]"][value="' + slug + '"]');
                        if (checkbox) {
                            checkbox.checked = true;
                            var label = checkbox.closest('.grupo-checkbox-mini');
                            if (label) label.classList.add('checked');
                        }
                    });
                });
            }
        });
}

function deleteUser(userId) {
    if (!confirm('Tem certeza que deseja excluir este aluno?\n\nTodos os dados dele serão perdidos.')) return;
    
    fetch(ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=raz_delete_user&nonce=' + nonce + '&user_id=' + userId
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) { 
            location.reload(); 
        } else { 
            alert('Erro: ' + (d.data ? d.data.message : 'Desconhecido')); 
        }
    });
}

function saveUser() {
    var form = document.getElementById('user-form');
    
    // Validação manual antes de enviar
    var userName = document.getElementById('user_name').value.trim();
    var userEmail = document.getElementById('user_email').value.trim();
    
    if (!userName || !userEmail) {
        alert('Por favor, preencha nome e email');
        return;
    }
    
    // Coletar cursos selecionados
    var cursos = [];
    document.querySelectorAll('input[name="user_cursos[]"]:checked').forEach(function(cb) {
        cursos.push(cb.value);
    });
    
    // Coletar grupos selecionados
    var grupos = {};
    document.querySelectorAll('input[name^="user_grupos["]:checked').forEach(function(cb) {
        var match = cb.name.match(/user_grupos\[(\d+)\]\[\]/);
        if (match) {
            var cursoId = match[1];
            if (!grupos[cursoId]) {
                grupos[cursoId] = [];
            }
            grupos[cursoId].push(cb.value);
        }
    });
    
    // Montar dados manualmente
    var formData = new FormData();
    formData.append('action', 'raz_save_user');
    formData.append('nonce', nonce);
    formData.append('user_id', document.getElementById('user_id').value || '');
    formData.append('user_name', userName);
    formData.append('user_email', userEmail);
    formData.append('user_telefone', document.getElementById('user_telefone').value || '');
    formData.append('user_password', document.getElementById('user_password').value || '');
    formData.append('acesso_tipo', document.getElementById('form_acesso_tipo').value);
    formData.append('dias_acesso', document.getElementById('form_dias').value);
    
    // Adicionar cursos
    cursos.forEach(function(cursoId) {
        formData.append('user_cursos[]', cursoId);
    });
    
    // Adicionar grupos
    Object.keys(grupos).forEach(function(cursoId) {
        grupos[cursoId].forEach(function(grupoSlug) {
            formData.append('user_grupos[' + cursoId + '][]', grupoSlug);
        });
    });
    
    // Debug: veja o que está sendo enviado
    console.log('Dados enviados:', {
        user_id: formData.get('user_id'),
        user_name: formData.get('user_name'),
        user_email: formData.get('user_email'),
        cursos: cursos,
        grupos: grupos
    });
    
    fetch(ajaxurl, { method: 'POST', body: formData })
    .then(r => {
        console.log('Status HTTP:', r.status);
        console.log('Headers:', r.headers);
        return r.text(); // Primeiro pega como texto
    })
    .then(text => {
        console.log('Resposta RAW do servidor:', text);
        
        // Tenta fazer parse do JSON
        try {
            var d = JSON.parse(text);
            console.log('JSON parseado:', d);
            
            if (d.success) { 
                location.reload(); 
            } else {
                // Mostrar debug se disponível
                if (d.data && d.data.debug) {
                    console.error('Debug do servidor:', d.data.debug);
                    
                    // Montar mensagem detalhada
                    var debugMsg = 'Erro: ' + d.data.message + '\n\n';
                    debugMsg += 'DEBUG:\n';
                    debugMsg += '- Raw name: "' + d.data.debug.name_raw + '"\n';
                    debugMsg += '- Raw email: "' + d.data.debug.email_raw + '"\n';
                    debugMsg += '- Sanitized name: "' + d.data.debug.name_sanitized + '"\n';
                    debugMsg += '- Sanitized email: "' + d.data.debug.email_sanitized + '"\n';
                    debugMsg += '- Name length: ' + d.data.debug.name_length + '\n';
                    debugMsg += '- Email length: ' + d.data.debug.email_length + '\n';
                    debugMsg += '- POST keys: ' + JSON.stringify(d.data.debug.post_keys) + '\n';
                    debugMsg += '- isset user_name: ' + d.data.debug.isset_user_name + '\n';
                    debugMsg += '- isset user_email: ' + d.data.debug.isset_user_email;
                    
                    alert(debugMsg);
                } else {
                    alert('Erro: ' + (d.data ? d.data.message : 'Desconhecido')); 
                }
            }
        } catch (e) {
            console.error('Erro ao fazer parse do JSON:', e);
            console.error('Texto recebido:', text);
            alert('Erro: Resposta inválida do servidor. Veja o console para detalhes.');
        }
    })
    .catch(e => {
        console.error('Erro na requisição:', e);
        alert('Erro ao salvar: ' + e.message);
    });
}

function showUserCursos(userId, userName) {
    document.getElementById('cursos-modal-title').textContent = 'Cursos de ' + userName;
    document.getElementById('cursos-modal').classList.add('open');
    document.getElementById('cursos-content').innerHTML = '<p style="text-align:center;padding:20px;color:var(--muted);">Carregando...</p>';
    
    fetch(ajaxurl + '?action=raz_get_user_cursos&nonce=' + nonce + '&user_id=' + userId)
        .then(r => r.json())
        .then(d => {
            if (d.success && d.data.length > 0) {
                var html = '<div class="cursos-list">';
                d.data.forEach(c => {
                    var expClass = c.vitalicio ? 'vitalicio' : (c.expirado ? 'expirado' : '');
                    var expText = c.vitalicio ? '♾️ Vitalício' : (c.expirado ? '❌ Expirado em ' + c.expiracao : '📅 Expira em ' + c.expiracao);
                    
                    html += '<div class="curso-item">';
                    html += '<div class="curso-item-header">';
                    html += '<span class="curso-item-name">' + c.nome + '</span>';
                    html += '<span class="curso-item-exp ' + expClass + '">' + expText + '</span>';
                    html += '</div>';
                    
                    // Seção de grupos de acesso
                    html += '<div class="curso-item-grupos">';
                    html += '<span class="curso-item-grupos-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg> Grupos de Acesso:</span>';
                    
                    if (c.grupos && c.grupos.length > 0) {
                        c.grupos.forEach(g => {
                            var tagClass = g.is_default ? 'grupo-tag default' : 'grupo-tag';
                            html += '<span class="' + tagClass + '">';
                            if (g.is_default) {
                                html += '<svg viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg> ';
                            }
                            html += g.nome + ' (' + g.modulos_count + ' mód.)';
                            html += '</span>';
                        });
                    } else {
                        html += '<span class="no-grupos">Nenhum grupo atribuído</span>';
                    }
                    
                    html += '</div>';
                    html += '</div>';
                });
                html += '</div>';
                document.getElementById('cursos-content').innerHTML = html;
            } else {
                document.getElementById('cursos-content').innerHTML = '<p style="text-align:center;color:var(--muted);">Nenhum curso encontrado</p>';
            }
        });
}

var auditPage = 1;
var auditUserId = 0;

function showUserAudit(userId, userName) {
    auditUserId = userId;
    auditPage = 1;
    document.getElementById('audit-modal-title').textContent = 'Auditoria: ' + userName;
    document.getElementById('audit-modal').classList.add('open');
    loadAuditData();
}

function loadAuditData() {
    document.getElementById('audit-content').innerHTML = '<p style="text-align:center;padding:40px;color:var(--muted);">Carregando...</p>';
    
    fetch(ajaxurl + '?action=raz_get_user_audit&nonce=' + nonce + '&user_id=' + auditUserId + '&page=' + auditPage)
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                var a = d.data;
                var html = '<div class="audit-grid">';
                
                html += '<div class="audit-card"><h4>📅 Último Acesso</h4>';
                html += '<p>Data: <span class="value">' + a.last_access.date + '</span></p>';
                html += '<p>Dias sem acessar: <span class="value">' + (a.last_access.dias_sem_acesso || '0') + '</span></p>';
                html += '<p>Curso: <span class="value">' + (a.last_access.curso || '-') + '</span></p>';
                html += '<p>Aula: <span class="value">' + (a.last_access.aula || '-') + '</span></p></div>';
                
                html += '<div class="audit-card"><h4>📍 Posição Atual</h4>';
                html += '<p>Módulo: <span class="value">' + (a.posicao.modulo || '-') + '</span></p>';
                html += '<p>Aula: <span class="value">' + (a.posicao.aula || '-') + '</span></p>';
                html += '<p>Progresso: <span class="value">' + (a.posicao.progresso || '0%') + '</span></p></div>';
                
                html += '<div class="audit-card"><h4>💻 Dispositivo</h4>';
                html += '<p>Navegador: <span class="value">' + (a.last_access.browser || '-') + '</span></p>';
                html += '<p>Sistema: <span class="value">' + (a.last_access.os || '-') + '</span></p>';
                html += '<p>IP: <span class="value">' + (a.last_access.ip || '-') + '</span></p></div>';
                
                html += '<div class="audit-card"><h4>👤 Informações</h4>';
                html += '<p>Cadastro: <span class="value">' + (a.user.registered || '-') + '</span></p>';
                html += '<p>Origem: <span class="value">' + (a.user.origem || 'manual') + '</span></p>';
                html += '<p>Total acessos: <span class="value">' + (a.total_acessos || '0') + '</span></p></div>';
                
                html += '</div>';
                
                html += '<h4 style="margin:20px 0 12px;">📜 Histórico de Acessos</h4>';
                html += '<div style="max-height:300px;overflow-y:auto;border:1px solid var(--border);border-radius:8px;">';
                html += '<table class="audit-table"><thead><tr><th>Data/Hora</th><th>Curso</th><th>Módulo</th><th>Aula</th><th>IP</th></tr></thead><tbody>';
                
                if (a.history && a.history.length) {
                    a.history.forEach(h => {
                        html += '<tr><td>' + h.date + '</td><td>' + h.curso + '</td><td>' + h.modulo + '</td><td>' + h.aula + '</td><td>' + h.ip + '</td></tr>';
                    });
                } else {
                    html += '<tr><td colspan="5" style="text-align:center;color:var(--muted);padding:20px;">Nenhum acesso registrado</td></tr>';
                }
                
                html += '</tbody></table></div>';
                
                if (a.total_pages > 1) {
                    html += '<div class="pagination-mini">';
                    html += '<button onclick="auditPrev()" ' + (auditPage <= 1 ? 'disabled' : '') + '>← Anterior</button>';
                    html += '<span>Página ' + auditPage + ' de ' + a.total_pages + '</span>';
                    html += '<button onclick="auditNext(' + a.total_pages + ')" ' + (auditPage >= a.total_pages ? 'disabled' : '') + '>Próxima →</button>';
                    html += '</div>';
                }
                
                document.getElementById('audit-content').innerHTML = html;
            }
        });
}

function auditPrev() { if (auditPage > 1) { auditPage--; loadAuditData(); } }
function auditNext(max) { if (auditPage < max) { auditPage++; loadAuditData(); } }

// Event listeners para fechar modais
document.addEventListener('DOMContentLoaded', function() {
    // Fechar ao clicar fora do modal
    document.querySelectorAll('.aluno-modal').forEach(function(modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.classList.remove('open');
            }
        });
    });
    
    // Fechar ao pressionar ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.aluno-modal.open').forEach(function(modal) {
                modal.classList.remove('open');
            });
        }
    });
});

</script>