<?php
/**
 * Componente: Gerenciamento de Grupos de Acesso do Curso
 * Inserir na aba "Grupos" do curso-editar.php
 * * @package RazMidiasLMS
 * @version 2.4.0
 */

defined('ABSPATH') || exit;

// Variáveis necessárias (devem existir no contexto do curso-editar.php)
$curso_id = isset($raz_item_id) ? intval($raz_item_id) : 0;

if (!$curso_id) {
    echo '<div class="notice notice-error"><p>ID do curso não encontrado.</p></div>';
    return;
}

// Busca módulos do curso
if (function_exists('raz_lms_get_modulos')) {
    $modulos = raz_lms_get_modulos($curso_id);
} else {
    // Fallback: busca direto
    $modulos = get_posts([
        'post_type' => 'modulo',
        'posts_per_page' => -1,
        'meta_key' => '_raz_modulo_curso',
        'meta_value' => $curso_id,
        'orderby' => 'menu_order',
        'order' => 'ASC'
    ]);
}

// Busca configuração de grupos
$grupos_config = raz_get_curso_grupos_config($curso_id);

// Prepara dados dos módulos para JavaScript
$modulos_data = [];
foreach ($modulos as $modulo) {
    // Conta aulas do módulo
    $aulas_count = 0;
    
    if (function_exists('raz_lms_get_aulas')) {
        $aulas = raz_lms_get_aulas($modulo->ID);
        $aulas_count = count($aulas);
    } else {
        // Fallback com a chave correta
        $aulas = get_posts([
            'post_type' => 'aula',
            'posts_per_page' => -1,
            'meta_key' => '_raz_aula_modulo',
            'meta_value' => $modulo->ID
        ]);
        $aulas_count = count($aulas);
    }
    
    $modulos_data[] = [
        'id' => $modulo->ID,
        'nome' => $modulo->post_title,
        'aulas' => $aulas_count
    ];
}
?>

<div class="form-card raz-grupos-container" style="margin-top: 30px;">
    <div class="raz-grupos-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <div>
            <h3 style="margin: 0; font-size: 18px; color: #1e293b; display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 24px;">🔐</span>
                Grupos de Acesso
            </h3>
            <p style="margin: 4px 0 0 32px; font-size: 13px; color: #64748b;">
                Configure quais módulos cada grupo de usuários pode acessar
            </p>
        </div>
        <button type="button" class="btn btn-primary" onclick="razAddGrupo()">
            <span style="font-size: 16px;">+</span> Novo Grupo
        </button>
    </div>

    <?php if (empty($modulos)): ?>
        <div style="padding: 40px; text-align: center; background: #fef3c7; border: 1px solid #fde68a; border-radius: 8px;">
            <p style="color: #92400e; margin: 0; font-size: 14px;">
                <strong>⚠️ Atenção:</strong> Crie alguns módulos primeiro antes de configurar os grupos de acesso.
            </p>
        </div>
    <?php else: ?>
        <div id="grupos-container">
            </div>

        <div id="grupos-empty" style="display: none; padding: 40px; text-align: center; background: #f8fafc; border-radius: 8px; border: 1px dashed #cbd5e1;">
            <p style="color: #94a3b8; margin: 0;">
                Nenhum grupo configurado. Clique em "+ Novo Grupo" para começar.
            </p>
        </div>
    <?php endif; ?>
</div>

<div class="modal-overlay" id="modal-alunos-grupo">
    <div class="modal" style="max-width: 900px; width: 90%; height: auto; max-height: 90vh; display: flex; flex-direction: column;">
        <div class="modal-header">
            <h3>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                Alunos no Grupo: <span id="modal-grupo-nome" style="margin-left: 5px; color: var(--primary);"></span>
            </h3>
            <button type="button" class="modal-close" onclick="closeModal('modal-alunos-grupo')">&times;</button>
        </div>
        
        <div class="modal-toolbar" style="padding: 16px 24px; background: #f8fafc; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
            <div class="search-box" style="position: relative; flex: 1; max-width: 400px;">
                <input type="text" id="modal-student-search" placeholder="Buscar aluno por nome ou email..." style="width: 100%; padding-left: 36px; height: 40px; border: 1px solid #cbd5e1; border-radius: 6px;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="position: absolute; left: 10px; top: 50%; transform: translateY(-50%); width: 16px; height: 16px; color: #94a3b8;"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            </div>
            <div class="stats" style="font-size: 13px; color: #64748b;">
                Total: <strong id="modal-total-students">0</strong> alunos encontrados
            </div>
        </div>

        <div class="modal-body" style="padding: 0; flex: 1; overflow: hidden; display: flex; flex-direction: column; position: relative;">
            <div class="table-responsive" style="overflow-y: auto; flex: 1; padding: 0;">
                <table class="wp-list-table widefat fixed striped" style="border: none; box-shadow: none; width: 100%;">
                    <thead>
                        <tr>
                            <th style="padding: 12px 24px; font-weight: 600; text-align: left;">Nome</th>
                            <th style="padding: 12px 24px; font-weight: 600; text-align: left;">Email</th>
                            <th style="padding: 12px 24px; width: 100px; text-align: center; font-weight: 600;">Ações</th>
                        </tr>
                    </thead>
                    <tbody id="modal-alunos-lista">
                        </tbody>
                </table>
            </div>
            
            <div id="modal-loading" style="display: none; position: absolute; inset: 0; background: rgba(255,255,255,0.8); align-items: center; justify-content: center; z-index: 10;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="32" height="32" style="animation: spin 1s linear infinite; color: var(--primary);"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
            </div>
        </div>
        
        <div class="modal-footer" style="justify-content: space-between; background: #fff;">
            <div class="pagination-info" style="font-size: 13px; color: #64748b;">
                Página <span id="current-page">1</span> de <span id="total-pages">1</span>
            </div>
            <div class="pagination-controls" style="display: flex; gap: 8px;">
                <button type="button" class="btn btn-sm btn-secondary" id="btn-prev-page" onclick="razChangePage(-1)" disabled>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="15 18 9 12 15 6"/></svg> Anterior
                </button>
                <button type="button" class="btn btn-sm btn-secondary" id="btn-next-page" onclick="razChangePage(1)" disabled>
                    Próximo <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="9 18 15 12 9 6"/></svg>
                </button>
            </div>
        </div>
    </div>
</div>

<style>
.raz-grupos-container .grupo-card { background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 16px; overflow: hidden; transition: box-shadow 0.2s; }
.raz-grupos-container .grupo-card:hover { box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
.raz-grupos-container .grupo-header { background: #f8fafc; padding: 16px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; border-bottom: 1px solid #e2e8f0; transition: background 0.2s; }
.raz-grupos-container .grupo-header:hover { background: #f1f5f9; }
.raz-grupos-container .grupo-title { display: flex; align-items: center; gap: 12px; flex: 1; }
.raz-grupos-container .grupo-title input { font-size: 15px; font-weight: 600; color: #1e293b; border: none; background: transparent; padding: 6px 10px; border-radius: 4px; min-width: 200px; transition: all 0.2s; }
.raz-grupos-container .grupo-title input:hover { background: rgba(255,255,255,0.5); }
.raz-grupos-container .grupo-title input:focus { background: #fff; outline: 2px solid #0284c7; outline-offset: -2px; }
.raz-grupos-container .grupo-badge { background: #dbeafe; color: #0369a1; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 500; }
.raz-grupos-container .grupo-badge.default { background: #fef3c7; color: #92400e; }
.raz-grupos-container .grupo-badge.alunos { background: #dcfce7; color: #166534; cursor: pointer; transition: all 0.2s; }
.raz-grupos-container .grupo-badge.alunos:hover { background: #bbf7d0; transform: translateY(-1px); }
.raz-grupos-container .grupo-actions { display: flex; gap: 8px; }
.raz-grupos-container .grupo-content { padding: 20px; display: none; }
.raz-grupos-container .grupo-content.active { display: block; }
.raz-grupos-container .modulos-checkboxes { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 12px; }
.raz-grupos-container .modulo-checkbox { display: flex; align-items: center; padding: 12px; background: #f8fafc; border: 2px solid #e2e8f0; border-radius: 6px; cursor: pointer; transition: all 0.2s; user-select: none; }
.raz-grupos-container .modulo-checkbox:hover { background: #f1f5f9; border-color: #cbd5e1; }
.raz-grupos-container .modulo-checkbox.checked { background: #dbeafe; border-color: #0284c7; }
.raz-grupos-container .modulo-checkbox input[type="checkbox"] { margin: 0 12px 0 0; width: 18px; height: 18px; cursor: pointer; flex-shrink: 0; }
.raz-grupos-container .modulo-info { flex: 1; min-width: 0; }
.raz-grupos-container .modulo-name { font-weight: 500; color: #1e293b; font-size: 14px; margin-bottom: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.raz-grupos-container .modulo-count { font-size: 12px; color: #64748b; }

/* Correção para tabela ocupar 100% */
#modal-alunos-lista tr td { vertical-align: middle; }
.wp-list-table { width: 100% !important; table-layout: auto; }
</style>

<script>
(function() {
    // Dados iniciais
    let gruposData = <?php echo json_encode($grupos_config); ?>;
    const modulosData = <?php echo json_encode($modulos_data); ?>;
    const cursoId = <?php echo $curso_id; ?>;
    const ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
    const nonce = '<?php echo wp_create_nonce('raz_admin_nonce'); ?>';
    
    // Estado do Modal de Alunos
    let modalState = {
        slug: '',
        page: 1,
        search: '',
        total: 0,
        totalPages: 1
    };
    let searchTimeout = null;
    let saveTimeout = null;

    // Inicializa
    document.addEventListener('DOMContentLoaded', function() {
        razRenderGrupos();
        
        // Listener para busca com debounce
        const searchInput = document.getElementById('modal-student-search');
        if(searchInput) {
            searchInput.addEventListener('input', function(e) {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    modalState.search = e.target.value;
                    modalState.page = 1; // Reseta para primeira página
                    razFetchStudents();
                }, 500); // 500ms delay
            });
        }
    });

    /**
     * Adiciona novo grupo
     */
    window.razAddGrupo = function() {
        const timestamp = Date.now();
        const slug = 'grupo_' + timestamp;
        const nome = 'Novo Grupo';
        
        gruposData[slug] = {
            nome: nome,
            modulos: [],
            is_default: Object.keys(gruposData).length === 0 
        };
        
        razRenderGrupos();
        razShowToast('Grupo adicionado! Configure e salve.', 'success');
        razScheduleSave();
    };

    /**
     * Remove grupo
     */
    window.razRemoveGrupo = function(slug) {
        if (!confirm('Tem certeza que deseja remover este grupo?\n\nUsuários que pertencem a este grupo perderão o acesso.')) return;
        delete gruposData[slug];
        razRenderGrupos();
        razSaveGrupos();
        razShowToast('Grupo removido!', 'info');
    };

    /**
     * Define grupo como padrão
     */
    window.razToggleGrupoDefault = function(slug) {
        Object.keys(gruposData).forEach(key => { gruposData[key].is_default = false; });
        gruposData[slug].is_default = true;
        razRenderGrupos();
        razSaveGrupos();
        razShowToast('Grupo padrão atualizado!', 'success');
    };

    /**
     * Atualiza nome do grupo
     */
    window.razUpdateGrupoNome = function(slug, nome) {
        if (gruposData[slug]) {
            gruposData[slug].nome = nome.trim() || 'Sem nome';
            razScheduleSave();
        }
    };

    /**
     * Toggle módulo no grupo
     */
    window.razToggleModulo = function(slug, moduloId, isChecked) {
        if (!gruposData[slug]) return;
        if (!gruposData[slug].modulos) gruposData[slug].modulos = [];
        
        const index = gruposData[slug].modulos.indexOf(moduloId);
        
        if (isChecked) {
            if (index === -1) gruposData[slug].modulos.push(moduloId);
        } else {
            if (index > -1) gruposData[slug].modulos.splice(index, 1);
        }
        
        // Atualiza visual
        const input = document.querySelector(`input[data-grupo="${slug}"][data-modulo="${moduloId}"]`);
        if (input) {
            const label = input.closest('.modulo-checkbox');
            isChecked ? label.classList.add('checked') : label.classList.remove('checked');
        }

        const badge = document.querySelector(`#grupo-badge-${slug}`);
        if (badge) {
            const count = gruposData[slug].modulos.length;
            badge.textContent = count + ' módulo' + (count !== 1 ? 's' : '');
        }
        
        razScheduleSave();
    };

    window.razToggleGrupoContent = function(slug) {
        const content = document.getElementById('grupo-content-' + slug);
        if (content) content.classList.toggle('active');
    };

    // --- FUNÇÕES DE RENDERIZAÇÃO PRINCIPAL ---

    function razRenderGrupos() {
        const container = document.getElementById('grupos-container');
        const empty = document.getElementById('grupos-empty');
        if (!container) return;
        
        if (Object.keys(gruposData).length === 0) {
            container.innerHTML = '';
            if (empty) empty.style.display = 'block';
            return;
        }
        
        if (empty) empty.style.display = 'none';
        container.innerHTML = '';
        
        Object.entries(gruposData).forEach(([slug, data]) => {
            container.insertAdjacentHTML('beforeend', razRenderGrupoCard(slug, data));
            razLoadStudentCount(slug);
        });
    }

    function razRenderGrupoCard(slug, data) {
        const isDefault = data.is_default || false;
        const modulosSelecionados = data.modulos || [];
        const modulosCount = modulosSelecionados.length;
        
        let modulosHtml = '';
        modulosData.forEach(modulo => {
            const checked = modulosSelecionados.includes(modulo.id);
            modulosHtml += `
                <label class="modulo-checkbox ${checked ? 'checked' : ''}">
                    <input type="checkbox" ${checked ? 'checked' : ''} 
                        onchange="razToggleModulo('${slug}', ${modulo.id}, this.checked)"
                        data-grupo="${slug}" data-modulo="${modulo.id}">
                    <div class="modulo-info">
                        <div class="modulo-name">${escapeHtml(modulo.nome)}</div>
                        <div class="modulo-count">${modulo.aulas} aula${modulo.aulas !== 1 ? 's' : ''}</div>
                    </div>
                </label>
            `;
        });
        
        return `
            <div class="grupo-card" data-grupo="${slug}">
                <div class="grupo-header" onclick="razToggleGrupoContent('${slug}')">
                    <div class="grupo-title">
                        <input type="text" value="${escapeHtml(data.nome)}" 
                            onclick="event.stopPropagation()" 
                            onblur="razUpdateGrupoNome('${slug}', this.value)"
                            onkeypress="if(event.key==='Enter'){this.blur();}"
                            placeholder="Nome do grupo">
                        ${isDefault ? '<span class="grupo-badge default">★ PADRÃO</span>' : ''}
                        <span class="grupo-badge" id="grupo-badge-${slug}">${modulosCount} módulo${modulosCount !== 1 ? 's' : ''}</span>
                        <span class="grupo-badge alunos" id="grupo-alunos-${slug}" onclick="event.stopPropagation(); razShowStudents('${slug}', '${escapeHtml(data.nome)}')">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12" style="margin-right:2px; vertical-align:-1px;"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                            Ver alunos...
                        </span>
                    </div>
                    <div class="grupo-actions" onclick="event.stopPropagation()">
                        ${!isDefault ? `<button type="button" class="btn btn-warning" onclick="razToggleGrupoDefault('${slug}')" title="Definir como padrão">★ Padrão</button>` : ''}
                        <button type="button" class="btn btn-danger" onclick="razRemoveGrupo('${slug}')">🗑️</button>
                    </div>
                </div>
                <div id="grupo-content-${slug}" class="grupo-content">
                    <h4 style="margin: 0 0 16px 0; font-size: 14px; color: #64748b; font-weight: 500;">
                        📚 Selecione os módulos que este grupo pode acessar:
                    </h4>
                    ${modulosData.length > 0 ? `<div class="modulos-checkboxes">${modulosHtml}</div>` : '<p style="color: #94a3b8; font-style: italic;">Nenhum módulo disponível</p>'}
                </div>
            </div>
        `;
    }

    // --- LÓGICA DO MODAL DE ALUNOS ---

    window.razShowStudents = function(slug, nome) {
        // Reset State
        modalState.slug = slug;
        modalState.page = 1;
        modalState.search = '';
        modalState.total = 0;
        
        document.getElementById('modal-grupo-nome').innerText = nome;
        document.getElementById('modal-student-search').value = '';
        
        // Open Modal
        openModal('modal-alunos-grupo');
        razFetchStudents();
    };

    window.razChangePage = function(direction) {
        const newPage = modalState.page + direction;
        if(newPage > 0 && newPage <= modalState.totalPages) {
            modalState.page = newPage;
            razFetchStudents();
        }
    };

    window.razFetchStudents = function() {
        const listContainer = document.getElementById('modal-alunos-lista');
        const loadingEl = document.getElementById('modal-loading');
        const prevBtn = document.getElementById('btn-prev-page');
        const nextBtn = document.getElementById('btn-next-page');
        
        // UI Updates
        loadingEl.style.display = 'flex';
        listContainer.style.opacity = '0.5';
        
        // Build Params
        const params = new URLSearchParams({
            action: 'raz_get_group_students',
            nonce: nonce,
            curso_id: cursoId,
            grupo_slug: modalState.slug,
            paged: modalState.page,
            search: modalState.search
        });

        fetch(ajaxUrl + '?' + params.toString())
        .then(r => r.json())
        .then(d => {
            loadingEl.style.display = 'none';
            listContainer.style.opacity = '1';

            if (d.success) {
                // Update State
                modalState.total = d.data.total_items;
                modalState.totalPages = d.data.total_pages;
                
                // Render List
                if(d.data.rows.length > 0) {
                    let html = '';
                    d.data.rows.forEach(user => {
                        // Link atualizado conforme solicitado
                        const profileUrl = `${razAdmin.homeUrl}/gestao-cursos/alunos/?s=${encodeURIComponent(user.email)}&curso_id=&status=&origem=`;
                        
                        html += `
                        <tr>
                            <td style="padding: 12px 24px;"><strong>${escapeHtml(user.name)}</strong></td>
                            <td style="padding: 12px 24px;">${escapeHtml(user.email)}</td>
                            <td style="padding: 12px 24px; text-align: center;">
                                <a href="${profileUrl}" target="_blank" class="btn btn-sm btn-secondary" style="padding: 2px 6px; font-size: 11px;">
                                    Perfil ↗
                                </a>
                            </td>
                        </tr>`;
                    });
                    listContainer.innerHTML = html;
                } else {
                    listContainer.innerHTML = `<tr><td colspan="3" style="padding: 30px; text-align:center; color:#94a3b8;">Nenhum aluno encontrado.</td></tr>`;
                }

                // Update Counters & Buttons
                document.getElementById('modal-total-students').innerText = modalState.total;
                document.getElementById('current-page').innerText = modalState.page;
                document.getElementById('total-pages').innerText = modalState.totalPages || 1;
                
                prevBtn.disabled = (modalState.page <= 1);
                nextBtn.disabled = (modalState.page >= modalState.totalPages);
            } else {
                listContainer.innerHTML = `<tr><td colspan="3" style="padding: 20px; color:red; text-align:center;">Erro ao carregar.</td></tr>`;
            }
        })
        .catch(err => {
            console.error(err);
            loadingEl.style.display = 'none';
            listContainer.innerHTML = `<tr><td colspan="3" style="padding: 20px; color:red; text-align:center;">Erro de conexão.</td></tr>`;
        });
    };

    // --- HELPERS ---

    window.razLoadStudentCount = function(slug) {
        const el = document.getElementById('grupo-alunos-' + slug);
        if (!el) return;
        
        // Simples chamada de contagem (rápida)
        fetch(`${ajaxUrl}?action=raz_get_group_student_count&nonce=${nonce}&curso_id=${cursoId}&grupo_slug=${slug}`)
        .then(r => r.json())
        .then(d => {
            if (d.success) el.innerHTML = `
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12" style="margin-right:2px; vertical-align:-1px;"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                ${d.data.count} aluno(s)`;
        });
    };

    function razScheduleSave() {
        if (saveTimeout) clearTimeout(saveTimeout);
        saveTimeout = setTimeout(razSaveGrupos, 1000);
    }

    function razSaveGrupos() {
        const data = new FormData();
        data.append('action', 'raz_save_curso_grupos');
        data.append('nonce', nonce);
        data.append('curso_id', cursoId);
        data.append('grupos', JSON.stringify(gruposData));
        
        fetch(ajaxUrl, { method: 'POST', body: data })
        .then(res => res.json())
        .then(result => {
            if (result.success) console.log('✅ Grupos salvos');
            else razShowToast('Erro ao salvar grupos', 'error');
        });
    }

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text || '';
        return div.innerHTML;
    }

    function razShowToast(message, type) {
        if (typeof window.razShowToast === 'function') return;
        const toast = document.createElement('div');
        toast.style.cssText = `position: fixed; top: 20px; right: 20px; padding: 12px 20px; background: ${type === 'success' ? '#10b981' : '#ef4444'}; color: white; border-radius: 6px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); z-index: 10000; animation: slideIn 0.3s ease;`;
        toast.textContent = message;
        document.body.appendChild(toast);
        setTimeout(() => { toast.remove(); }, 3000);
    }
})();
</script>

<style>
@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
@keyframes spin { 100% { transform: rotate(360deg); } }
</style>