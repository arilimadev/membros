<?php
/**
 * Template Name: Meus Cursos
 * @package RazMidiasLMS
 */

if (!is_user_logged_in()) {
    wp_redirect(home_url('/login'));
    exit;
}

get_header(); // Carrega o Topo Global (Configurado no header.php)

$user_id = get_current_user_id();
$cursos = raz_lms_get_user_courses($user_id);

// --- LÓGICA DO "CONTINUE DE ONDE PAROU" ---
$last_course_id = get_user_meta($user_id, '_raz_last_curso', true);
$last_lesson_id = $last_course_id ? get_user_meta($user_id, '_raz_last_aula_' . $last_course_id, true) : 0;
$resume_data = null;

if ($last_course_id && $last_lesson_id) {
    $last_course_post = get_post($last_course_id);
    $last_lesson_post = get_post($last_lesson_id);

    // Verifica se os posts existem e se o usuário ainda tem acesso ao curso
    if ($last_course_post && $last_lesson_post && raz_lms_user_has_access($user_id, $last_course_id)) {
        $resume_progress = raz_lms_get_course_progress($user_id, $last_course_id);
        $resume_data = [
            'course_title' => $last_course_post->post_title,
            'lesson_title' => $last_lesson_post->post_title,
            'lesson_url'   => get_permalink($last_lesson_id),
            'percent'      => $resume_progress['percent']
        ];
    }
}
?>

<div class="raz-dashboard">
    <div class="raz-dashboard-content">
        <div class="raz-dashboard-welcome">
            <h1>Meus Cursos</h1>
            <p>Bem-vindo ao seu painel de aprendizado.</p>
        </div>

        <?php if ($resume_data) : ?>
        <a href="<?php echo esc_url($resume_data['lesson_url']); ?>" class="raz-resume-bar">
            <div class="raz-resume-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
            </div>
            
            <div class="raz-resume-info">
                <div class="raz-resume-text">
                    <span class="raz-resume-label">Continue assistindo:</span>
                    <span class="raz-resume-lesson"><?php echo esc_html($resume_data['lesson_title']); ?></span>
                </div>
                <div class="raz-resume-subtext">
                    <?php echo esc_html($resume_data['course_title']); ?>
                </div>
            </div>

            <div class="raz-resume-meta">
                <div class="raz-resume-progress-bg">
                    <div class="raz-resume-progress-fill" style="width: <?php echo $resume_data['percent']; ?>%"></div>
                </div>
                <span class="raz-resume-percent"><?php echo $resume_data['percent']; ?>%</span>
                <svg xmlns="http://www.w3.org/2000/svg" class="raz-arrow-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" /></svg>
            </div>
        </a>
        <?php endif; ?>
        <?php if (empty($cursos)) : ?>
            <div class="raz-empty-state"
                 style="text-align:center;padding:4rem 2rem;background:var(--bg-primary);border-radius:12px;border:1px solid var(--border);">
                <div style="width:64px;height:64px;background:var(--bg-tertiary);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1.5rem;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2" style="color:var(--text-secondary);">
                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
                    </svg>
                </div>
                <h3 style="margin-bottom:0.5rem;">Nenhum curso encontrado</h3>
                <p style="color:var(--text-secondary);margin-bottom:1.5rem;">Você ainda não está matriculado em nenhum
                    curso.</p>
                <a href="<?php echo home_url('/cursos/'); ?>" class="raz-btn raz-btn-primary">Ver Cursos Disponíveis</a>
            </div>
        <?php else : ?>

            <div class="raz-dashboard-courses">
                <?php foreach ($cursos as $curso) :
                    $thumbnail = get_the_post_thumbnail_url($curso->ID, 'raz-course-card');
                    $tipo_curso = get_post_meta($curso->ID, '_raz_curso_tipo', true);

                    // Formatar texto de validade
                    $validade_html = '';
                    $acesso = $curso->acesso;

                    if (isset($acesso['vitalicio']) && $acesso['vitalicio']) {
                        $validade_html = '<span class="status-badge vitalicio">Vitalício</span>';
                    } elseif (isset($acesso['expiracao'])) {
                        $data_exp = strtotime($acesso['expiracao']);
                        $dias_restantes = ceil(($data_exp - time()) / 86400);
                        $data_fmt = date_i18n('d/m/Y', $data_exp);

                        if ($tipo_curso === 'assinatura') {
                            $validade_html = '<div style="display:flex;flex-direction:column;align-items:center;">';
                            $validade_html .= '<span class="status-badge assinatura">Assinatura Ativa</span>';
                            $validade_html .= '<span style="font-size:9px;color:var(--text-muted);margin-top:2px;">Renova em: ' . $data_fmt . '</span>';
                            $validade_html .= '</div>';
                        } else {
                            $class = $dias_restantes < 7 ? 'expirando' : 'ativo';
                            $validade_html = '<div style="display:flex;flex-direction:column;align-items:center;">';
                            $validade_html .= '<span style="font-size:10px;color:var(--text-secondary);">Expira em ' . $data_fmt . '</span>';
                            if ($dias_restantes < 7 && $dias_restantes > 0) {
                                $validade_html .= '<span style="font-size:10px;color:#ef4444;font-weight:600;">Expira em breve!</span>';
                            }
                            $validade_html .= '</div>';
                        }
                    }
                    ?>
                    <div class="raz-course-card">
                        <a href="<?php echo get_permalink($curso->ID); ?>" class="raz-course-card-image">
                            <?php if ($thumbnail) : ?>
                                <img src="<?php echo esc_url($thumbnail); ?>"
                                     alt="<?php echo esc_attr($curso->post_title); ?>">
                            <?php else : ?>
                                <div style="width:100%;height:100%;background:linear-gradient(135deg,var(--bg-dark),#1a365d);display:flex;align-items:center;justify-content:center;color:white;">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24"
                                         fill="none" stroke="currentColor" stroke-width="1">
                                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
                                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
                                    </svg>
                                </div>
                            <?php endif; ?>

                            <div class="card-overlay">
                                <div class="play-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"
                                         width="24" height="24">
                                        <polygon points="5 3 19 12 5 21 5 3"/>
                                    </svg>
                                </div>
                            </div>
                        </a>

                        <div class="raz-course-card-content">
                            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px;">
                                <h3 class="raz-course-card-title">
                                    <a href="<?php echo get_permalink($curso->ID); ?>"><?php echo esc_html($curso->post_title); ?></a>
                                </h3>
                                <?php echo $validade_html; ?>
                            </div>

                            <div class="raz-course-card-progress">
                                <div class="raz-course-card-progress-header">
                                    <span>Progresso</span>
                                    <span><?php echo $curso->progresso['percent']; ?>%</span>
                                </div>
                                <div class="raz-course-card-progress-bar">
                                    <div class="raz-course-card-progress-fill"
                                         style="width:<?php echo $curso->progresso['percent']; ?>%;"></div>
                                </div>
                            </div>

                            <a href="<?php echo get_permalink($curso->ID); ?>" class="raz-course-card-action">
                                <?php echo $curso->progresso['percent'] > 0 ? 'Continuar Curso' : 'Iniciar Curso'; ?>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
    /* Estilos Específicos para os cards e barra de retomada (O resto vem do style.css ou header.php) */
    .raz-resume-bar {
        display: flex;
        align-items: center;
        gap: 16px;
        background: var(--bg-card, #fff);
        border: 1px solid var(--border, #e2e8f0);
        padding: 12px 20px;
        border-radius: 8px;
        margin-bottom: 32px;
        text-decoration: none;
        color: inherit;
        transition: all 0.2s;
        box-shadow: 0 1px 2px rgba(0,0,0,0.05);
    }
    
    .raz-resume-bar:hover {
        border-color: var(--primary);
        transform: translateY(-1px);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }

    .raz-resume-icon {
        width: 40px;
        height: 40px;
        background: var(--primary);
        border-radius: 50%;
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }

    .raz-resume-icon svg { width: 20px; height: 20px; }

    .raz-resume-info {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .raz-resume-text {
        font-size: 14px;
        color: var(--text-primary, #1e293b);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        line-height: 1.4;
    }

    .raz-resume-label {
        color: var(--text-secondary, #64748b);
        margin-right: 4px;
    }

    .raz-resume-lesson {
        font-weight: 600;
        color: var(--text-primary, #0f172a);
    }

    .raz-resume-subtext {
        font-size: 12px;
        color: var(--text-muted, #94a3b8);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .raz-resume-meta {
        display: flex;
        align-items: center;
        gap: 12px;
        flex-shrink: 0;
    }

    .raz-resume-progress-bg {
        width: 100px;
        height: 6px;
        background: var(--bg-tertiary, #e2e8f0);
        border-radius: 3px;
        overflow: hidden;
    }

    .raz-resume-progress-fill {
        height: 100%;
        background: #10b981;
        border-radius: 3px;
    }

    .raz-resume-percent {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary, #64748b);
        min-width: 32px;
        text-align: right;
    }

    .raz-arrow-icon {
        width: 16px;
        height: 16px;
        color: var(--primary);
    }

    @media (max-width: 640px) {
        .raz-resume-bar { flex-wrap: wrap; padding: 16px; }
        .raz-resume-meta { width: 100%; margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border, #e2e8f0); justify-content: space-between; }
        .raz-resume-progress-bg { flex: 1; }
    }

    /* Estilos Específicos para Status */
    .status-badge { font-size: 10px; font-weight: 600; padding: 2px 8px; border-radius: 99px; text-transform: uppercase; }
    .status-badge.vitalicio { background: #dcfce7; color: #166534; }
    .status-badge.assinatura { background: #e0f2fe; color: #0369a1; font-size: 8px !important; }
    .status-badge.expirando { background: #fee2e2; color: #991b1b; }
    .raz-course-card-image { position: relative; display: block; }
    .card-overlay { position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0, 0, 0, 0.3); display: flex; align-items: center; justify-content: center; opacity: 0; transition: opacity 0.2s; }
    .raz-course-card:hover .card-overlay { opacity: 1; }
    .play-icon { width: 48px; height: 48px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; transform: scale(0.8); transition: transform 0.2s; }
    .raz-course-card:hover .play-icon { transform: scale(1); }
</style>

<?php get_footer(); ?>