/**
 * Raz Midias LMS - Video/Audio Player
 * @package RazMidiasLMS
 */

(function() {
    'use strict';

    // Elements
    var playerContainer = document.getElementById('player-container');
    var videoWrapper = document.getElementById('video-wrapper');
    var playOverlay = document.getElementById('play-overlay');
    var playBtn = document.getElementById('play-btn');
    var progressContainer = document.getElementById('progress-container');
    var progressBar = document.getElementById('progress-bar');
    var timeDisplay = document.getElementById('time-display');
    var volumeBtn = document.getElementById('volume-btn');
    var volumeSlider = document.getElementById('volume-slider');
    var volumeLevel = document.getElementById('volume-level');
    var fullscreenBtn = document.getElementById('fullscreen-btn');
    var pipBtn = document.getElementById('pip-btn');
    var skipBack = document.getElementById('skip-back');
    var skipForward = document.getElementById('skip-forward');
    var playerControls = document.getElementById('player-controls');

    // Get video element (could be iframe or video)
    var video = videoWrapper ? videoWrapper.querySelector('video') : null;
    var iframe = videoWrapper ? videoWrapper.querySelector('iframe') : null;
    var isYouTube = iframe && iframe.src.indexOf('youtube') > -1;
    var isVimeo = iframe && iframe.src.indexOf('vimeo') > -1;

    var isPlaying = false;
    var currentVolume = 1;
    var lessonCompleted = razAulaData.isCompleted;
    var completionThreshold = 0.9; // 90% watched to mark complete

    // Format time
    function formatTime(seconds) {
        var mins = Math.floor(seconds / 60);
        var secs = Math.floor(seconds % 60);
        return mins + ':' + (secs < 10 ? '0' : '') + secs;
    }

    // Update play button icon
    function updatePlayButton(playing) {
        if (!playBtn) return;
        var playIcon = playBtn.querySelector('.play-icon');
        var pauseIcon = playBtn.querySelector('.pause-icon');
        if (playIcon) playIcon.style.display = playing ? 'none' : 'block';
        if (pauseIcon) pauseIcon.style.display = playing ? 'block' : 'none';
    }

    // Native HTML5 Video Controls
    if (video) {
        // Hide overlay when playing
        video.addEventListener('play', function() {
            isPlaying = true;
            if (playOverlay) playOverlay.classList.add('hidden');
            updatePlayButton(true);
        });

        video.addEventListener('pause', function() {
            isPlaying = false;
            updatePlayButton(false);
        });

        video.addEventListener('timeupdate', function() {
            var percent = (video.currentTime / video.duration) * 100;
            if (progressBar) progressBar.style.width = percent + '%';
            if (timeDisplay) timeDisplay.textContent = formatTime(video.currentTime) + ' / ' + formatTime(video.duration);

            // Mark as complete when reaching threshold
            if (!lessonCompleted && video.currentTime / video.duration >= completionThreshold) {
                lessonCompleted = true;
                markLessonComplete(razAulaData.aulaId);
            }
        });

        video.addEventListener('ended', function() {
            isPlaying = false;
            updatePlayButton(false);
            
            // Auto-advance to next lesson
            if (razAulaData.nextUrl) {
                setTimeout(function() {
                    window.location.href = razAulaData.nextUrl;
                }, 1500);
            }
        });

        video.addEventListener('loadedmetadata', function() {
            if (timeDisplay) timeDisplay.textContent = '0:00 / ' + formatTime(video.duration);
        });

        // Play/Pause
        if (playBtn) {
            playBtn.addEventListener('click', function() {
                if (video.paused) {
                    video.play();
                } else {
                    video.pause();
                }
            });
        }

        if (playOverlay) {
            playOverlay.addEventListener('click', function() {
                video.play();
            });
        }

        // Click on video to toggle
        video.addEventListener('click', function() {
            if (video.paused) {
                video.play();
            } else {
                video.pause();
            }
        });

        // Progress bar seek
        if (progressContainer) {
            progressContainer.addEventListener('click', function(e) {
                var rect = progressContainer.getBoundingClientRect();
                var percent = (e.clientX - rect.left) / rect.width;
                video.currentTime = percent * video.duration;
            });
        }

        // Volume
        if (volumeSlider) {
            volumeSlider.addEventListener('click', function(e) {
                var rect = volumeSlider.getBoundingClientRect();
                var percent = (e.clientX - rect.left) / rect.width;
                video.volume = Math.max(0, Math.min(1, percent));
                currentVolume = video.volume;
                if (volumeLevel) volumeLevel.style.width = (video.volume * 100) + '%';
            });
        }

        if (volumeBtn) {
            volumeBtn.addEventListener('click', function() {
                if (video.volume > 0) {
                    video.volume = 0;
                    if (volumeLevel) volumeLevel.style.width = '0%';
                } else {
                    video.volume = currentVolume || 1;
                    if (volumeLevel) volumeLevel.style.width = (video.volume * 100) + '%';
                }
            });
        }

        // Skip buttons
        if (skipBack) {
            skipBack.addEventListener('click', function() {
                video.currentTime = Math.max(0, video.currentTime - 15);
            });
        }

        if (skipForward) {
            skipForward.addEventListener('click', function() {
                video.currentTime = Math.min(video.duration, video.currentTime + 15);
            });
        }

        // Fullscreen
        if (fullscreenBtn) {
            fullscreenBtn.addEventListener('click', function() {
                if (document.fullscreenElement) {
                    document.exitFullscreen();
                } else {
                    playerContainer.requestFullscreen();
                }
            });
        }

        // Picture in Picture
        if (pipBtn && document.pictureInPictureEnabled) {
            pipBtn.addEventListener('click', function() {
                if (document.pictureInPictureElement) {
                    document.exitPictureInPicture();
                } else {
                    video.requestPictureInPicture();
                }
            });
        }

        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

            switch (e.key) {
                case ' ':
                case 'k':
                    e.preventDefault();
                    if (video.paused) video.play();
                    else video.pause();
                    break;
                case 'ArrowLeft':
                    e.preventDefault();
                    video.currentTime = Math.max(0, video.currentTime - 10);
                    break;
                case 'ArrowRight':
                    e.preventDefault();
                    video.currentTime = Math.min(video.duration, video.currentTime + 10);
                    break;
                case 'ArrowUp':
                    e.preventDefault();
                    video.volume = Math.min(1, video.volume + 0.1);
                    if (volumeLevel) volumeLevel.style.width = (video.volume * 100) + '%';
                    break;
                case 'ArrowDown':
                    e.preventDefault();
                    video.volume = Math.max(0, video.volume - 0.1);
                    if (volumeLevel) volumeLevel.style.width = (video.volume * 100) + '%';
                    break;
                case 'f':
                    e.preventDefault();
                    if (document.fullscreenElement) document.exitFullscreen();
                    else playerContainer.requestFullscreen();
                    break;
                case 'm':
                    e.preventDefault();
                    video.muted = !video.muted;
                    if (volumeLevel) volumeLevel.style.width = video.muted ? '0%' : (video.volume * 100) + '%';
                    break;
            }
        });

        // Double click for fullscreen
        video.addEventListener('dblclick', function() {
            if (document.fullscreenElement) {
                document.exitFullscreen();
            } else {
                playerContainer.requestFullscreen();
            }
        });
    }

    // For iframes (YouTube/Vimeo) - simplified controls
    if (iframe && !video) {
        // Hide custom controls for iframe embeds as they have their own
        if (playerControls) playerControls.style.display = 'none';
        if (playOverlay) playOverlay.style.display = 'none';
        if (skipBack) skipBack.style.display = 'none';
        if (skipForward) skipForward.style.display = 'none';

        // Just handle fullscreen
        if (fullscreenBtn) {
            fullscreenBtn.addEventListener('click', function() {
                if (document.fullscreenElement) {
                    document.exitFullscreen();
                } else {
                    playerContainer.requestFullscreen();
                }
            });
        }

        // Mark as complete after some time (since we can't track iframe progress easily)
        setTimeout(function() {
            if (!lessonCompleted) {
                lessonCompleted = true;
                markLessonComplete(razAulaData.aulaId);
            }
        }, 60000); // 1 minute
    }

    // Audio Player
    var audioElement = document.getElementById('audio-element');
    var audioPlay = document.getElementById('audio-play');
    var audioProgress = document.getElementById('audio-progress');
    var audioProgressBar = document.getElementById('audio-progress-bar');
    var audioCurrent = document.getElementById('audio-current');
    var audioDuration = document.getElementById('audio-duration');
    var audioBack = document.getElementById('audio-back');
    var audioForward = document.getElementById('audio-forward');

    if (audioElement) {
        audioElement.addEventListener('loadedmetadata', function() {
            if (audioDuration) audioDuration.textContent = formatTime(audioElement.duration);
        });

        audioElement.addEventListener('timeupdate', function() {
            var percent = (audioElement.currentTime / audioElement.duration) * 100;
            if (audioProgressBar) audioProgressBar.style.width = percent + '%';
            if (audioCurrent) audioCurrent.textContent = formatTime(audioElement.currentTime);

            // Mark as complete
            if (!lessonCompleted && audioElement.currentTime / audioElement.duration >= completionThreshold) {
                lessonCompleted = true;
                markLessonComplete(razAulaData.aulaId);
            }
        });

        audioElement.addEventListener('play', function() {
            isPlaying = true;
            if (audioPlay) {
                audioPlay.querySelector('.play-icon').style.display = 'none';
                audioPlay.querySelector('.pause-icon').style.display = 'block';
            }
        });

        audioElement.addEventListener('pause', function() {
            isPlaying = false;
            if (audioPlay) {
                audioPlay.querySelector('.play-icon').style.display = 'block';
                audioPlay.querySelector('.pause-icon').style.display = 'none';
            }
        });

        audioElement.addEventListener('ended', function() {
            isPlaying = false;
            if (razAulaData.nextUrl) {
                setTimeout(function() {
                    window.location.href = razAulaData.nextUrl;
                }, 1500);
            }
        });

        if (audioPlay) {
            audioPlay.addEventListener('click', function() {
                if (audioElement.paused) audioElement.play();
                else audioElement.pause();
            });
        }

        if (audioProgress) {
            audioProgress.addEventListener('click', function(e) {
                var rect = audioProgress.getBoundingClientRect();
                var percent = (e.clientX - rect.left) / rect.width;
                audioElement.currentTime = percent * audioElement.duration;
            });
        }

        if (audioBack) {
            audioBack.addEventListener('click', function() {
                audioElement.currentTime = Math.max(0, audioElement.currentTime - 15);
            });
        }

        if (audioForward) {
            audioForward.addEventListener('click', function() {
                audioElement.currentTime = Math.min(audioElement.duration, audioElement.currentTime + 15);
            });
        }
    }

    // Text-only lessons - mark complete immediately
    if (razAulaData.tipo === 'texto' && !lessonCompleted) {
        setTimeout(function() {
            markLessonComplete(razAulaData.aulaId);
        }, 5000); // After 5 seconds of reading
    }

    // Show controls on mouse movement
    var controlsTimeout;
    if (playerContainer) {
        playerContainer.addEventListener('mousemove', function() {
            if (playerControls) playerControls.classList.add('visible');
            clearTimeout(controlsTimeout);
            controlsTimeout = setTimeout(function() {
                if (isPlaying && playerControls) {
                    playerControls.classList.remove('visible');
                }
            }, 3000);
        });
    }

})();
