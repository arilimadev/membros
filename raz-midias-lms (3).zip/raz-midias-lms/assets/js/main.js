/**
 * Raz Midias LMS - Main JavaScript
 * @package RazMidiasLMS
 */

(function($) {
    'use strict';

    // Sidebar Toggle
    var sidebar = document.getElementById('raz-sidebar');
    var sidebarToggle = document.getElementById('sidebar-toggle');
    var sidebarClose = document.getElementById('sidebar-close');
    var sidebarOverlay = document.getElementById('sidebar-overlay');
    var main = document.getElementById('raz-main');

    function openSidebar() {
        if (sidebar) {
            sidebar.classList.add('open');
            if (sidebarOverlay) sidebarOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    }

    function closeSidebar() {
        if (sidebar) {
            sidebar.classList.remove('open');
            if (sidebarOverlay) sidebarOverlay.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', openSidebar);
    }

    if (sidebarClose) {
        sidebarClose.addEventListener('click', closeSidebar);
    }

    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', closeSidebar);
    }

    // Landscape mode detection
    var wrapper = document.getElementById('raz-lms-wrapper');
    var landscapeExit = document.getElementById('landscape-exit');

    function checkOrientation() {
        if (window.innerWidth <= 1024 && window.innerHeight < window.innerWidth) {
            // Landscape on mobile
            if (wrapper) wrapper.classList.add('landscape-mode');
        } else {
            if (wrapper) wrapper.classList.remove('landscape-mode');
        }
    }

    window.addEventListener('orientationchange', function() {
        setTimeout(checkOrientation, 100);
    });

    window.addEventListener('resize', checkOrientation);
    checkOrientation();

    if (landscapeExit) {
        landscapeExit.addEventListener('click', function() {
            if (wrapper) wrapper.classList.remove('landscape-mode');
            // Try to exit fullscreen
            if (document.exitFullscreen) {
                document.exitFullscreen();
            } else if (document.webkitExitFullscreen) {
                document.webkitExitFullscreen();
            }
        });
    }

    // Rating System
    var ratingContainer = document.getElementById('rating-container');
    if (ratingContainer) {
        var stars = ratingContainer.querySelectorAll('.raz-rating-star');
        var aulaId = ratingContainer.dataset.aula;

        stars.forEach(function(star, index) {
            star.addEventListener('click', function() {
                var rating = this.dataset.rating;
                
                // Update UI
                stars.forEach(function(s, i) {
                    if (i < rating) {
                        s.classList.add('active');
                        s.setAttribute('fill', 'currentColor');
                    } else {
                        s.classList.remove('active');
                        s.setAttribute('fill', 'none');
                    }
                });

                // Save rating via AJAX
                $.ajax({
                    url: razLMS.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'raz_rate_lesson',
                        nonce: razLMS.nonce,
                        aula_id: aulaId,
                        rating: rating
                    }
                });
            });

            star.addEventListener('mouseenter', function() {
                var rating = this.dataset.rating;
                stars.forEach(function(s, i) {
                    if (i < rating) {
                        s.style.color = '#fbbf24';
                    }
                });
            });

            star.addEventListener('mouseleave', function() {
                stars.forEach(function(s) {
                    if (!s.classList.contains('active')) {
                        s.style.color = '';
                    }
                });
            });
        });
    }

    // Mark lesson as complete
    window.markLessonComplete = function(aulaId, callback) {
        $.ajax({
            url: razLMS.ajaxurl,
            type: 'POST',
            data: {
                action: 'raz_complete_lesson',
                nonce: razLMS.nonce,
                aula_id: aulaId
            },
            success: function(response) {
                if (response.success) {
                    // Update checkbox in sidebar
                    var lessonItem = document.querySelector('.raz-lesson-item.active .raz-lesson-checkbox');
                    if (lessonItem) {
                        lessonItem.classList.add('completed');
                    }
                    
                    if (callback) callback(response.data);
                }
            }
        });
    };

    // Mobile tabs
    var mobileTabs = document.querySelectorAll('.raz-mobile-tab');
    mobileTabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
            mobileTabs.forEach(function(t) { t.classList.remove('active'); });
            this.classList.add('active');
            
            var tabName = this.dataset.tab;
            if (tabName === 'aulas') {
                openSidebar();
            }
        });
    });

    // Show mobile tabs on smaller screens
    if (window.innerWidth <= 768) {
        var mobileTabsContainer = document.querySelector('.raz-mobile-tabs');
        if (mobileTabsContainer) {
            mobileTabsContainer.style.display = 'flex';
        }
    }

})(jQuery);
