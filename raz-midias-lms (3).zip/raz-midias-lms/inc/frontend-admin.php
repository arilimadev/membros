<?php
/**
 * Frontend Admin Panel - Painel amigável para administrador.
 *
 * Este arquivo atua como o controlador (Controller) principal do sistema LMS.
 * Responsável por rotas, CRUD, gestão de usuários, logs, duplicação e relatórios.
 *
 * @package RazMidiasLMS
 * @version 5.1.0
 */

defined('ABSPATH') || exit;

/* ==========================================================================
   1. CONFIGURAÇÃO DE ROTAS, REWRITE RULES E SETUP INICIAL
   ========================================================================== */

if (!function_exists('raz_lms_register_admin_page')) {
    /**
     * Registra as regras de reescrita para as URLs amigáveis.
     */
    function raz_lms_register_admin_page()
    {
        // Rota principal (Dashboard)
        add_rewrite_rule(
            '^gestao-cursos/?$',
            'index.php?raz_admin_page=dashboard',
            'top'
        );

        // Rotas de listagem
        add_rewrite_rule(
            '^gestao-cursos/([^/]+)/?$',
            'index.php?raz_admin_page=$matches[1]',
            'top'
        );

        // Rotas de edição com ID
        add_rewrite_rule(
            '^gestao-cursos/([^/]+)/([0-9]+)/?$',
            'index.php?raz_admin_page=$matches[1]&raz_item_id=$matches[2]',
            'top'
        );
    }
}
add_action('init', 'raz_lms_register_admin_page');


if (!function_exists('raz_lms_flush_rewrite_rules')) {
    /**
     * Força a atualização das regras de reescrita.
     */
    function raz_lms_flush_rewrite_rules()
    {
        raz_lms_register_admin_page();
        flush_rewrite_rules();
    }
}
add_action('after_switch_theme', 'raz_lms_flush_rewrite_rules');


if (!function_exists('raz_lms_maybe_flush_rules')) {
    /**
     * Verificação de segurança para flush de regras.
     */
    function raz_lms_maybe_flush_rules()
    {
        if (get_option('raz_lms_flush_rules') !== 'done') {
            raz_lms_register_admin_page();
            flush_rewrite_rules();
            update_option('raz_lms_flush_rules', 'done');
        }
    }
}
add_action('init', 'raz_lms_maybe_flush_rules', 99);


if (!function_exists('raz_lms_admin_query_vars')) {
    /**
     * Adiciona variáveis de query personalizadas.
     */
    function raz_lms_admin_query_vars($vars)
    {
        $vars[] = 'raz_admin_page';
        $vars[] = 'raz_item_id';
        return $vars;
    }
}
add_filter('query_vars', 'raz_lms_admin_query_vars');


if (!function_exists('raz_lms_admin_template')) {
    /**
     * Carrega o template do painel administrativo.
     */
    function raz_lms_admin_template($template)
    {
        $page = get_query_var('raz_admin_page');

        if (!$page && isset($_GET['raz_admin_page'])) {
            $page = sanitize_text_field($_GET['raz_admin_page']);
        }

        if ($page && current_user_can('manage_options')) {
            global $raz_admin_page, $raz_item_id;
            
            $raz_admin_page = $page;
            $raz_item_id = get_query_var('raz_item_id') ?: (isset($_GET['raz_item_id']) ? intval($_GET['raz_item_id']) : 0);

            if (defined('RAZ_LMS_DIR')) {
                $template_path = RAZ_LMS_DIR . '/templates/admin-panel.php';
                if (file_exists($template_path)) {
                    return $template_path;
                }
            } else {
                $theme_path = get_template_directory() . '/templates/admin-panel.php';
                if (file_exists($theme_path)) {
                    return $theme_path;
                }
            }
        }

        return $template;
    }
}
add_filter('template_include', 'raz_lms_admin_template');


if (!function_exists('raz_lms_admin_bar_menu')) {
    /**
     * Adiciona atalho na Admin Bar.
     */
    function raz_lms_admin_bar_menu($wp_admin_bar)
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $wp_admin_bar->add_node(array(
            'id'    => 'raz-lms-gestao',
            'title' => '📚 Gestão LMS',
            'href'  => home_url('/gestao-cursos/'),
            'meta'  => array('target' => '_self')
        ));
    }
}
add_action('admin_bar_menu', 'raz_lms_admin_bar_menu', 100);


/* ==========================================================================
   2. AJAX HANDLERS: CRUD E FUNCIONALIDADES
   ========================================================================== */

/**
 * IMPORTANTE: A função raz_lms_ajax_toggle_lock foi removida daqui
 * pois já existe em inc/course-tools.php.
 */

/**
 * NOVO: Busca dados da aula para preencher o WP Editor via AJAX
 */
if (!function_exists('raz_lms_ajax_get_aula_data')) {
    function raz_lms_ajax_get_aula_data()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Sem permissão.'));
        }

        $aula_id = isset($_GET['aula_id']) ? intval($_GET['aula_id']) : 0;
        $post = get_post($aula_id);

        if (!$post || $post->post_type !== 'aula') {
            wp_send_json_error(array('message' => 'Aula não encontrada.'));
        }

        // Recupera metadados
        $video_url = get_post_meta($aula_id, '_raz_aula_video_url', true);
        $video_provider = get_post_meta($aula_id, '_raz_aula_video_provider', true);
        $duracao = get_post_meta($aula_id, '_raz_aula_duracao', true);
        $materiais = get_post_meta($aula_id, '_raz_aula_materiais', true);
        $rotina = get_post_meta($aula_id, '_raz_aula_rotina', true);

        // Prepara resposta
        $data = array(
            'id' => $post->ID,
            'title' => $post->post_title,
            // wpautop garante que quebras de linha sejam respeitadas no editor visual
            'content' => wpautop($post->post_content), 
            'video_url' => $video_url,
            'video_provider' => $video_provider,
            'duracao' => $duracao,
            'materiais' => $materiais,
            'rotina' => $rotina
        );

        wp_send_json_success($data);
    }
}
add_action('wp_ajax_raz_get_aula_data', 'raz_lms_ajax_get_aula_data');


if (!function_exists('raz_lms_ajax_save_curso')) {
    /**
     * AJAX: Salva Curso.
     */
    function raz_lms_ajax_save_curso()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Sem permissão de administrador.'));
        }

        $curso_id = isset($_POST['curso_id']) ? intval($_POST['curso_id']) : 0;
        $titulo = sanitize_text_field($_POST['titulo']);
        $descricao = isset($_POST['descricao']) ? wp_kses_post($_POST['descricao']) : '';
        $conteudo = isset($_POST['conteudo']) ? wp_kses_post($_POST['conteudo']) : '';

        $post_data = array(
            'post_title'   => $titulo,
            'post_excerpt' => $descricao,
            'post_content' => $conteudo,
            'post_type'    => 'curso',
            'post_status'  => 'publish'
        );

        if ($curso_id) {
            $post_data['ID'] = $curso_id;
            wp_update_post($post_data);
        } else {
            $curso_id = wp_insert_post($post_data);
        }

        if (!empty($_FILES['thumbnail']['name'])) {
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');

            $attachment_id = media_handle_upload('thumbnail', $curso_id);
            if (!is_wp_error($attachment_id)) {
                set_post_thumbnail($curso_id, $attachment_id);
            }
        } elseif (isset($_POST['thumbnail_id']) && intval($_POST['thumbnail_id']) > 0) {
            set_post_thumbnail($curso_id, intval($_POST['thumbnail_id']));
        }

        if (isset($_POST['produto_woo'])) {
            update_post_meta($curso_id, '_raz_curso_produto_woo', intval($_POST['produto_woo']));
        }
        
        if (isset($_POST['tipo'])) {
            update_post_meta($curso_id, '_raz_curso_tipo', sanitize_text_field($_POST['tipo']));
        }

        if (isset($_POST['dias_acesso'])) {
            update_post_meta($curso_id, '_raz_curso_dias_acesso', intval($_POST['dias_acesso']));
        }
        
        if (isset($_POST['kiwify_id'])) {
            update_post_meta($curso_id, '_raz_curso_kiwify_id', sanitize_text_field($_POST['kiwify_id']));
        }
        
        if (isset($_POST['cor_header'])) {
            update_post_meta($curso_id, '_raz_curso_cor_header', sanitize_hex_color($_POST['cor_header']));
        }
        
        if (isset($_POST['cor_controls'])) {
            update_post_meta($curso_id, '_raz_curso_cor_controls', sanitize_hex_color($_POST['cor_controls']));
        }
        
        $vitalicio = isset($_POST['vitalicio']) && $_POST['vitalicio'] === '1' ? '1' : '';
        if (isset($_POST['tipo']) && $_POST['tipo'] === 'assinatura') {
            $vitalicio = ''; 
        }
        update_post_meta($curso_id, '_raz_curso_vitalicio', $vitalicio);

        wp_send_json_success(array('curso_id' => $curso_id, 'message' => 'Curso salvo com sucesso!'));
    }
}
add_action('wp_ajax_raz_save_curso', 'raz_lms_ajax_save_curso');


if (!function_exists('raz_lms_ajax_save_modulo')) {
    /**
     * AJAX: Salva Módulo.
     */
    function raz_lms_ajax_save_modulo()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Sem permissão.'));
        }

        $modulo_id = isset($_POST['modulo_id']) ? intval($_POST['modulo_id']) : 0;
        
        // Verificação de travamento (Se existir a meta)
        if ($modulo_id && get_post_meta($modulo_id, '_raz_item_locked', true) === '1') {
            wp_send_json_error(array('message' => 'Este módulo está travado. Destrave para editar.'));
            return;
        }

        $titulo = sanitize_text_field($_POST['titulo']);
        $curso_id = intval($_POST['curso_id']);
        $ordem = isset($_POST['ordem']) ? intval($_POST['ordem']) : 0;

        $post_data = array(
            'post_title'  => $titulo,
            'post_type'   => 'modulo',
            'post_status' => 'publish'
        );

        if ($modulo_id) {
            $post_data['ID'] = $modulo_id;
            wp_update_post($post_data);
        } else {
            $modulo_id = wp_insert_post($post_data);
        }

        update_post_meta($modulo_id, '_raz_modulo_curso', $curso_id);
        
        if (isset($_POST['ordem'])) {
            update_post_meta($modulo_id, '_raz_modulo_ordem', $ordem);
        }

        wp_send_json_success(array('modulo_id' => $modulo_id, 'message' => 'Módulo salvo!'));
    }
}
add_action('wp_ajax_raz_save_modulo', 'raz_lms_ajax_save_modulo');


if (!function_exists('raz_lms_ajax_save_aula')) {
    /**
     * AJAX: Salva Aula (incluindo conteúdo do WP Editor).
     */
    function raz_lms_ajax_save_aula()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Sem permissão.'));
        }

        $aula_id = isset($_POST['aula_id']) ? intval($_POST['aula_id']) : 0;
        
        // Verificação de travamento
        if ($aula_id && get_post_meta($aula_id, '_raz_item_locked', true) === '1') {
            wp_send_json_error(array('message' => 'Esta aula está travada. Destrave para editar.'));
            return;
        }

        $titulo = '';
        if (isset($_POST['aula_titulo'])) {
            $titulo = sanitize_text_field($_POST['aula_titulo']);
        } elseif (isset($_POST['title'])) {
            $titulo = sanitize_text_field($_POST['title']);
        } elseif (isset($_POST['titulo'])) {
            $titulo = sanitize_text_field($_POST['titulo']);
        }

        if (empty($titulo)) {
            if ($aula_id) {
                $existing_post = get_post($aula_id);
                $titulo = $existing_post->post_title;
            } else {
                wp_send_json_error(array('message' => 'O título da aula é obrigatório.'));
            }
        }

        // Recuperar Conteúdo - O ID do editor no curso-editar.php é 'raz_aula_content'
        $conteudo = '';
        if (isset($_POST['raz_aula_content'])) {
            $conteudo = $_POST['raz_aula_content'];
        } elseif (isset($_POST['content'])) {
            $conteudo = $_POST['content'];
        } elseif (isset($_POST['conteudo'])) {
            $conteudo = $_POST['conteudo'];
        }
        
        // Sanitização que permite HTML rico (vídeos, iframes, styles)
        $conteudo = wp_kses_post($conteudo);

        $modulo_id = intval($_POST['modulo_id']);
        $ordem = isset($_POST['ordem']) ? intval($_POST['ordem']) : 0;
        $video_provider = isset($_POST['video_provider']) ? sanitize_text_field($_POST['video_provider']) : '';
        $video_url = isset($_POST['video_url']) ? esc_url_raw($_POST['video_url']) : '';
        $duracao = isset($_POST['duracao']) ? sanitize_text_field($_POST['duracao']) : '';

        // Ordem automática
        if (!$ordem && $modulo_id) {
            $existing_aulas = raz_lms_get_aulas($modulo_id);
            $ordem = count($existing_aulas);
        }

        // Versionamento
        if ($aula_id && function_exists('raz_lms_save_content_version')) {
            raz_lms_save_content_version($aula_id, 'auto');
        }

        $post_data = array(
            'post_title'   => $titulo,
            'post_content' => $conteudo, // Salva o HTML do editor
            'post_type'    => 'aula',
            'post_status'  => 'publish'
        );

        if ($aula_id) {
            $post_data['ID'] = $aula_id;
            wp_update_post($post_data);
        } else {
            $aula_id = wp_insert_post($post_data);
        }

        // Salvar Metas
        update_post_meta($aula_id, '_raz_aula_modulo', $modulo_id);
        update_post_meta($aula_id, '_raz_aula_ordem', $ordem);
        update_post_meta($aula_id, '_raz_aula_video_url', $video_url);
        update_post_meta($aula_id, '_raz_aula_video_provider', $video_provider);
        update_post_meta($aula_id, '_raz_aula_duracao', $duracao);

        $tipo = (isset($_POST['video_url']) && !empty($_POST['video_url'])) ? 'video' : 'texto';
        update_post_meta($aula_id, '_raz_aula_tipo', $tipo);

        // Materiais
        $materiais = array();
        if (isset($_POST['materiais'])) {
            $mat_data = $_POST['materiais'];
            if (is_string($mat_data)) {
                $mat_data = json_decode(stripslashes($mat_data), true);
            }
            if (is_array($mat_data)) {
                foreach ($mat_data as $mat) {
                    $materiais[] = array(
                        'nome' => sanitize_text_field($mat['nome'] ?? ''),
                        'display_name' => sanitize_text_field($mat['display_name'] ?? $mat['nome'] ?? ''),
                        'url' => esc_url_raw($mat['url'] ?? ''),
                        'tipo' => sanitize_text_field($mat['tipo'] ?? '')
                    );
                }
            }
        }
        update_post_meta($aula_id, '_raz_aula_materiais', $materiais);

        // Drip Content
        if (isset($_POST['rotina'])) {
            $rotina_raw = $_POST['rotina'];
            $rotina_data = is_string($rotina_raw) ? json_decode(stripslashes($rotina_raw), true) : $rotina_raw;
            
            $rotina_save = array(
                'ativa' => isset($rotina_data['ativa']) && ($rotina_data['ativa'] === 'true' || $rotina_data['ativa'] === true || $rotina_data['ativa'] === '1'),
                'dias' => isset($rotina_data['dias']) ? intval($rotina_data['dias']) : 0,
                'mensagem' => isset($rotina_data['mensagem']) ? sanitize_text_field($rotina_data['mensagem']) : ''
            );
            update_post_meta($aula_id, '_raz_aula_rotina', $rotina_save);
        }

        if (function_exists('raz_lms_clear_auto_draft')) {
            raz_lms_clear_auto_draft($aula_id);
        }

        wp_send_json_success(array('aula_id' => $aula_id, 'message' => 'Aula salva com sucesso!'));
    }
}
add_action('wp_ajax_raz_save_aula', 'raz_lms_ajax_save_aula');


if (!function_exists('raz_lms_ajax_delete_item')) {
    /**
     * AJAX: Deleta Cursos, Módulos ou Aulas.
     */
    function raz_lms_ajax_delete_item()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Sem permissão.'));
        }

        $item_id = intval($_POST['item_id']);
        $tipo = sanitize_text_field($_POST['tipo']);

        // Verificação de travamento
        $is_locked = get_post_meta($item_id, '_raz_item_locked', true) === '1';
        if ($is_locked) {
            wp_send_json_error(array('message' => 'Este item está travado e não pode ser excluído. Destrave primeiro.'));
            return;
        }

        if ($tipo === 'modulo') {
            $aulas = get_posts(array(
                'post_type' => 'aula', 
                'meta_key' => '_raz_aula_modulo', 
                'meta_value' => $item_id, 
                'posts_per_page' => -1
            ));
            
            foreach ($aulas as $aula) {
                wp_delete_post($aula->ID, true);
            }
        }

        $deleted = wp_delete_post($item_id, true);

        if ($deleted) {
            wp_send_json_success(array('message' => 'Item deletado com sucesso!'));
        } else {
            wp_send_json_error(array('message' => 'Erro ao deletar item.'));
        }
    }
}
add_action('wp_ajax_raz_delete_item', 'raz_lms_ajax_delete_item');


if (!function_exists('raz_lms_ajax_reorder')) {
    /**
     * AJAX: Reordena itens via Drag and Drop.
     */
    function raz_lms_ajax_reorder()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Sem permissão.'));
        }

        $items_raw = isset($_POST['items']) ? $_POST['items'] : '[]';
        $items = json_decode(stripslashes($items_raw), true);
        $tipo = sanitize_text_field($_POST['tipo']);

        if (!is_array($items)) {
            wp_send_json_error(array('message' => 'Dados inválidos.'));
        }
        
        // Verifica travamento global ou individual
        foreach ($items as $item_id) {
            if (get_post_meta(intval($item_id), '_raz_item_locked', true) === '1') {
                wp_send_json_error(array('message' => 'A lista contém itens travados. Destrave para reordenar.'));
                return;
            }
        }

        foreach ($items as $index => $item_id) {
            if ($tipo === 'modulo') {
                update_post_meta(intval($item_id), '_raz_modulo_ordem', $index);
            } else {
                update_post_meta(intval($item_id), '_raz_aula_ordem', $index);
            }
        }

        wp_send_json_success(array('message' => 'Ordem atualizada!'));
    }
}
add_action('wp_ajax_raz_reorder', 'raz_lms_ajax_reorder');


/* ==========================================================================
   3. GESTÃO DE ALUNOS, ACESSOS E AUDITORIA
   ========================================================================== */

if (!function_exists('raz_lms_ajax_grant_access')) {
    function raz_lms_ajax_grant_access()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Sem permissão.'));
        }

        $user_id = intval($_POST['user_id']);
        $curso_id = intval($_POST['curso_id']);
        $dias = intval($_POST['dias']) ?: 365;
        
        $vitalicio = (isset($_POST['vitalicio']) && $_POST['vitalicio'] === '1');
        $tipo = isset($_POST['tipo']) ? sanitize_text_field($_POST['tipo']) : 'avulso';
        
        if ($tipo === 'vitalicio') {
            $vitalicio = true;
        }

        if (function_exists('raz_lms_grant_access')) {
            raz_lms_grant_access($user_id, $curso_id, $dias, $vitalicio, $tipo);
        } else {
            $acesso_data = array(
                'inicio' => current_time('mysql'),
                'vitalicio' => $vitalicio,
                'tipo' => $tipo,
                'origem' => 'manual'
            );
            if (!$vitalicio) {
                $acesso_data['expiracao'] = date('Y-m-d', strtotime('+' . $dias . ' days'));
            }
            update_user_meta($user_id, '_raz_curso_acesso_' . $curso_id, $acesso_data);
        }

        wp_send_json_success(array('message' => 'Acesso liberado com sucesso!'));
    }
}
add_action('wp_ajax_raz_grant_access', 'raz_lms_ajax_grant_access');


if (!function_exists('raz_lms_ajax_revoke_access')) {
    function raz_lms_ajax_revoke_access()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Sem permissão.'));
        }

        $user_id = intval($_POST['user_id']);
        $curso_id = intval($_POST['curso_id']);

        delete_user_meta($user_id, '_raz_curso_acesso_' . $curso_id);

        wp_send_json_success(array('message' => 'Acesso removido com sucesso.'));
    }
}
add_action('wp_ajax_raz_revoke_access', 'raz_lms_ajax_revoke_access');


if (!function_exists('raz_lms_ajax_get_user_audit_history')) {
    function raz_lms_ajax_get_user_audit_history()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Sem permissão.'));
        }

        global $wpdb;
        
        $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
        $paged = isset($_POST['paged']) ? intval($_POST['paged']) : 1;
        $per_page = 10; // FIX: Alinhado com o pedido de 10 por página
        $offset = ($paged - 1) * $per_page;

        $table_logs = $wpdb->prefix . 'raz_lms_logs';
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_logs'") === $table_logs;

        $logs = array();
        $total_items = 0;

        if ($table_exists) {
            $total_items = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_logs WHERE user_id = %d", $user_id));
            
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $table_logs WHERE user_id = %d ORDER BY created_at DESC LIMIT %d OFFSET %d",
                $user_id, $per_page, $offset
            ));

            foreach ($results as $row) {
                $logs[] = array(
                    'date' => date_i18n('d/m/Y H:i', strtotime($row->created_at)),
                    'curso' => get_the_title($row->curso_id) ?: '-',
                    'modulo' => $row->modulo_id ? get_the_title($row->modulo_id) : '-',
                    'aula' => get_the_title($row->aula_id) ?: '-',
                    'ip' => isset($row->ip_address) ? $row->ip_address : '-'
                );
            }
        } else {
            // Fallback para usermeta se tabela de logs não existir
            $meta_logs = $wpdb->get_results($wpdb->prepare(
                "SELECT meta_key, meta_value FROM {$wpdb->usermeta} 
                 WHERE user_id = %d AND meta_key LIKE '_raz_lesson_completed_%%' 
                 ORDER BY meta_id DESC", 
                $user_id
            ));

            $total_items = count($meta_logs);
            $sliced_logs = array_slice($meta_logs, $offset, $per_page);

            foreach ($sliced_logs as $meta) {
                $aula_id = str_replace('_raz_lesson_completed_', '', $meta->meta_key);
                $timestamp = $meta->meta_value;
                
                $mod_id = get_post_meta($aula_id, '_raz_aula_modulo', true);
                $curso_id = $mod_id ? get_post_meta($mod_id, '_raz_modulo_curso', true) : 0;
                
                $last_ip = get_user_meta($user_id, '_raz_last_ip', true) ?: '-';

                $logs[] = array(
                    'date' => is_numeric($timestamp) ? date_i18n('d/m/Y H:i', $timestamp) : '-',
                    'curso' => $curso_id ? get_the_title($curso_id) : '-',
                    'modulo' => $mod_id ? get_the_title($mod_id) : '-',
                    'aula' => get_the_title($aula_id) . ' (Conclusão)',
                    'ip' => $last_ip
                );
            }
        }

        $total_pages = ceil($total_items / $per_page);

        // Retorna sucesso mesmo com array vazio, para evitar erro no frontend
        wp_send_json_success(array(
            'logs' => $logs,
            'total_pages' => $total_pages,
            'current_page' => $paged,
            'total_items' => $total_items
        ));
    }
}
add_action('wp_ajax_raz_get_user_audit_history', 'raz_lms_ajax_get_user_audit_history');


if (!function_exists('raz_lms_ajax_get_user_courses')) {
    function raz_lms_ajax_get_user_courses()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Sem permissão.'));
        }

        $user_id = intval($_REQUEST['user_id']);
        
        $user_courses = raz_lms_get_user_courses($user_id);
        $courses_data = array();

        foreach ($user_courses as $curso) {
            $acesso = get_user_meta($user_id, '_raz_curso_acesso_' . $curso->ID, true);
            $tipo_curso = isset($acesso['tipo']) ? $acesso['tipo'] : 'avulso';
            $expiracao = '-';
            $is_vitalicio = isset($acesso['vitalicio']) && $acesso['vitalicio'];
            
            if ($is_vitalicio) {
                $expiracao = 'Vitalício';
            } elseif (isset($acesso['expiracao'])) {
                $data_fmt = date_i18n('d/m/Y', strtotime($acesso['expiracao']));
                if ($tipo_curso === 'assinatura') {
                    $expiracao = 'Renova em ' . $data_fmt;
                } else {
                    $expiracao = 'Até ' . $data_fmt;
                }
            }

            $courses_data[] = array(
                'id' => $curso->ID,
                'nome' => $curso->post_title,
                'tipo' => $tipo_curso,
                'expiracao' => $expiracao,
                'vitalicio' => $is_vitalicio,
                'expirado' => (!$is_vitalicio && isset($acesso['expiracao']) && strtotime($acesso['expiracao']) < time())
            );
        }

        wp_send_json_success(array('courses' => $courses_data, 'data' => $courses_data));
    }
}
add_action('wp_ajax_raz_get_user_courses', 'raz_lms_ajax_get_user_courses');


if (!function_exists('raz_lms_ajax_get_user_data')) {
    function raz_lms_ajax_get_user_data()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Sem permissão.'));
        }

        $user_id = intval($_GET['user_id']);
        $user = get_userdata($user_id);

        if (!$user) {
            wp_send_json_error(array('message' => 'Usuário não encontrado.'));
        }

        $cursos = array();
        global $wpdb;
        $metas = $wpdb->get_results($wpdb->prepare(
            "SELECT meta_key FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key LIKE '_raz_curso_acesso_%%'",
            $user_id
        ));

        foreach ($metas as $meta) {
            $curso_id = str_replace('_raz_curso_acesso_', '', $meta->meta_key);
            $cursos[] = intval($curso_id);
        }

        $telefone = get_user_meta($user_id, '_raz_telefone', true);

        wp_send_json_success(array(
            'id' => $user->ID,
            'name' => $user->display_name,
            'email' => $user->user_email,
            'telefone' => $telefone,
            'cursos' => $cursos
        ));
    }
}
add_action('wp_ajax_raz_get_user_data', 'raz_lms_ajax_get_user_data');

/*
if (!function_exists('raz_lms_ajax_save_user')) {
    function raz_lms_ajax_save_user()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Sem permissão.'));
        }

        $user_id = isset($_POST['user_id']) && !empty($_POST['user_id']) ? intval($_POST['user_id']) : 0;
        $display_name = sanitize_text_field($_POST['display_name']);
        $email = sanitize_email($_POST['email']);
        $telefone = isset($_POST['telefone']) ? sanitize_text_field($_POST['telefone']) : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        $cursos = isset($_POST['cursos']) ? array_map('intval', $_POST['cursos']) : array();
        
        $acesso_tipo = isset($_POST['acesso_tipo']) ? sanitize_text_field($_POST['acesso_tipo']) : 'avulso';
        $dias = isset($_POST['dias']) ? intval($_POST['dias']) : 365;

        // Ajuste padrão assinatura mensal
        if ($acesso_tipo === 'assinatura' && $dias == 365) {
            $dias = 30;
        }

        if (empty($display_name) || empty($email)) {
            wp_send_json_error(array('message' => 'Nome e email são obrigatórios.'));
        }

        // Edição
        if ($user_id) {
            $existing = get_user_by('email', $email);
            if ($existing && $existing->ID != $user_id) {
                wp_send_json_error(array('message' => 'Email em uso por outro usuário.'));
            }

            wp_update_user(array(
                'ID' => $user_id,
                'display_name' => $display_name,
                'user_email' => $email
            ));

            if (!empty($password)) {
                wp_set_password($password, $user_id);
            }
        } 
        // Criação
        else {
            if (email_exists($email)) {
                wp_send_json_error(array('message' => 'Email já cadastrado.'));
            }

            $username = sanitize_user(explode('@', $email)[0]);
            $original = $username;
            $counter = 1;
            while (username_exists($username)) {
                $username = $original . $counter;
                $counter++;
            }

            if (empty($password)) {
                $password = wp_generate_password(12, false);
            }

            $user_id = wp_create_user($username, $password, $email);

            if (is_wp_error($user_id)) {
                wp_send_json_error(array('message' => $user_id->get_error_message()));
            }

            wp_update_user(array(
                'ID' => $user_id,
                'display_name' => $display_name,
                'first_name' => explode(' ', $display_name)[0]
            ));

            // Email
            $subject = 'Seus dados de acesso - ' . get_bloginfo('name');
            $message = "Olá {$display_name},\n\n";
            $message .= "Sua conta foi criada!\n\n";
            $message .= "Login: {$email}\n";
            $message .= "Senha: {$password}\n\n";
            $message .= "Acesse: " . home_url('/entrar');
            
            wp_mail($email, $subject, $message);
        }

        update_user_meta($user_id, '_raz_telefone', $telefone);

        // Atualizar Acessos
        global $wpdb;
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key LIKE '_raz_curso_acesso_%%'",
            $user_id
        ));

        foreach ($cursos as $curso_id) {
            $data = array(
                'inicio' => current_time('mysql'),
                'tipo' => $acesso_tipo,
                'vitalicio' => ($acesso_tipo === 'vitalicio')
            );
            
            if ($acesso_tipo !== 'vitalicio') {
                $data['expiracao'] = date('Y-m-d', strtotime("+$dias days"));
            }
            
            update_user_meta($user_id, '_raz_curso_acesso_' . $curso_id, $data);
        }

        wp_send_json_success(array('message' => 'Aluno salvo com sucesso!'));
    }
}
add_action('wp_ajax_raz_save_user', 'raz_lms_ajax_save_user');
*/

if (!function_exists('raz_lms_ajax_delete_user')) {
    /**
     * AJAX: Excluir Usuário.
     */
    function raz_lms_ajax_delete_user()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Sem permissão.'));
        }

        $user_id = intval($_POST['user_id']);

        if ($user_id == get_current_user_id() || user_can($user_id, 'manage_options')) {
            wp_send_json_error(array('message' => 'Ação não permitida.'));
        }

        require_once(ABSPATH . 'wp-admin/includes/user.php');
        wp_delete_user($user_id);

        wp_send_json_success(array('message' => 'Usuário excluído.'));
    }
}
add_action('wp_ajax_raz_delete_user', 'raz_lms_ajax_delete_user');


/* ==========================================================================
   4. FUNÇÕES DE DUPLICAÇÃO DE CONTEÚDO (NOVO)
   ========================================================================== */

if (!function_exists('raz_lms_ajax_get_modules_by_course')) {
    /**
     * AJAX: Retorna lista de módulos.
     */
    function raz_lms_ajax_get_modules_by_course()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error();
        }

        $curso_id = intval($_GET['curso_id']);
        
        $modules = get_posts(array(
            'post_type' => 'modulo',
            'posts_per_page' => -1,
            'meta_key' => '_raz_modulo_curso',
            'meta_value' => $curso_id,
            'orderby' => 'meta_value_num',
            'order' => 'ASC'
        ));

        // Reordenação manual via meta 'ordem'
        usort($modules, function($a, $b) {
            $ordem_a = (int) get_post_meta($a->ID, '_raz_modulo_ordem', true);
            $ordem_b = (int) get_post_meta($b->ID, '_raz_modulo_ordem', true);
            return $ordem_a - $ordem_b;
        });

        $data = array();
        foreach ($modules as $m) {
            $data[] = array(
                'id' => $m->ID,
                'title' => $m->post_title
            );
        }

        wp_send_json_success($data);
    }
}
add_action('wp_ajax_raz_get_modules_by_course', 'raz_lms_ajax_get_modules_by_course');


if (!function_exists('raz_lms_ajax_duplicate_content')) {
    /**
     * AJAX: Duplica Aula ou Módulo (Deep Copy).
     */
    function raz_lms_ajax_duplicate_content()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Sem permissão.'));
        }

        $type = sanitize_text_field($_POST['type']); // 'aula' ou 'modulo'
        $source_id = intval($_POST['source_id']);
        $target_course_id = intval($_POST['target_course_id']);
        
        if (!$source_id || !$target_course_id) {
            wp_send_json_error(array('message' => 'Dados inválidos.'));
        }

        // --- HELPER INTERNO: Copiar Aula ---
        if (!function_exists('raz_lms_copy_lesson')) {
            function raz_lms_copy_lesson($lesson_id, $target_module_id) {
                $source = get_post($lesson_id);
                if (!$source) return false;

                $new_id = wp_insert_post(array(
                    'post_title' => $source->post_title . ' (Cópia)',
                    'post_content' => $source->post_content,
                    'post_type' => 'aula',
                    'post_status' => 'publish'
                ));

                $metas = array(
                    '_raz_aula_video_url', 
                    '_raz_aula_video_provider', 
                    '_raz_aula_duracao', 
                    '_raz_aula_tipo', 
                    '_raz_aula_materiais', 
                    '_raz_aula_ordem',
                    '_raz_aula_rotina'
                );

                foreach ($metas as $k) {
                    $v = get_post_meta($lesson_id, $k, true);
                    if ($v) update_post_meta($new_id, $k, $v);
                }

                update_post_meta($new_id, '_raz_aula_modulo', $target_module_id);
                return $new_id;
            }
        }

        // DUPLICAR AULA
        if ($type === 'aula') {
            $target_module_id = intval($_POST['target_module_id']);
            if (!$target_module_id) {
                wp_send_json_error(array('message' => 'Selecione o módulo de destino.'));
            }

            raz_lms_copy_lesson($source_id, $target_module_id);
            wp_send_json_success(array('message' => 'Aula duplicada com sucesso!'));
        }

        // DUPLICAR MÓDULO
        if ($type === 'modulo') {
            $source_mod = get_post($source_id);
            if (!$source_mod) {
                wp_send_json_error(array('message' => 'Módulo original não encontrado.'));
            }

            // 1. Criar novo módulo
            $new_mod_id = wp_insert_post(array(
                'post_title' => $source_mod->post_title . ' (Cópia)',
                'post_type' => 'modulo',
                'post_status' => 'publish'
            ));

            // Vincular ao novo curso e manter ordem
            update_post_meta($new_mod_id, '_raz_modulo_curso', $target_course_id);
            $ordem = get_post_meta($source_id, '_raz_modulo_ordem', true);
            update_post_meta($new_mod_id, '_raz_modulo_ordem', $ordem);

            // 2. Duplicar todas as aulas do módulo original
            $lessons = get_posts(array(
                'post_type' => 'aula',
                'meta_key' => '_raz_aula_modulo',
                'meta_value' => $source_id,
                'posts_per_page' => -1,
                'post_status' => 'publish'
            ));
            
            // Helper interno para duplicação em massa (sem sufixo cópia)
            if (!function_exists('raz_lms_copy_lesson_internal')) {
                function raz_lms_copy_lesson_internal($lesson_id, $target_mod_id) {
                    $source = get_post($lesson_id);
                    if (!$source) return;
                    
                    $new_id = wp_insert_post(array(
                        'post_title' => $source->post_title, // Mantém nome original
                        'post_content' => $source->post_content,
                        'post_type' => 'aula',
                        'post_status' => 'publish'
                    ));
                    
                    $metas = array(
                        '_raz_aula_video_url', 
                        '_raz_aula_video_provider', 
                        '_raz_aula_duracao', 
                        '_raz_aula_tipo', 
                        '_raz_aula_materiais', 
                        '_raz_aula_ordem', 
                        '_raz_aula_rotina'
                    );

                    foreach ($metas as $k) {
                        $v = get_post_meta($lesson_id, $k, true);
                        if ($v) update_post_meta($new_id, $k, $v);
                    }
                    
                    update_post_meta($new_id, '_raz_aula_modulo', $target_mod_id);
                }
            }

            foreach ($lessons as $lesson) {
                raz_lms_copy_lesson_internal($lesson->ID, $new_mod_id);
            }

            wp_send_json_success(array('message' => 'Módulo e todas as aulas duplicados com sucesso!'));
        }
    }
}
add_action('wp_ajax_raz_duplicate_content', 'raz_lms_ajax_duplicate_content');


/* ==========================================================================
   5. EXPORTAÇÃO CSV E RELATÓRIOS
   ========================================================================== */

/**
 * AJAX: Exportar Alunos (CSV)
 */
if (!function_exists('raz_lms_ajax_export_alunos')) {
    function raz_lms_ajax_export_alunos()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die('Sem permissão');
        }

        global $wpdb;

        $curso_id = isset($_GET['curso']) ? intval($_GET['curso']) : 0;
        $periodo_de = isset($_GET['periodo_de']) ? sanitize_text_field($_GET['periodo_de']) : '';
        $periodo_ate = isset($_GET['periodo_ate']) ? sanitize_text_field($_GET['periodo_ate']) : '';

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=alunos_' . date('Y-m-d') . '.csv');
        header('Pragma: no-cache');
        header('Expires: 0');

        $output = fopen('php://output', 'w');
        // BOM para Excel
        fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

        fputcsv($output, array('Nome', 'Email', 'Telefone', 'Curso', 'Data Início', 'Expiração', 'Status', 'Origem', 'Progresso'), ';');

        $where = "WHERE meta_key LIKE '_raz_curso_acesso_%'";
        if ($curso_id) {
            $where .= $wpdb->prepare(" AND meta_key = %s", '_raz_curso_acesso_' . $curso_id);
        }

        $acessos = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} {$where}");

        foreach ($acessos as $acesso) {
            $data = maybe_unserialize($acesso->meta_value);

            if ($periodo_de && isset($data['inicio']) && strtotime($data['inicio']) < strtotime($periodo_de)) continue;
            if ($periodo_ate && isset($data['inicio']) && strtotime($data['inicio']) > strtotime($periodo_ate . ' 23:59:59')) continue;

            $user = get_userdata($acesso->user_id);
            $cid = str_replace('_raz_curso_acesso_', '', $acesso->meta_key);
            $curso = get_post($cid);

            if (!$user || !$curso) continue;

            $ativo = raz_lms_user_has_access($acesso->user_id, $cid);
            $tipo_curso = isset($data['tipo']) ? $data['tipo'] : 'avulso';

            $exp = '';
            if (isset($data['vitalicio']) && $data['vitalicio']) {
                $exp = 'Vitalício';
            } elseif (isset($data['expiracao'])) {
                $data_fmt = date_i18n('d/m/Y', strtotime($data['expiracao']));
                $exp = ($tipo_curso === 'assinatura') ? 'Renova em ' . $data_fmt : $data_fmt;
            }

            $telefone = get_user_meta($acesso->user_id, '_raz_telefone', true);
            $origem = isset($data['origem']) ? $data['origem'] : 'manual';
            $progress = raz_lms_get_course_progress($acesso->user_id, $cid);

            fputcsv($output, array(
                $user->display_name,
                $user->user_email,
                $telefone ?: '',
                $curso->post_title,
                isset($data['inicio']) ? date_i18n('d/m/Y', strtotime($data['inicio'])) : '',
                $exp,
                $ativo ? 'Ativo' : 'Expirado',
                ucfirst($origem),
                $progress['percent'] . '%'
            ), ';');
        }

        fclose($output);
        exit;
    }
}
add_action('wp_ajax_raz_export_alunos', 'raz_lms_ajax_export_alunos');

/**
 * AJAX: Exportar Progresso
 */
if (!function_exists('raz_lms_ajax_export_progresso')) {
    function raz_lms_ajax_export_progresso()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die('Sem permissão');
        }

        global $wpdb;

        $curso_id = isset($_GET['curso']) ? intval($_GET['curso']) : 0;
        $modulo_id = isset($_GET['modulo']) ? intval($_GET['modulo']) : 0;
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=progresso_' . date('Y-m-d') . '.csv');
        header('Pragma: no-cache');
        header('Expires: 0');

        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

        $header = array('Aluno', 'Email', 'Telefone', 'Curso');
        if ($modulo_id) $header[] = 'Módulo';
        $header = array_merge($header, array('Progresso', 'Aulas Concluídas', 'Total Aulas', 'Último Acesso'));
        fputcsv($output, $header, ';');

        $where = "WHERE meta_key LIKE '_raz_curso_acesso_%'";
        if ($curso_id) {
            $where .= $wpdb->prepare(" AND meta_key = %s", '_raz_curso_acesso_' . $curso_id);
        }

        $acessos = $wpdb->get_results("SELECT user_id, meta_key FROM {$wpdb->usermeta} {$where}");

        foreach ($acessos as $acesso) {
            $user = get_userdata($acesso->user_id);
            $cid = str_replace('_raz_curso_acesso_', '', $acesso->meta_key);
            $curso = get_post($cid);

            if (!$user || !$curso) continue;

            $telefone = get_user_meta($acesso->user_id, '_raz_telefone', true);
            $ultimo_acesso = get_user_meta($acesso->user_id, '_raz_last_login', true);
            $ultimo_acesso_fmt = $ultimo_acesso ? date_i18n('d/m/Y H:i', strtotime($ultimo_acesso)) : '-';

            if ($modulo_id) {
                $modulo = get_post($modulo_id);
                // Verifica se módulo pertence ao curso
                if (!$modulo || get_post_meta($modulo->ID, '_raz_modulo_curso', true) != $cid) continue;
                
                $p = raz_lms_get_module_progress($acesso->user_id, $modulo_id);
                
                fputcsv($output, array(
                    $user->display_name,
                    $user->user_email,
                    $telefone,
                    $curso->post_title,
                    $modulo->post_title,
                    $p['percent'] . '%',
                    $p['completed'],
                    $p['total'],
                    $ultimo_acesso_fmt
                ), ';');
            } else {
                $p = raz_lms_get_course_progress($acesso->user_id, $cid);
                
                fputcsv($output, array(
                    $user->display_name,
                    $user->user_email,
                    $telefone,
                    $curso->post_title,
                    $p['percent'] . '%',
                    $p['completed'],
                    $p['total'],
                    $ultimo_acesso_fmt
                ), ';');
            }
        }

        fclose($output);
        exit;
    }
}
add_action('wp_ajax_raz_export_progresso', 'raz_lms_ajax_export_progresso');

/**
 * AJAX: Exportar Conclusões
 */
if (!function_exists('raz_lms_ajax_export_conclusoes')) {
    function raz_lms_ajax_export_conclusoes()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) wp_die('Sem permissão');

        global $wpdb;
        $curso_id = isset($_GET['curso']) ? intval($_GET['curso']) : 0;
        $modulo_id = isset($_GET['modulo']) ? intval($_GET['modulo']) : 0;

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=conclusoes_' . date('Y-m-d') . '.csv');
        header('Pragma: no-cache');
        header('Expires: 0');

        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

        fputcsv($output, array('Curso', 'Módulo', 'Aula', 'Total Alunos (Ativos)', 'Conclusões', 'Taxa de Conclusão'), ';');

        // Se curso definido, pega só ele, senão todos
        $cursos = $curso_id ? array(get_post($curso_id)) : get_posts(array('post_type' => 'curso', 'posts_per_page' => -1));

        foreach ($cursos as $curso) {
            if (!$curso) continue;

            $total_alunos = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s",
                '_raz_curso_acesso_' . $curso->ID
            ));
            
            if ($total_alunos == 0) continue;

            $alunos_ids = $wpdb->get_col($wpdb->prepare(
                "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s",
                '_raz_curso_acesso_' . $curso->ID
            ));

            $modulos_query = array(
                'post_type' => 'modulo',
                'posts_per_page' => -1,
                'meta_query' => array(array('key' => '_raz_modulo_curso', 'value' => $curso->ID)),
                'orderby' => 'meta_value_num',
                'meta_key' => '_raz_modulo_ordem',
                'order' => 'ASC'
            );
            if ($modulo_id) $modulos_query['p'] = $modulo_id;

            $modulos = get_posts($modulos_query);

            foreach ($modulos as $modulo) {
                $aulas = raz_lms_get_aulas($modulo->ID);
                foreach ($aulas as $aula) {
                    $conclusoes = 0;
                    foreach ($alunos_ids as $uid) {
                        if (raz_lms_is_lesson_completed($uid, $aula->ID)) $conclusoes++;
                    }
                    $taxa = $total_alunos > 0 ? round(($conclusoes / $total_alunos) * 100, 2) : 0;

                    fputcsv($output, array(
                        $curso->post_title,
                        $modulo->post_title,
                        $aula->post_title,
                        $total_alunos,
                        $conclusoes,
                        $taxa . '%'
                    ), ';');
                }
            }
        }

        fclose($output);
        exit;
    }
}
add_action('wp_ajax_raz_export_conclusoes', 'raz_lms_ajax_export_conclusoes');

/**
 * AJAX: Exportar Relatório Completo
 */
if (!function_exists('raz_lms_ajax_export_completo')) {
    function raz_lms_ajax_export_completo()
    {
        check_ajax_referer('raz_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) wp_die('Sem permissão');

        global $wpdb;
        $curso_id = isset($_GET['curso']) ? intval($_GET['curso']) : 0;
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=relatorio_completo_' . date('Y-m-d') . '.csv');
        header('Pragma: no-cache');
        header('Expires: 0');

        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

        fputcsv($output, array(
            'ID Aluno', 'Nome', 'Email', 'Telefone', 'Curso', 'Data Início',
            'Status Acesso', 'Progresso Geral (%)', 'Aulas Completas', 'Total Aulas', 'Último Acesso'
        ), ';');

        $where = "WHERE meta_key LIKE '_raz_curso_acesso_%'";
        if ($curso_id) {
            $where .= $wpdb->prepare(" AND meta_key = %s", '_raz_curso_acesso_' . $curso_id);
        }

        $acessos = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} {$where}");

        foreach ($acessos as $acesso) {
            $data = maybe_unserialize($acesso->meta_value);
            
            $user = get_userdata($acesso->user_id);
            $cid = str_replace('_raz_curso_acesso_', '', $acesso->meta_key);
            $curso = get_post($cid);

            if (!$user || !$curso) continue;

            $telefone = get_user_meta($acesso->user_id, '_raz_telefone', true);
            $ativo = raz_lms_user_has_access($acesso->user_id, $cid);
            $p = raz_lms_get_course_progress($acesso->user_id, $cid);
            $ultimo_acesso = get_user_meta($acesso->user_id, '_raz_last_login', true);

            fputcsv($output, array(
                $user->ID,
                $user->display_name,
                $user->user_email,
                $telefone,
                $curso->post_title,
                isset($data['inicio']) ? date_i18n('d/m/Y', strtotime($data['inicio'])) : '',
                $ativo ? 'Ativo' : 'Expirado',
                $p['percent'] . '%',
                $p['completed'],
                $p['total'],
                $ultimo_acesso ? date_i18n('d/m/Y H:i', strtotime($ultimo_acesso)) : '-'
            ), ';');
        }

        fclose($output);
        exit;
    }
}
add_action('wp_ajax_raz_export_completo', 'raz_lms_ajax_export_completo');