<?php
/**
 * Sistema de Emails Automáticos
 * @package RazMidiasLMS
 */

defined('ABSPATH') || exit;

/**
 * Enviar email com credenciais de acesso (para novos usuários via webhook)
 */
function raz_lms_send_credentials_email($user_id, $password) {
    $user = get_userdata($user_id);
    if (!$user) return false;
    
    $site_name = get_bloginfo('name');
    $login_url = home_url('/entrar');
    
    $subject = 'Bem-vindo! Seus dados de acesso - ' . $site_name;
    
    $message = '<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;">';
    $message .= '<h2 style="color:#1e293b;">Olá ' . esc_html($user->display_name) . '!</h2>';
    $message .= '<p>Sua conta foi criada com sucesso. Aqui estão seus dados de acesso:</p>';
    $message .= '<div style="background:#f8fafc;padding:20px;border-radius:8px;margin:20px 0;">';
    $message .= '<p><strong>Email:</strong> ' . esc_html($user->user_email) . '</p>';
    $message .= '<p><strong>Senha:</strong> ' . esc_html($password) . '</p>';
    $message .= '</div>';
    $message .= '<p><a href="' . esc_url($login_url) . '" style="display:inline-block;background:#6366f1;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;">Acessar Plataforma</a></p>';
    $message .= '<p style="color:#64748b;font-size:14px;margin-top:20px;">Recomendamos que você altere sua senha após o primeiro acesso.</p>';
    $message .= '<hr style="border:none;border-top:1px solid #e2e8f0;margin:20px 0;">';
    $message .= '<p style="color:#94a3b8;font-size:12px;">' . esc_html($site_name) . '</p>';
    $message .= '</div>';
    
    $headers = array('Content-Type: text/html; charset=UTF-8');
    
    return wp_mail($user->user_email, $subject, $message, $headers);
}

/**
 * Enviar email de acesso liberado (para usuários existentes)
 */
function raz_lms_send_access_granted_email($user_id, $curso_id) {
    $user = get_userdata($user_id);
    $curso = get_post($curso_id);
    
    if (!$user || !$curso) return false;
    
    $site_name = get_bloginfo('name');
    $curso_url = home_url('/meus-cursos');
    
    $subject = 'Acesso liberado: ' . $curso->post_title . ' - ' . $site_name;
    
    $message = '<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;">';
    $message .= '<h2 style="color:#1e293b;">Olá ' . esc_html($user->display_name) . '!</h2>';
    $message .= '<p>Seu acesso ao curso <strong>' . esc_html($curso->post_title) . '</strong> foi liberado!</p>';
    $message .= '<p><a href="' . esc_url($curso_url) . '" style="display:inline-block;background:#10b981;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;">Acessar Meus Cursos</a></p>';
    $message .= '<p style="color:#64748b;margin-top:20px;">Bons estudos!</p>';
    $message .= '<hr style="border:none;border-top:1px solid #e2e8f0;margin:20px 0;">';
    $message .= '<p style="color:#94a3b8;font-size:12px;">' . esc_html($site_name) . '</p>';
    $message .= '</div>';
    
    $headers = array('Content-Type: text/html; charset=UTF-8');
    
    return wp_mail($user->user_email, $subject, $message, $headers);
}

/**
 * Enviar email de boas-vindas (configurável pelo admin)
 */
function raz_lms_send_welcome_email($user_id, $curso_id, $password = null) {
    // Definição de Padrões
    $defaults = array(
        'ativo' => '1',
        'assunto' => 'Bem-vindo ao {curso}!',
        'mensagem' => "Olá {nome},\n\nSeja bem-vindo ao curso {curso}!\n\nVocê já pode começar a estudar acessando:\n{link_curso}\n\nSeu acesso é válido até: {data_expiracao}\n\nBons estudos!\n{site_nome}"
    );

    $config = get_option('raz_lms_email_boas_vindas', $defaults);
    
    if (!is_array($config)) $config = $defaults;
    $config = wp_parse_args($config, $defaults);
    
    if (empty($config['ativo'])) {
        return false;
    }
    
    $user = get_userdata($user_id);
    $curso = get_post($curso_id);
    $acesso = get_user_meta($user_id, '_raz_curso_acesso_' . $curso_id, true);
    
    if (!$user || !$curso) {
        return false;
    }
    
    $expiracao = 'Vitalício';
    if (isset($acesso['expiracao']) && !($acesso['vitalicio'] ?? false)) {
        $expiracao = date_i18n('d/m/Y', strtotime($acesso['expiracao']));
    }
    
    // Tratamento da senha
    $senha_texto = $password ? $password : 'Utilize sua senha atual';
    
    $vars = array(
        '{nome}' => $user->display_name,
        '{email}' => $user->user_email,
        '{senha}' => $senha_texto,
        '{curso}' => $curso->post_title,
        '{link_curso}' => get_permalink($curso_id),
        '{data_expiracao}' => $expiracao,
        '{site_nome}' => get_bloginfo('name'),
        '{site_url}' => home_url()
    );
    
    $assunto = str_replace(array_keys($vars), array_values($vars), $config['assunto']);
    $mensagem = str_replace(array_keys($vars), array_values($vars), $config['mensagem']);
    $mensagem = nl2br($mensagem);
    
    $headers = array('Content-Type: text/html; charset=UTF-8');
    
    return wp_mail($user->user_email, $assunto, $mensagem, $headers);
}

/**
 * Enviar email de acesso expirando
 */
function raz_lms_send_expiring_email($user_id, $curso_id, $dias_restantes) {
    $defaults = array(
        'ativo' => '1',
        'assunto' => 'Seu acesso expira em breve!',
        'mensagem' => "Olá {nome},\n\nFaltam {dias_restantes} dias para seu acesso acabar."
    );
    
    $config = get_option('raz_lms_email_expirando', $defaults);
    if (!is_array($config)) $config = $defaults;
    $config = wp_parse_args($config, $defaults);
    
    if (empty($config['ativo'])) return false;
    
    $user = get_userdata($user_id);
    $curso = get_post($curso_id);
    $acesso = get_user_meta($user_id, '_raz_curso_acesso_' . $curso_id, true);
    
    if (!$user || !$curso) return false;
    
    $expiracao = isset($acesso['expiracao']) ? date_i18n('d/m/Y', strtotime($acesso['expiracao'])) : '';
    
    $vars = array(
        '{nome}' => $user->display_name,
        '{email}' => $user->user_email,
        '{curso}' => $curso->post_title,
        '{link_curso}' => get_permalink($curso_id),
        '{data_expiracao}' => $expiracao,
        '{dias_restantes}' => $dias_restantes,
        '{site_nome}' => get_bloginfo('name'),
        '{site_url}' => home_url()
    );
    
    $assunto = str_replace(array_keys($vars), array_values($vars), $config['assunto']);
    $mensagem = str_replace(array_keys($vars), array_values($vars), $config['mensagem']);
    $mensagem = nl2br($mensagem);
    
    $headers = array('Content-Type: text/html; charset=UTF-8');
    
    return wp_mail($user->user_email, $assunto, $mensagem, $headers);
}

/**
 * Enviar email de conclusão
 */
function raz_lms_send_completion_email($user_id, $curso_id) {
    $defaults = array(
        'ativo' => '0',
        'assunto' => 'Parabéns pela conclusão!',
        'mensagem' => "Parabéns {nome}!"
    );

    $config = get_option('raz_lms_email_conclusao', $defaults);
    if (!is_array($config)) $config = $defaults;
    $config = wp_parse_args($config, $defaults);
    
    if (empty($config['ativo'])) return false;
    
    $sent = get_user_meta($user_id, '_raz_email_conclusao_' . $curso_id, true);
    if ($sent) return false;
    
    $user = get_userdata($user_id);
    $curso = get_post($curso_id);
    
    if (!$user || !$curso) return false;
    
    $vars = array(
        '{nome}' => $user->display_name,
        '{email}' => $user->user_email,
        '{curso}' => $curso->post_title,
        '{link_curso}' => get_permalink($curso_id),
        '{link_certificado}' => home_url('/certificado/?curso=' . $curso_id . '&user=' . $user_id),
        '{site_nome}' => get_bloginfo('name'),
        '{site_url}' => home_url()
    );
    
    $assunto = str_replace(array_keys($vars), array_values($vars), $config['assunto']);
    $mensagem = str_replace(array_keys($vars), array_values($vars), $config['mensagem']);
    $mensagem = nl2br($mensagem);
    
    $headers = array('Content-Type: text/html; charset=UTF-8');
    
    $result = wp_mail($user->user_email, $assunto, $mensagem, $headers);
    
    if ($result) {
        update_user_meta($user_id, '_raz_email_conclusao_' . $curso_id, date('Y-m-d H:i:s'));
    }
    
    return $result;
}

/**
 * Hook: Enviar email de boas-vindas ao liberar acesso
 */
add_action('raz_lms_access_granted', 'raz_lms_send_welcome_email', 10, 3);

/**
 * Verificar conclusão de curso e enviar email
 */
function raz_lms_check_completion_email($user_id, $curso_id) {
    $progress = raz_lms_get_course_progress($user_id, $curso_id);
    if ($progress['percent'] >= 100) {
        raz_lms_send_completion_email($user_id, $curso_id);
    }
}

/**
 * Cron: Verificar acessos expirando
 */
function raz_lms_cron_check_expiring() {
    global $wpdb;
    $config = get_option('raz_lms_email_expirando', array());
    if (empty($config['ativo'])) return;
    
    $dias_antes = isset($config['dias_antes']) ? intval($config['dias_antes']) : 7;
    $acessos = $wpdb->get_results("SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE meta_key LIKE '_raz_curso_acesso_%'");
    
    foreach ($acessos as $acesso) {
        $data = maybe_unserialize($acesso->meta_value);
        if (isset($data['vitalicio']) && $data['vitalicio']) continue;
        
        if (isset($data['expiracao'])) {
            $exp_date = strtotime($data['expiracao']);
            $now = time();
            $diff_days = round(($exp_date - $now) / (60 * 60 * 24));
            
            if ($diff_days == $dias_antes) {
                $curso_id = str_replace('_raz_curso_acesso_', '', $acesso->meta_key);
                $sent_key = '_raz_email_expirando_' . $curso_id;
                $last_sent = get_user_meta($acesso->user_id, $sent_key, true);
                
                if ($last_sent !== date('Y-m-d')) {
                    $result = raz_lms_send_expiring_email($acesso->user_id, $curso_id, $diff_days);
                    if ($result) {
                        update_user_meta($acesso->user_id, $sent_key, date('Y-m-d'));
                    }
                }
            }
        }
    }
}

/**
 * Registrar cron event
 */
function raz_lms_schedule_cron() {
    if (!wp_next_scheduled('raz_lms_daily_cron')) {
        wp_schedule_event(time(), 'daily', 'raz_lms_daily_cron');
    }
}
add_action('wp', 'raz_lms_schedule_cron');
add_action('raz_lms_daily_cron', 'raz_lms_cron_check_expiring');

function raz_lms_clear_cron() {
    wp_clear_scheduled_hook('raz_lms_daily_cron');
}
add_action('switch_theme', 'raz_lms_clear_cron');

/* ==========================================================================
   PERSONALIZAÇÃO DE REMETENTE
   ========================================================================== */

/**
 * Alterar Nome do Remetente (De "WordPress" para "Nome do Site")
 */
add_filter('wp_mail_from_name', function($original_email_from) {
    // Retorna o nome do site definido em Configurações > Geral
    return get_bloginfo('name');
});

/**
 * Alterar E-mail do Remetente (De "wordpress@" para "no-reply@")
 */
add_filter('wp_mail_from', function($original_email_address) {
    // Pega o domínio do site atual (ex: razmidias.com.br)
    $sitename = strtolower($_SERVER['SERVER_NAME']);
    if (substr($sitename, 0, 4) == 'www.') {
        $sitename = substr($sitename, 4);
    }
    // Retorna no-reply@dominio.com
    return 'no-reply@' . $sitename;
});