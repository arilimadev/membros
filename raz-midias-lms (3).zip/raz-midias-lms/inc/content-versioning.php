<?php
/**
 * Sistema de Versionamento e Rascunho Automático
 * @package RazMidiasLMS
 */

defined('ABSPATH') || exit;

/**
 * Criar tabela de versões
 */
function raz_lms_create_versions_table() {
    global $wpdb;
    $table = $wpdb->prefix . 'raz_content_versions';
    $charset = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE IF NOT EXISTS {$table} (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        post_id BIGINT(20) UNSIGNED NOT NULL,
        post_type VARCHAR(50) NOT NULL,
        content LONGTEXT NOT NULL,
        meta_data LONGTEXT,
        version_type VARCHAR(20) DEFAULT 'manual',
        created_at DATETIME NOT NULL,
        created_by BIGINT(20) UNSIGNED NOT NULL,
        PRIMARY KEY (id),
        KEY post_id (post_id),
        KEY created_at (created_at)
    ) {$charset};";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    // Tabela de rascunhos
    $table_draft = $wpdb->prefix . 'raz_auto_drafts';
    $sql_draft = "CREATE TABLE IF NOT EXISTS {$table_draft} (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        post_id BIGINT(20) UNSIGNED NOT NULL,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        content LONGTEXT NOT NULL,
        meta_data LONGTEXT,
        updated_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY post_user (post_id, user_id)
    ) {$charset};";
    
    dbDelta($sql_draft);
}
add_action('after_switch_theme', 'raz_lms_create_versions_table');
add_action('init', 'raz_lms_create_versions_table');

/**
 * Salvar versão do conteúdo
 */
function raz_lms_save_content_version($post_id, $type = 'manual') {
    global $wpdb;
    $table = $wpdb->prefix . 'raz_content_versions';
    
    $post = get_post($post_id);
    if (!$post) return false;
    
    // Coletar meta dados relevantes
    $meta_data = array();
    if ($post->post_type === 'aula') {
        $meta_data['video_url'] = get_post_meta($post_id, '_raz_aula_video_url', true);
        $meta_data['video_provider'] = get_post_meta($post_id, '_raz_aula_video_provider', true);
        $meta_data['duracao'] = get_post_meta($post_id, '_raz_aula_duracao', true);
        $meta_data['materiais'] = get_post_meta($post_id, '_raz_aula_materiais', true);
    }
    
    $wpdb->insert($table, array(
        'post_id' => $post_id,
        'post_type' => $post->post_type,
        'content' => $post->post_content,
        'meta_data' => json_encode($meta_data),
        'version_type' => $type,
        'created_at' => current_time('mysql'),
        'created_by' => get_current_user_id()
    ));
    
    // Manter apenas últimas 20 versões
    $versions = $wpdb->get_col($wpdb->prepare(
        "SELECT id FROM {$table} WHERE post_id = %d ORDER BY created_at DESC LIMIT 20, 1000",
        $post_id
    ));
    
    if (!empty($versions)) {
        $wpdb->query("DELETE FROM {$table} WHERE id IN (" . implode(',', $versions) . ")");
    }
    
    return $wpdb->insert_id;
}

/**
 * Obter versões do conteúdo
 */
function raz_lms_get_content_versions($post_id, $limit = 20) {
    global $wpdb;
    $table = $wpdb->prefix . 'raz_content_versions';
    
    return $wpdb->get_results($wpdb->prepare(
        "SELECT v.*, u.display_name as author_name 
         FROM {$table} v 
         LEFT JOIN {$wpdb->users} u ON v.created_by = u.ID
         WHERE v.post_id = %d 
         ORDER BY v.created_at DESC 
         LIMIT %d",
        $post_id, $limit
    ));
}

/**
 * Restaurar versão
 */
function raz_lms_restore_version($version_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'raz_content_versions';
    
    $version = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table} WHERE id = %d",
        $version_id
    ));
    
    if (!$version) return false;
    
    // Salvar versão atual antes de restaurar
    raz_lms_save_content_version($version->post_id, 'before_restore');
    
    // Restaurar conteúdo
    wp_update_post(array(
        'ID' => $version->post_id,
        'post_content' => $version->content
    ));
    
    // Restaurar meta dados
    if ($version->meta_data) {
        $meta = json_decode($version->meta_data, true);
        if (is_array($meta)) {
            foreach ($meta as $key => $value) {
                update_post_meta($version->post_id, '_raz_aula_' . $key, $value);
            }
        }
    }
    
    return true;
}

/**
 * Salvar rascunho automático
 */
function raz_lms_save_auto_draft($post_id, $content, $meta_data = array()) {
    global $wpdb;
    $table = $wpdb->prefix . 'raz_auto_drafts';
    
    $wpdb->replace($table, array(
        'post_id' => $post_id,
        'user_id' => get_current_user_id(),
        'content' => $content,
        'meta_data' => json_encode($meta_data),
        'updated_at' => current_time('mysql')
    ));
    
    return true;
}

/**
 * Obter rascunho automático
 */
function raz_lms_get_auto_draft($post_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'raz_auto_drafts';
    
    return $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table} WHERE post_id = %d AND user_id = %d",
        $post_id, get_current_user_id()
    ));
}

/**
 * Limpar rascunho automático
 */
function raz_lms_clear_auto_draft($post_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'raz_auto_drafts';
    
    $wpdb->delete($table, array(
        'post_id' => $post_id,
        'user_id' => get_current_user_id()
    ));
}

/**
 * AJAX: Salvar rascunho automático
 */
function raz_lms_ajax_save_auto_draft() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error();
    }
    
    $post_id = intval($_POST['post_id']);
    $content = wp_kses_post($_POST['content']);
    $meta_data = isset($_POST['meta_data']) ? $_POST['meta_data'] : array();
    
    raz_lms_save_auto_draft($post_id, $content, $meta_data);
    
    wp_send_json_success(array('time' => current_time('H:i:s')));
}
add_action('wp_ajax_raz_save_auto_draft', 'raz_lms_ajax_save_auto_draft');

/**
 * AJAX: Obter rascunho automático
 */
function raz_lms_ajax_get_auto_draft() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error();
    }
    
    $post_id = intval($_GET['post_id']);
    $draft = raz_lms_get_auto_draft($post_id);
    
    if ($draft) {
        wp_send_json_success(array(
            'content' => $draft->content,
            'meta_data' => json_decode($draft->meta_data, true),
            'updated_at' => date_i18n('d/m/Y H:i', strtotime($draft->updated_at))
        ));
    } else {
        wp_send_json_error();
    }
}
add_action('wp_ajax_raz_get_auto_draft', 'raz_lms_ajax_get_auto_draft');

/**
 * AJAX: Obter versões
 */
function raz_lms_ajax_get_versions() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error();
    }
    
    $post_id = intval($_GET['post_id']);
    $versions = raz_lms_get_content_versions($post_id);
    
    $data = array();
    foreach ($versions as $v) {
        $data[] = array(
            'id' => $v->id,
            'date' => date_i18n('d/m/Y H:i', strtotime($v->created_at)),
            'author' => $v->author_name ?: 'Sistema',
            'type' => $v->version_type,
            'content_preview' => wp_trim_words(strip_tags($v->content), 20)
        );
    }
    
    wp_send_json_success($data);
}
add_action('wp_ajax_raz_get_versions', 'raz_lms_ajax_get_versions');

/**
 * AJAX: Restaurar versão
 */
function raz_lms_ajax_restore_version() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error();
    }
    
    $version_id = intval($_POST['version_id']);
    
    if (raz_lms_restore_version($version_id)) {
        wp_send_json_success();
    } else {
        wp_send_json_error(array('message' => 'Erro ao restaurar versão'));
    }
}
add_action('wp_ajax_raz_restore_version', 'raz_lms_ajax_restore_version');

/**
 * AJAX: Visualizar versão
 */
function raz_lms_ajax_view_version() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error();
    }
    
    global $wpdb;
    $table = $wpdb->prefix . 'raz_content_versions';
    $version_id = intval($_GET['version_id']);
    
    $version = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table} WHERE id = %d",
        $version_id
    ));
    
    if ($version) {
        wp_send_json_success(array(
            'content' => $version->content,
            'meta_data' => json_decode($version->meta_data, true)
        ));
    } else {
        wp_send_json_error();
    }
}
add_action('wp_ajax_raz_view_version', 'raz_lms_ajax_view_version');
