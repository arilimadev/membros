<?php

/**
 * AJAX Handlers Adicionais - Gestão de Perfil e Conteúdo
 * @package RazMidiasLMS
 */

defined('ABSPATH') || exit;

/**
 * AJAX: Alterar Senha do Aluno via Modal
 * Resolve o erro 400 garantindo que a action esteja registrada
 */
function raz_lms_ajax_change_user_password()
{
    // Verifica o nonce de segurança enviado pelo header.php
    check_ajax_referer('raz_pass_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(array(
            'message' => 'Você precisa estar logado para realizar esta ação.'
        ));
    }

    $new_password = isset($_POST['password']) ? $_POST['password'] : '';
    $user_id = get_current_user_id();

    if (empty($new_password) || strlen($new_password) < 6) {
        wp_send_json_error(array(
            'message' => 'A senha deve ter no mínimo 6 caracteres.'
        ));
    }

    // Altera a senha do usuário de forma segura
    wp_set_password($new_password, $user_id);

    // Como o wp_set_password desloga o usuário (invalida cookies), logamos ele novamente
    $user = get_user_by('id', $user_id);
    if ($user) {
        wp_set_current_user($user_id, $user->user_login);
        wp_set_auth_cookie($user_id);
        do_action('wp_login', $user->user_login, $user);
    }

    wp_send_json_success(array(
        'message' => 'Senha alterada com sucesso!'
    ));
}
// Registra a action para usuários logados
add_action('wp_ajax_raz_change_user_password', 'raz_lms_ajax_change_user_password');

/**
 * AJAX: Salvar Módulo (Novo ou Edição)
 */
function raz_lms_ajax_save_modulo()
{
    check_ajax_referer('raz_admin_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(array(
            'message' => 'Sem permissão'
        ));
    }

    $curso_id = isset($_POST['curso_id']) ? intval($_POST['curso_id']) : 0;
    $modulo_id = isset($_POST['modulo_id']) ? intval($_POST['modulo_id']) : 0;
    $titulo = isset($_POST['titulo']) ? sanitize_text_field($_POST['titulo']) : '';
    $ordem = isset($_POST['ordem']) ? intval($_POST['ordem']) : 0;

    if (!$curso_id || empty($titulo)) {
        wp_send_json_error(array(
            'message' => 'Dados incompletos. Verifique o título e o curso.'
        ));
    }

    $args = array(
        'post_title'   => $titulo,
        'post_type'    => 'modulo',
        'post_status'  => 'publish',
    );

    if ($modulo_id > 0) {
        $args['ID'] = $modulo_id;
        $saved_id = wp_update_post($args);
    } else {
        $saved_id = wp_insert_post($args);
    }

    if ($saved_id && !is_wp_error($saved_id)) {
        // Vincula o módulo ao curso
        update_post_meta($saved_id, '_raz_modulo_curso', (string)$curso_id);
        update_post_meta($saved_id, '_raz_modulo_ordem', $ordem);

        wp_send_json_success(array(
            'message' => 'Módulo salvo com sucesso!',
            'modulo_id' => $saved_id,
            'titulo' => $titulo,
            'ordem' => $ordem
        ));
    }

    wp_send_json_error(array(
        'message' => 'Erro interno ao salvar o módulo.'
    ));
}
add_action('wp_ajax_raz_save_modulo', 'raz_lms_ajax_save_modulo');

/**
 * AJAX: Toggle lesson complete
 */
function raz_lms_ajax_toggle_lesson()
{
    check_ajax_referer('raz_lms_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(array(
            'message' => 'Não autorizado'
        ));
    }

    $aula_id = isset($_POST['aula_id']) ? intval($_POST['aula_id']) : 0;
    $completed = isset($_POST['completed']) ? $_POST['completed'] === '1' : true;
    $user_id = get_current_user_id();

    if (!$aula_id || get_post_type($aula_id) !== 'aula') {
        wp_send_json_error(array(
            'message' => 'Aula inválida'
        ));
    }

    $lessons = get_user_meta($user_id, '_raz_completed_lessons', true) ?: array();

    if ($completed && !in_array($aula_id, $lessons)) {
        $lessons[] = $aula_id;
    } elseif (!$completed && in_array($aula_id, $lessons)) {
        $lessons = array_diff($lessons, array($aula_id));
    }

    update_user_meta($user_id, '_raz_completed_lessons', array_values($lessons));

    $modulo_id = get_post_meta($aula_id, '_raz_aula_modulo', true);
    $module_progress = $modulo_id ? raz_lms_get_module_progress($user_id, $modulo_id) : null;

    wp_send_json_success(array(
        'completed' => $completed,
        'module_progress' => $module_progress
    ));
}
add_action('wp_ajax_raz_toggle_lesson', 'raz_lms_ajax_toggle_lesson');

/**
 * AJAX: Marcar/Desmarcar aula como concluída (TOGGLE)
 */
function raz_lms_ajax_toggle_lesson_complete()
{
    check_ajax_referer('raz_lms_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array(
            'message' => 'Não autenticado'
        ));
    }
    
    $aula_id = isset($_POST['aula_id']) ? intval($_POST['aula_id']) : 0;
    $complete = isset($_POST['complete']) ? intval($_POST['complete']) : 1;
    
    if (!$aula_id) {
        wp_send_json_error(array(
            'message' => 'Aula inválida'
        ));
    }
    
    $user_id = get_current_user_id();
    
    if ($complete) {
        raz_lms_complete_lesson($user_id, $aula_id);
    } else {
        raz_lms_uncomplete_lesson($user_id, $aula_id);
    }
    
    $adjacent = raz_lms_get_adjacent_aulas($aula_id);
    
    wp_send_json_success(array(
        'message' => $complete ? 'Aula concluída!' : 'Aula desmarcada!',
        'completed' => $complete ? true : false,
        'next_url' => $adjacent['next'] ? get_permalink($adjacent['next']->ID) : '',
    ));
}
add_action('wp_ajax_raz_toggle_lesson_complete', 'raz_lms_ajax_toggle_lesson_complete');

// Mantém compatibilidade com a antiga
add_action('wp_ajax_raz_complete_lesson', 'raz_lms_ajax_toggle_lesson_complete');

/**
 * AJAX: Buscar módulos por curso (Duplicação)
 */
function raz_lms_ajax_get_modules_by_course()
{
    check_ajax_referer('raz_admin_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(array(
            'message' => 'Sem permissão'
        ));
    }

    $curso_id = isset($_GET['curso_id']) ? intval($_GET['curso_id']) : 0;
    if (!$curso_id) {
        wp_send_json_error(array(
            'message' => 'Curso inválido'
        ));
    }

    $modulos = raz_lms_get_modulos($curso_id);
    $data = array();

    foreach ($modulos as $modulo) {
        $data[] = array(
            'id' => $modulo->ID,
            'title' => $modulo->post_title
        );
    }

    wp_send_json_success($data);
}
add_action('wp_ajax_raz_get_modules_by_course', 'raz_lms_ajax_get_modules_by_course');

/**
 * AJAX: Deletar Item (Módulo ou Aula)
 */
function raz_lms_ajax_delete_item()
{
    check_ajax_referer('raz_admin_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(array(
            'message' => 'Sem permissão'
        ));
    }

    $item_id = isset($_POST['item_id']) ? intval($_POST['item_id']) : 0;
    $type = isset($_POST['type']) ? sanitize_text_field($_POST['type']) : '';

    if (!$item_id || !in_array($type, array('modulo', 'aula'))) {
        wp_send_json_error(array(
            'message' => 'Item inválido'
        ));
    }

    // Se for módulo, opcionalmente tratar as aulas órfãs ou deletá-las
    $result = wp_delete_post($item_id, true);

    if ($result) {
        wp_send_json_success(array(
            'message' => 'Item excluído com sucesso'
        ));
    }

    wp_send_json_error(array(
        'message' => 'Erro ao excluir item'
    ));
}
add_action('wp_ajax_raz_delete_item', 'raz_lms_ajax_delete_item');