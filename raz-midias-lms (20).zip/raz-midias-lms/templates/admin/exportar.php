<?php
/**
 * Admin: Exportar Dados - Com Filtros
 */
$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title'));

$filter_curso = isset($_GET['curso']) ? intval($_GET['curso']) : 0;
$filter_periodo_de = isset($_GET['periodo_de']) ? sanitize_text_field($_GET['periodo_de']) : '';
$filter_periodo_ate = isset($_GET['periodo_ate']) ? sanitize_text_field($_GET['periodo_ate']) : '';
$filter_modulo = isset($_GET['modulo']) ? intval($_GET['modulo']) : 0;

// Buscar módulos se curso selecionado
$modulos = array();
if ($filter_curso) {
    $modulos = raz_lms_get_modulos($filter_curso);
}
?>

<style>
.export-filters { background: #fff; padding: 20px; border-radius: 12px; border: 1px solid var(--border); margin-bottom: 24px; }
.export-filters h3 { margin-bottom: 16px; font-size: 16px; }
.filter-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; }
.filter-grid .form-group { margin-bottom: 0; }
.filter-actions { display: flex; gap: 12px; margin-top: 16px; padding-top: 16px; border-top: 1px solid var(--border); }
</style>

<div class="admin-header">
    <h2>Exportar Dados</h2>
</div>

<div class="export-filters">
    <h3>🔍 Filtros</h3>
    <form method="get" action="" id="filter-form">
        <div class="filter-grid">
            <div class="form-group">
                <label>Curso</label>
                <select name="curso" id="filter-curso" onchange="loadModulos()">
                    <option value="">Todos os cursos</option>
                    <?php foreach ($cursos as $c) : ?>
                    <option value="<?php echo $c->ID; ?>" <?php selected($filter_curso, $c->ID); ?>><?php echo esc_html($c->post_title); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Módulo</label>
                <select name="modulo" id="filter-modulo">
                    <option value="">Todos os módulos</option>
                    <?php foreach ($modulos as $m) : ?>
                    <option value="<?php echo $m->ID; ?>" <?php selected($filter_modulo, $m->ID); ?>><?php echo esc_html($m->post_title); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Período de</label>
                <input type="date" name="periodo_de" value="<?php echo esc_attr($filter_periodo_de); ?>">
            </div>
            
            <div class="form-group">
                <label>Período até</label>
                <input type="date" name="periodo_ate" value="<?php echo esc_attr($filter_periodo_ate); ?>">
            </div>
        </div>
        
        <div class="filter-actions">
            <button type="submit" class="btn btn-secondary">Aplicar Filtros</button>
            <a href="<?php echo home_url('/gestao-cursos/exportar/'); ?>" class="btn" style="color:var(--muted);">Limpar Filtros</a>
        </div>
    </form>
</div>

<div class="form-card">
    <h3 style="margin-bottom:16px;">📊 Exportar Relatórios</h3>
    <p style="color:var(--muted);margin-bottom:20px;">Selecione o tipo de relatório para exportar em CSV. Abra no Google Sheets.</p>
    
    <div style="display:grid;gap:16px;">
        <div style="display:flex;align-items:center;justify-content:space-between;padding:16px;background:var(--bg);border-radius:8px;">
            <div>
                <h4 style="margin-bottom:4px;">👥 Lista de Alunos</h4>
                <p style="font-size:13px;color:var(--muted);margin:0;">Nome, Email, Telefone, Cursos, Status, Origem</p>
            </div>
            <button class="btn btn-primary btn-sm" onclick="exportAlunos()">Exportar CSV</button>
        </div>
        
        <div style="display:flex;align-items:center;justify-content:space-between;padding:16px;background:var(--bg);border-radius:8px;">
            <div>
                <h4 style="margin-bottom:4px;">📈 Progresso dos Alunos</h4>
                <p style="font-size:13px;color:var(--muted);margin:0;">Nome, Email, Telefone, Curso, Progresso, Último Acesso</p>
            </div>
            <button class="btn btn-primary btn-sm" onclick="exportProgresso()">Exportar CSV</button>
        </div>
        
        <div style="display:flex;align-items:center;justify-content:space-between;padding:16px;background:var(--bg);border-radius:8px;">
            <div>
                <h4 style="margin-bottom:4px;">📺 Conclusões por Aula</h4>
                <p style="font-size:13px;color:var(--muted);margin:0;">Aula, Módulo, Total Conclusões, Taxa</p>
            </div>
            <button class="btn btn-primary btn-sm" onclick="exportConclusoes()">Exportar CSV</button>
        </div>
        
        <div style="display:flex;align-items:center;justify-content:space-between;padding:16px;background:var(--bg);border-radius:8px;">
            <div>
                <h4 style="margin-bottom:4px;">📊 Relatório Completo</h4>
                <p style="font-size:13px;color:var(--muted);margin:0;">Todos os dados em um arquivo</p>
            </div>
            <button class="btn btn-primary btn-sm" onclick="exportCompleto()">Exportar CSV</button>
        </div>
    </div>
</div>

<script>
var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
var nonce = '<?php echo wp_create_nonce('raz_admin_nonce'); ?>';

function getFilters() {
    return {
        curso: document.getElementById('filter-curso').value,
        modulo: document.getElementById('filter-modulo').value,
        periodo_de: document.querySelector('[name="periodo_de"]').value,
        periodo_ate: document.querySelector('[name="periodo_ate"]').value
    };
}

function loadModulos() {
    var cursoId = document.getElementById('filter-curso').value;
    var select = document.getElementById('filter-modulo');
    select.innerHTML = '<option value="">Todos os módulos</option>';
    
    if (!cursoId) return;
    
    fetch(ajaxurl + '?action=raz_get_modulos&nonce=' + nonce + '&curso_id=' + cursoId)
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success && d.data) {
                d.data.forEach(function(m) {
                    var opt = document.createElement('option');
                    opt.value = m.id;
                    opt.textContent = m.title;
                    select.appendChild(opt);
                });
            }
        });
}

function exportAlunos() {
    var f = getFilters();
    window.location.href = ajaxurl + '?action=raz_export_alunos&nonce=' + nonce + 
        '&curso=' + f.curso + '&periodo_de=' + f.periodo_de + '&periodo_ate=' + f.periodo_ate;
}

function exportProgresso() {
    var f = getFilters();
    window.location.href = ajaxurl + '?action=raz_export_progresso&nonce=' + nonce + 
        '&curso=' + f.curso + '&modulo=' + f.modulo + '&periodo_de=' + f.periodo_de + '&periodo_ate=' + f.periodo_ate;
}

function exportConclusoes() {
    var f = getFilters();
    window.location.href = ajaxurl + '?action=raz_export_conclusoes&nonce=' + nonce + 
        '&curso=' + f.curso + '&modulo=' + f.modulo;
}

function exportCompleto() {
    var f = getFilters();
    window.location.href = ajaxurl + '?action=raz_export_completo&nonce=' + nonce + 
        '&curso=' + f.curso + '&periodo_de=' + f.periodo_de + '&periodo_ate=' + f.periodo_ate;
}
</script>
