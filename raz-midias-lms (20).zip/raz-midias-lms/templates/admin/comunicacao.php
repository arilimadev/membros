<?php
/**
 * Admin: Comunicação - Notificações e E-mails
 */
$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title'));

// Configurações de lembrete
$config_lembrete = get_option('raz_lms_email_lembrete', array(
    'ativo' => false,
    'dias' => 7,
    'assunto' => 'Sentimos sua falta, {nome}!',
    'mensagem' => "Olá {nome},\n\nPercebemos que você não acessa o curso \"{curso}\" há {dias} dias.\n\nVolte agora e continue sua jornada de aprendizado!\n\n{link}\n\nAbraços,\n{site_nome}"
));

if (isset($_POST['save_lembrete']) && wp_verify_nonce($_POST['lembrete_nonce'], 'raz_save_lembrete')) {
    $config_lembrete = array(
        'ativo' => isset($_POST['lembrete_ativo']),
        'dias' => intval($_POST['lembrete_dias']),
        'assunto' => sanitize_text_field($_POST['lembrete_assunto']),
        'mensagem' => wp_kses_post($_POST['lembrete_mensagem'])
    );
    update_option('raz_lms_email_lembrete', $config_lembrete);
    echo '<div class="alert alert-success" style="margin-bottom:20px;">Configurações salvas!</div>';
}
?>

<style>
.tab-buttons { display: flex; gap: 0; margin-bottom: 24px; border-bottom: 2px solid var(--border); }
.tab-btn { padding: 12px 24px; border: none; background: none; cursor: pointer; font-size: 14px; font-weight: 500; color: var(--muted); border-bottom: 2px solid transparent; margin-bottom: -2px; transition: all 0.15s; }
.tab-btn:hover { color: var(--text); }
.tab-btn.active { color: var(--primary); border-bottom-color: var(--primary); }
.tab-content { display: none; }
.tab-content.active { display: block; }

.notif-list { display: flex; flex-direction: column; gap: 12px; }
.notif-item { display: flex; justify-content: space-between; align-items: flex-start; padding: 16px; background: var(--bg); border-radius: 8px; }
.notif-item-info h4 { margin: 0 0 4px; font-size: 14px; }
.notif-item-info p { margin: 0; font-size: 13px; color: var(--muted); }
.notif-item-meta { font-size: 11px; color: var(--muted); margin-top: 8px; }
.notif-item-actions { display: flex; gap: 8px; }

.recipient-count { display: inline-flex; align-items: center; gap: 6px; padding: 8px 12px; background: var(--bg); border-radius: 6px; font-size: 13px; margin-top: 12px; }
.recipient-count strong { color: var(--primary); }
</style>

<div class="admin-header">
    <h2>Comunicação</h2>
</div>

<div class="tab-buttons">
    <button class="tab-btn active" onclick="showTab('notificacoes')">🔔 Notificações</button>
    <button class="tab-btn" onclick="showTab('email-manual')">✉️ Enviar E-mail</button>
    <button class="tab-btn" onclick="showTab('lembretes')">⏰ Lembretes Automáticos</button>
</div>

<!-- Tab: Notificações -->
<div class="tab-content active" id="tab-notificacoes">
    <div class="form-card">
        <h3 style="margin-bottom:20px;">Criar Nova Notificação</h3>
        <p style="color:var(--muted);margin-bottom:20px;">As notificações aparecem no sininho dentro da área de membros.</p>
        
        <div class="form-group">
            <label>Título *</label>
            <input type="text" id="notif_title" placeholder="Ex: Novo módulo disponível!">
        </div>
        
        <div class="form-group">
            <label>Mensagem *</label>
            <textarea id="notif_message" rows="4" placeholder="Escreva a mensagem da notificação..."></textarea>
        </div>
        
        <div class="form-group">
            <label>Destinatários</label>
            <select id="notif_curso">
                <option value="0">Todos os alunos</option>
                <?php foreach ($cursos as $c) : ?>
                <option value="<?php echo $c->ID; ?>">Apenas: <?php echo esc_html($c->post_title); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <button class="btn btn-primary" onclick="createNotification()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/></svg>
            Enviar Notificação
        </button>
    </div>
    
    <div class="form-card">
        <h3 style="margin-bottom:16px;">Notificações Enviadas</h3>
        <div id="notif-list" class="notif-list">
            <p style="text-align:center;color:var(--muted);padding:20px;">Carregando...</p>
        </div>
    </div>
</div>

<!-- Tab: E-mail Manual -->
<div class="tab-content" id="tab-email-manual">
    <div class="form-card">
        <h3 style="margin-bottom:20px;">Enviar E-mail</h3>
        <p style="color:var(--muted);margin-bottom:20px;">Envie um e-mail para seus alunos.</p>
        
        <div class="form-group">
            <label>Assunto *</label>
            <input type="text" id="email_assunto" placeholder="Assunto do e-mail">
        </div>
        
        <div class="form-group">
            <label>Mensagem *</label>
            <textarea id="email_mensagem" rows="8" placeholder="Escreva a mensagem do e-mail..."></textarea>
            <small style="color:var(--muted);">Variáveis disponíveis: {nome}, {email}, {site_nome}</small>
        </div>
        
        <div class="form-group">
            <label>Destinatários</label>
            <select id="email_destinatarios" onchange="updateRecipientCount()">
                <option value="todos">Todos os alunos</option>
                <option value="curso">Alunos de um curso específico</option>
                <option value="manual">Inserir e-mails manualmente</option>
            </select>
        </div>
        
        <div class="form-group" id="email_curso_group" style="display:none;">
            <label>Selecione o Curso</label>
            <select id="email_curso" onchange="updateRecipientCount()">
                <?php foreach ($cursos as $c) : ?>
                <option value="<?php echo $c->ID; ?>"><?php echo esc_html($c->post_title); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="form-group" id="email_manual_group" style="display:none;">
            <label>E-mails (um por linha)</label>
            <textarea id="email_manuais" rows="5" placeholder="email1@exemplo.com&#10;email2@exemplo.com"></textarea>
        </div>
        
        <div class="recipient-count" id="recipient-count">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            <span>Destinatários: <strong id="recipient-num">-</strong></span>
        </div>
        
        <div style="margin-top:20px;">
            <button class="btn btn-primary" onclick="sendManualEmail()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/></svg>
                Enviar E-mail
            </button>
        </div>
    </div>
</div>

<!-- Tab: Lembretes Automáticos -->
<div class="tab-content" id="tab-lembretes">
    <form method="post" class="form-card">
        <?php wp_nonce_field('raz_save_lembrete', 'lembrete_nonce'); ?>
        
        <h3 style="margin-bottom:20px;">⏰ Lembrete de Inatividade</h3>
        <p style="color:var(--muted);margin-bottom:20px;">Envie e-mails automáticos para alunos que não acessam a plataforma há alguns dias.</p>
        
        <div class="form-group">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                <input type="checkbox" name="lembrete_ativo" <?php checked($config_lembrete['ativo']); ?>>
                <span>Ativar e-mail de lembrete</span>
            </label>
        </div>
        
        <div class="form-group">
            <label>Enviar após quantos dias sem acessar?</label>
            <input type="number" name="lembrete_dias" value="<?php echo esc_attr($config_lembrete['dias']); ?>" min="1" max="90" style="width:100px;">
        </div>
        
        <div class="form-group">
            <label>Assunto do E-mail</label>
            <input type="text" name="lembrete_assunto" value="<?php echo esc_attr($config_lembrete['assunto']); ?>">
        </div>
        
        <div class="form-group">
            <label>Mensagem</label>
            <textarea name="lembrete_mensagem" rows="8"><?php echo esc_textarea($config_lembrete['mensagem']); ?></textarea>
            <small style="color:var(--muted);">Variáveis: {nome}, {email}, {curso}, {dias}, {link}, {site_nome}</small>
        </div>
        
        <button type="submit" name="save_lembrete" class="btn btn-primary">Salvar Configurações</button>
    </form>
</div>

<script>
var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
var nonce = '<?php echo wp_create_nonce('raz_admin_nonce'); ?>';

function showTab(tab) {
    document.querySelectorAll('.tab-btn').forEach(function(b) { b.classList.remove('active'); });
    document.querySelectorAll('.tab-content').forEach(function(c) { c.classList.remove('active'); });
    document.querySelector('[onclick="showTab(\'' + tab + '\')"]').classList.add('active');
    document.getElementById('tab-' + tab).classList.add('active');
}

function loadNotifications() {
    fetch(ajaxurl + '?action=raz_list_notifications&nonce=' + nonce)
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success && d.data.length > 0) {
                var html = '';
                d.data.forEach(function(n) {
                    html += '<div class="notif-item">';
                    html += '<div class="notif-item-info">';
                    html += '<h4>' + n.title + '</h4>';
                    html += '<p>' + n.message.substring(0, 100) + (n.message.length > 100 ? '...' : '') + '</p>';
                    html += '<div class="notif-item-meta">📅 ' + n.date + ' • 📚 ' + n.curso + '</div>';
                    html += '</div>';
                    html += '<div class="notif-item-actions">';
                    html += '<button class="btn btn-sm" style="color:var(--danger);" onclick="deleteNotification(' + n.id + ')">Excluir</button>';
                    html += '</div></div>';
                });
                document.getElementById('notif-list').innerHTML = html;
            } else {
                document.getElementById('notif-list').innerHTML = '<p style="text-align:center;color:var(--muted);padding:20px;">Nenhuma notificação enviada</p>';
            }
        });
}

function createNotification() {
    var title = document.getElementById('notif_title').value;
    var message = document.getElementById('notif_message').value;
    var curso_id = document.getElementById('notif_curso').value;
    
    if (!title || !message) {
        alert('Preencha título e mensagem');
        return;
    }
    
    fetch(ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=raz_create_notification&nonce=' + nonce + '&title=' + encodeURIComponent(title) + '&message=' + encodeURIComponent(message) + '&curso_id=' + curso_id
    })
    .then(function(r) { return r.json(); })
    .then(function(d) {
        if (d.success) {
            alert('Notificação enviada com sucesso!');
            document.getElementById('notif_title').value = '';
            document.getElementById('notif_message').value = '';
            loadNotifications();
        } else {
            alert('Erro: ' + (d.data ? d.data.message : 'Desconhecido'));
        }
    });
}

function deleteNotification(id) {
    if (!confirm('Excluir esta notificação?')) return;
    
    fetch(ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=raz_delete_notification&nonce=' + nonce + '&notification_id=' + id
    })
    .then(function(r) { return r.json(); })
    .then(function(d) {
        if (d.success) {
            loadNotifications();
        }
    });
}

document.getElementById('email_destinatarios').addEventListener('change', function() {
    document.getElementById('email_curso_group').style.display = this.value === 'curso' ? 'block' : 'none';
    document.getElementById('email_manual_group').style.display = this.value === 'manual' ? 'block' : 'none';
});

function updateRecipientCount() {
    var tipo = document.getElementById('email_destinatarios').value;
    var curso_id = document.getElementById('email_curso').value;
    
    if (tipo === 'manual') {
        document.getElementById('recipient-num').textContent = 'Conforme lista';
        return;
    }
    
    var url = ajaxurl + '?action=raz_count_recipients&nonce=' + nonce + '&tipo=' + tipo;
    if (tipo === 'curso') url += '&curso_id=' + curso_id;
    
    fetch(url)
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) {
                document.getElementById('recipient-num').textContent = d.data.count + ' aluno(s)';
            }
        });
}

function sendManualEmail() {
    var assunto = document.getElementById('email_assunto').value;
    var mensagem = document.getElementById('email_mensagem').value;
    var destinatarios = document.getElementById('email_destinatarios').value;
    var curso_id = document.getElementById('email_curso').value;
    var emails_manuais = document.getElementById('email_manuais').value;
    
    if (!assunto || !mensagem) {
        alert('Preencha assunto e mensagem');
        return;
    }
    
    if (!confirm('Confirma o envio dos e-mails?')) return;
    
    var btn = event.target;
    btn.disabled = true;
    btn.textContent = 'Enviando...';
    
    var body = 'action=raz_send_manual_email&nonce=' + nonce;
    body += '&assunto=' + encodeURIComponent(assunto);
    body += '&mensagem=' + encodeURIComponent(mensagem);
    body += '&destinatarios=' + destinatarios;
    body += '&curso_id=' + curso_id;
    body += '&emails_manuais=' + encodeURIComponent(emails_manuais);
    
    fetch(ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body
    })
    .then(function(r) { return r.json(); })
    .then(function(d) {
        btn.disabled = false;
        btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/></svg> Enviar E-mail';
        
        if (d.success) {
            alert('E-mails enviados!\n\nEnviados: ' + d.data.enviados + '\nErros: ' + d.data.erros);
        } else {
            alert('Erro: ' + (d.data ? d.data.message : 'Desconhecido'));
        }
    });
}

// Carregar dados iniciais
loadNotifications();
updateRecipientCount();
</script>
