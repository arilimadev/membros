<?php
/**
 * Admin: Editar Curso
 *
 * Estrutura:
 * - Edição de Curso com WP Editor (TinyMCE).
 * - Listagem de Módulos e Aulas.
 * - Links diretos para criação/edição de aulas (SEM MODAL).
 * - Sistema de Travamento e Duplicação.
 *
 * @package RazMidiasLMS
 * @version 5.2.0
 */

defined('ABSPATH') || exit;

// 1. Inicialização de Dados
$curso_id = isset($raz_item_id) ? intval($raz_item_id) : 0;
$curso = $curso_id ? get_post($curso_id) : null;

// Garante que a biblioteca de mídia esteja carregada
if (function_exists('wp_enqueue_media')) {
    wp_enqueue_media();
}

// Validação de segurança básica
if ($curso_id && (!$curso || $curso->post_type !== 'curso')) {
    echo '<div class="raz-admin-container"><div class="notice notice-error"><p>Curso não encontrado.</p></div></div>';
    return;
}

// Metas do Curso
$modulos = $curso_id ? raz_lms_get_modulos($curso_id) : array();
$kiwify_id = $curso_id ? get_post_meta($curso_id, '_raz_curso_kiwify_id', true) : '';
$dias_acesso = $curso_id ? (get_post_meta($curso_id, '_raz_curso_dias_acesso', true) ?: 365) : 365;
$vitalicio = $curso_id ? get_post_meta($curso_id, '_raz_curso_vitalicio', true) : '';
$tipo_acesso = $curso_id ? (get_post_meta($curso_id, '_raz_curso_tipo', true) ?: 'avulso') : 'avulso';

// Se vitalicio estava setado no modelo antigo, força tipo visual
if ($vitalicio) {
    $tipo_acesso = 'vitalicio';
}

$thumb_id = $curso_id ? get_post_thumbnail_id($curso_id) : 0;
$thumb_url = $thumb_id ? wp_get_attachment_image_url($thumb_id, 'medium') : '';
$cor_header = $curso_id ? get_post_meta($curso_id, '_raz_curso_cor_header', true) : '#667eea';
$cor_controls = $curso_id ? get_post_meta($curso_id, '_raz_curso_cor_controls', true) : '#1e293b';

if (!$cor_header) {
    $cor_header = '#667eea';
}
if (!$cor_controls) {
    $cor_controls = '#1e293b';
}

// Tab ativa (vinda da URL)
$active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'info';

// Buscar todos os cursos para o modal de duplicação
$all_courses = get_posts(array(
    'post_type'      => 'curso',
    'posts_per_page' => -1,
    'orderby'        => 'title',
    'order'          => 'ASC',
    'post_status'    => 'publish'
));
?>

<style>
    .admin-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
    .tabs { display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 1px solid #ddd; }
    .tab { padding: 10px 20px; cursor: pointer; font-weight: 600; color: #64748b; border-bottom: 2px solid transparent; }
    .tab:hover { color: #1e293b; }
    .tab.active { color: #0284c7; border-bottom-color: #0284c7; }
    .tab-content { display: none; }
    
    .form-card { background: #fff; padding: 24px; border-radius: 8px; border: 1px solid #e2e8f0; }
    .form-group { margin-bottom: 16px; }
    .form-group label { display: block; margin-bottom: 6px; font-weight: 500; font-size: 13px; color: #334155; }
    .form-group input[type="text"], .form-group select, .form-group input[type="number"] { 
        width: 100%; padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 14px; 
    }
    .form-hint { font-size: 12px; color: #94a3b8; margin-top: 4px; }
    
    .btn { padding: 8px 16px; border-radius: 6px; cursor: pointer; border: none; font-size: 14px; font-weight: 500; text-decoration: none; display: inline-flex; align-items: center; gap: 5px; }
    .btn-primary { background: #0284c7; color: #fff; }
    .btn-secondary { background: #fff; border: 1px solid #e2e8f0; color: #475569; }
    .btn-danger { background: #fee2e2; color: #ef4444; border: 1px solid #fecaca; padding: 6px 10px; }
    .btn-warning { background: #fff7ed; border: 1px solid #ffedd5; color: #c2410c; }
    
    /* Layout de Módulos e Aulas */
    .modulo-item { background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 12px; overflow: hidden; transition: opacity 0.2s; }
    .item-header { padding: 12px 16px; background: #f8fafc; display: flex; justify-content: space-between; align-items: center; cursor: pointer; border-bottom: 1px solid #e2e8f0; }
    .item-header:hover { background: #f1f5f9; }
    
    .item-drag { cursor: grab; color: #94a3b8; margin-right: 10px; }
    .badge { padding: 2px 8px; border-radius: 12px; font-size: 11px; background: #e0f2fe; color: #0284c7; margin-left: 10px; }
    
    .aulas-list { padding: 0; }
    .item-row { padding: 10px 16px 10px 40px; border-bottom: 1px solid #f1f5f9; display: flex; align-items: center; justify-content: space-between; background: #fff; }
    .item-row:last-child { border-bottom: none; }
    .item-row:hover { background: #f8fafc; }
    .item-title { font-size: 14px; color: #334155; font-weight: 500; }
    
    /* ESTADO DE ORDENAÇÃO BLOQUEADA */
    .sorting-disabled .item-drag { opacity: 0.3; cursor: not-allowed; }
    .locked-item { opacity: 0.7; background: #f9f9f9; }
    
    /* Modais */
    .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: none; align-items: center; justify-content: center; z-index: 1000; }
    .modal-overlay.open { display: flex; }
    .modal { background: #fff; width: 450px; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); padding: 20px; }
    .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .modal-header h3 { margin: 0; font-size: 18px; }
    .modal-close { cursor: pointer; font-size: 24px; color: #94a3b8; }
</style>

<div class="admin-header">
    <h2><?php echo $curso_id ? 'Editar Curso' : 'Novo Curso'; ?></h2>
    <a href="<?php echo home_url('/gestao-cursos/cursos'); ?>" class="btn btn-secondary">← Voltar</a>
</div>

<div class="tabs">
    <div class="tab <?php echo $active_tab === 'info' ? 'active' : ''; ?>" onclick="showTab('info',this)">Informações</div>
    <?php if ($curso_id) : ?>
    <div class="tab <?php echo $active_tab === 'conteudo' ? 'active' : ''; ?>" onclick="showTab('conteudo',this)">Conteúdo (Aulas)</div>
    <div class="tab <?php echo $active_tab === 'config' ? 'active' : ''; ?>" onclick="showTab('config',this)">Configurações</div>
    <?php endif; ?>
</div>

<div id="tab-info" class="tab-content" style="<?php echo $active_tab !== 'info' ? 'display:none;' : ''; ?>">
    <div class="form-card" style="max-width:800px;">
        <form id="form-curso" enctype="multipart/form-data">
            <input type="hidden" name="curso_id" value="<?php echo $curso_id; ?>">
            <input type="hidden" name="action" value="raz_save_curso">
            <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('raz_admin_nonce'); ?>">
            
            <div class="form-group">
                <label>Imagem do Curso</label>
                <div style="display:flex;gap:16px;align-items:flex-start;">
                    <div id="thumb-preview" style="width:200px;height:125px;background:linear-gradient(135deg,<?php echo esc_attr($cor_header); ?>,#764ba2);border-radius:12px;overflow:hidden;flex-shrink:0;">
                        <?php if ($thumb_url) : ?>
                        <img src="<?php echo esc_url($thumb_url); ?>" style="width:100%;height:100%;object-fit:cover;">
                        <?php endif; ?>
                    </div>
                    <div>
                        <input type="file" name="thumbnail" id="thumbnail-input" accept="image/*" style="display:none;">
                        <input type="hidden" name="thumbnail_id" id="thumbnail_id" value="<?php echo $thumb_id; ?>">
                        <button type="button" class="btn btn-secondary" onclick="document.getElementById('thumbnail-input').click()">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                            Escolher Imagem
                        </button>
                        <p class="form-hint" style="margin-top:8px;">Recomendado: 800x500px</p>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label>Cor do Header do Curso</label>
                <div style="display:flex;gap:12px;align-items:center;">
                    <input type="color" name="cor_header" id="cor_header" value="<?php echo esc_attr($cor_header); ?>" style="width:60px;height:40px;padding:0;border:none;">
                    <input type="text" id="cor_header_hex" value="<?php echo esc_attr($cor_header); ?>" style="width:100px;" onchange="document.getElementById('cor_header').value=this.value">
                    <span class="form-hint">Cor de fundo do cabeçalho na página do curso</span>
                </div>
            </div>
            
            <div class="form-group">
                <label>Cor dos Controles do Player</label>
                <div style="display:flex;gap:12px;align-items:center;">
                    <input type="color" name="cor_controls" id="cor_controls" value="<?php echo esc_attr($cor_controls); ?>" style="width:60px;height:40px;padding:0;border:none;">
                    <input type="text" id="cor_controls_hex" value="<?php echo esc_attr($cor_controls); ?>" style="width:100px;" onchange="document.getElementById('cor_controls').value=this.value">
                    <span class="form-hint">Cor da barra de controles no player de aula</span>
                </div>
            </div>
            
            <div class="form-group">
                <label>Título do Curso *</label>
                <input type="text" name="titulo" value="<?php echo $curso ? esc_attr($curso->post_title) : ''; ?>" required>
            </div>
            
            <div class="form-group">
                <label>Descrição do Curso (Conteúdo)</label>
                <?php 
                $content = $curso ? $curso->post_excerpt : '';
                // Configurações do Editor
                $settings = array(
                    'media_buttons' => true,
                    'textarea_name' => 'descricao',
                    'textarea_rows' => 10,
                    'teeny'         => false,
                    'quicktags'     => true
                );
                wp_editor($content, 'descricao', $settings);
                ?>
            </div>
            
            <button type="submit" class="btn btn-primary">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                Salvar Curso
            </button>
        </form>
    </div>
</div>

<?php if ($curso_id) : ?>
<div id="tab-conteudo" class="tab-content" style="<?php echo $active_tab !== 'conteudo' ? 'display:none;' : ''; ?>">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
        <h3>Módulos e Aulas</h3>
        
        <div style="display:flex;gap:10px;">
            <button type="button" class="btn btn-secondary" id="toggle-sorting-btn" onclick="toggleGlobalSorting()">
                <span id="lock-icon">🔒</span> <span id="lock-text">Destravar Ordenação</span>
            </button>

            <button class="btn btn-primary" onclick="openModuloModal()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                Novo Módulo
            </button>
        </div>
    </div>
    
    <p style="color:var(--muted);margin-bottom:16px;font-size:14px;">💡 Arraste os módulos e aulas para reorganizar a ordem (Necessário destravar).</p>
    
    <div class="item-list sorting-disabled" id="modulos-list">
        <?php if (empty($modulos)) : ?>
        <div class="empty-state" id="empty-modulos" style="padding:40px;">
            <h3>Nenhum módulo</h3>
            <p>Clique em "Novo Módulo" para começar</p>
        </div>
        <?php else : 
            foreach ($modulos as $index => $modulo) : 
                $aulas = raz_lms_get_aulas($modulo->ID); 
        ?>
        <div class="modulo-item sortable-item" data-id="<?php echo $modulo->ID; ?>">
            <div class="item-header" onclick="toggleModulo(this)">
                <div style="display:flex;align-items:center;gap:12px;">
                    <span class="item-drag" onclick="event.stopPropagation();">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
                    </span>
                    <strong><?php echo esc_html($modulo->post_title); ?></strong>
                    <span class="badge badge-primary aulas-count" data-modulo="<?php echo $modulo->ID; ?>"><?php echo count($aulas); ?> aulas</span>
                </div>
                <div style="display:flex;gap:8px;">
                    <button class="btn btn-sm btn-secondary" onclick="event.stopPropagation();editModulo(<?php echo $modulo->ID; ?>,'<?php echo esc_js($modulo->post_title); ?>')">Editar</button>
                    
                    <button class="btn btn-sm btn-secondary" onclick="event.stopPropagation();razOpenDuplicateModule(<?php echo $modulo->ID; ?>)" title="Duplicar Módulo">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                    </button>
                    
                    <a href="<?php echo home_url('/gestao-cursos/aula-editar/?modulo=' . $modulo->ID . '&curso=' . $curso_id); ?>" class="btn btn-sm btn-primary" onclick="event.stopPropagation();">+ Aula</a>
                    
                    <button class="btn btn-sm btn-danger" onclick="event.stopPropagation();deleteItem(<?php echo $modulo->ID; ?>,'modulo',this)">×</button>
                </div>
            </div>
            <div class="item-content aulas-list" id="aulas-<?php echo $modulo->ID; ?>" style="display:none;">
                <?php if (empty($aulas)) : ?>
                <div class="aulas-empty" style="padding:20px;text-align:center;color:var(--muted);">Sem aulas neste módulo</div>
                <?php else : foreach ($aulas as $aula) : ?>
                <div class="item-row sortable-item" data-id="<?php echo $aula->ID; ?>">
                    <span class="item-drag">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
                    </span>
                    <span class="item-title"><?php echo esc_html($aula->post_title); ?></span>
                    <div class="item-actions">
                        <a href="<?php echo home_url('/gestao-cursos/aula-editar/' . $aula->ID . '?curso=' . $curso_id); ?>" class="btn btn-sm btn-secondary">Editar</a>
                        
                        <button class="btn btn-sm btn-secondary" onclick="razOpenDuplicateLesson(<?php echo $aula->ID; ?>)" title="Duplicar">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                        </button>

                        <button class="btn btn-sm btn-danger" onclick="deleteItem(<?php echo $aula->ID; ?>,'aula',this)">×</button>
                    </div>
                </div>
                <?php endforeach; endif; ?>
            </div>
        </div>
        <?php endforeach; endif; ?>
    </div>
</div>

<div id="tab-config" class="tab-content" style="<?php echo $active_tab !== 'config' ? 'display:none;' : ''; ?>">
    <div class="form-card" style="max-width:700px;">
        <form id="form-config">
            <input type="hidden" name="curso_id" value="<?php echo $curso_id; ?>">
            <h3 style="margin-bottom:20px;">Integração e Acesso</h3>
            
            <div class="form-group">
                <label>ID do Produto Kiwify</label>
                <input type="text" name="kiwify_id" value="<?php echo esc_attr($kiwify_id); ?>" placeholder="Ex: abc123xyz">
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Tipo de Acesso</label>
                    <select name="tipo" id="conf_tipo" onchange="toggleAccessDays()" style="width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:6px;">
                        <option value="avulso" <?php selected($tipo_acesso, 'avulso'); ?>>Avulso (Dias definidos)</option>
                        <option value="assinatura" <?php selected($tipo_acesso, 'assinatura'); ?>>Assinatura (Recorrente)</option>
                        <option value="vitalicio" <?php selected($tipo_acesso, 'vitalicio'); ?>>Vitalício (Acesso Infinito)</option>
                    </select>
                </div>
                <div class="form-group" id="conf_dias_group">
                    <label>Dias de Acesso</label>
                    <input type="number" name="dias_acesso" value="<?php echo intval($dias_acesso); ?>" min="1">
                    <p class="form-hint">Quantos dias o aluno terá acesso após a compra</p>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary">Salvar Configurações</button>
        </form>
    </div>
</div>

<div class="modal-overlay" id="modal-modulo">
    <div class="modal">
        <div class="modal-header">
            <h3 id="modal-modulo-title">Novo Módulo</h3>
            <span class="modal-close" onclick="closeModal('modal-modulo')">×</span>
        </div>
        <form id="form-modulo">
            <input type="hidden" name="modulo_id" id="modulo_id">
            <input type="hidden" name="curso_id" value="<?php echo $curso_id; ?>">
            <div class="form-group">
                <label>Nome do Módulo *</label>
                <input type="text" name="titulo" id="modulo_titulo" required>
            </div>
            <div style="display:flex;gap:12px;">
                <button type="submit" class="btn btn-primary">Salvar Módulo</button>
                <button type="button" class="btn btn-secondary" onclick="closeModal('modal-modulo')">Cancelar</button>
            </div>
        </form>
    </div>
</div>

<div class="modal-overlay" id="modal-dup-aula">
    <div class="modal">
        <div class="modal-header">
            <h3>Duplicar Aula</h3>
            <span class="modal-close" onclick="closeModal('modal-dup-aula')">×</span>
        </div>
        <form id="form-dup-aula">
            <input type="hidden" name="source_id" id="dup_aula_source_id">
            <input type="hidden" name="type" value="aula">
            
            <div class="form-group">
                <label>Para qual Curso?</label>
                <select name="target_course_id" id="dup_aula_course_select" onchange="razLoadModulesForDup(this.value)" required style="width:100%;padding:10px;">
                    <option value="">Selecione...</option>
                    <?php foreach ($all_courses as $c): ?>
                        <option value="<?php echo $c->ID; ?>" <?php selected($c->ID, $curso_id); ?>><?php echo esc_html($c->post_title); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Para qual Módulo?</label>
                <select name="target_module_id" id="dup_aula_module_select" required style="width:100%;padding:10px;">
                    <option value="">Selecione um curso primeiro...</option>
                </select>
            </div>
            
            <div style="display:flex;gap:12px;justify-content:flex-end;">
                <button type="button" class="btn btn-secondary" onclick="closeModal('modal-dup-aula')">Cancelar</button>
                <button type="submit" class="btn btn-primary">Duplicar</button>
            </div>
        </form>
    </div>
</div>

<div class="modal-overlay" id="modal-dup-modulo">
    <div class="modal">
        <div class="modal-header">
            <h3>Duplicar Módulo</h3>
            <span class="modal-close" onclick="closeModal('modal-dup-modulo')">×</span>
        </div>
        <div style="padding:0 20px;">
            <p style="font-size:13px;color:#666;margin-bottom:15px;background:#fff8e1;padding:10px;border-radius:4px;">
                Isso copiará o módulo inteiro e <strong>todas as suas aulas</strong> para o curso selecionado.
            </p>
        </div>
        <form id="form-dup-modulo">
            <input type="hidden" name="source_id" id="dup_mod_source_id">
            <input type="hidden" name="type" value="modulo">
            
            <div class="form-group">
                <label>Para qual Curso?</label>
                <select name="target_course_id" required style="width:100%;padding:10px;">
                    <?php foreach ($all_courses as $c): ?>
                        <option value="<?php echo $c->ID; ?>" <?php selected($c->ID, $curso_id); ?>><?php echo esc_html($c->post_title); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div style="display:flex;gap:12px;justify-content:flex-end;">
                <button type="button" class="btn btn-secondary" onclick="closeModal('modal-dup-modulo')">Cancelar</button>
                <button type="submit" class="btn btn-primary">Duplicar Módulo</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.14.0/Sortable.min.js"></script>
<script>
var cursoId = <?php echo $curso_id ?: 0; ?>;
var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
var nonce = '<?php echo wp_create_nonce('raz_admin_nonce'); ?>';
var isSortingEnabled = false; // Estado inicial: travado
var sortableInstances = [];

// Cor picker sync
if(document.getElementById('cor_header')){
    document.getElementById('cor_header').addEventListener('input', function() {
        document.getElementById('cor_header_hex').value = this.value;
    });
}

// Thumbnail preview
if(document.getElementById('thumbnail-input')){
    document.getElementById('thumbnail-input').addEventListener('change', function(e) {
        var file = e.target.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('thumb-preview').innerHTML = '<img src="' + e.target.result + '" style="width:100%;height:100%;object-fit:cover;">';
            };
            reader.readAsDataURL(file);
        }
    });
}

function showTab(t,el){
    document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(x=>x.style.display='none');
    el.classList.add('active');
    document.getElementById('tab-'+t).style.display='block';
}

function toggleModulo(el){
    var content = el.nextElementSibling;
    content.style.display = content.style.display==='none'?'block':'none';
}

// Toggle Access Days
function toggleAccessDays() {
    var type = document.getElementById('conf_tipo').value;
    var group = document.getElementById('conf_dias_group');
    if(type === 'vitalicio') {
        group.style.display = 'none';
    } else {
        group.style.display = 'block';
    }
}
if(document.getElementById('conf_tipo')) toggleAccessDays();


// --- MODALS ---

function openModal(id) { 
    var el = document.getElementById(id);
    if(el) el.style.display = 'flex';
}

function closeModal(id) { 
    var el = document.getElementById(id);
    if(el) el.style.display = 'none';
}

function showModalById(id) { openModal(id); }

window.openModal = showModalById;
window.closeModal = closeModal;

// Módulo CRUD
function openModuloModal(id, titulo) {
    document.getElementById('modulo_id').value = id || '';
    document.getElementById('modulo_titulo').value = titulo || '';
    document.getElementById('modal-modulo-title').textContent = id ? 'Editar Módulo' : 'Novo Módulo';
    openModal('modal-modulo');
    document.getElementById('modulo_titulo').focus();
}

function editModulo(id, title) {
    openModuloModal(id, title);
}

// Duplication Logic
function razOpenDuplicateModule(id) {
    document.getElementById('dup_mod_source_id').value = id;
    openModal('modal-dup-modulo');
}
function razOpenDuplicateLesson(id) {
    document.getElementById('dup_aula_source_id').value = id;
    var sel = document.getElementById('dup_aula_course_select');
    sel.value = cursoId;
    razLoadModulesForDup(cursoId);
    openModal('modal-dup-aula');
}
function razLoadModulesForDup(cId) {
    var sel = document.getElementById('dup_aula_module_select');
    sel.innerHTML = '<option>Carregando...</option>';
    fetch(ajaxurl + '?action=raz_get_modules_by_course&nonce='+nonce+'&curso_id='+cId)
    .then(r=>r.json()).then(d=>{
        sel.innerHTML = '';
        if(d.success && d.data.length>0) {
            d.data.forEach(m=>{
                var opt=document.createElement('option'); opt.value=m.id; opt.textContent=m.title; sel.appendChild(opt);
            });
        } else sel.innerHTML = '<option value="">Sem módulos</option>';
    });
}

// GLOBAL SORTING TOGGLE
function toggleGlobalSorting() {
    isSortingEnabled = !isSortingEnabled;
    var btn = document.getElementById('toggle-sorting-btn');
    var icon = document.getElementById('lock-icon');
    var text = document.getElementById('lock-text');
    var list = document.getElementById('modulos-list');
    
    if(isSortingEnabled) {
        icon.innerText = '🔓';
        text.innerText = 'Bloquear Ordenação';
        btn.classList.remove('btn-secondary');
        btn.classList.add('btn-warning');
        list.classList.remove('sorting-disabled');
    } else {
        icon.innerText = '🔒';
        text.innerText = 'Destravar Ordenação';
        btn.classList.remove('btn-warning');
        btn.classList.add('btn-secondary');
        list.classList.add('sorting-disabled');
    }
    
    sortableInstances.forEach(function(instance) {
        instance.option("disabled", !isSortingEnabled);
    });
}

// Submits
document.getElementById('form-curso').onsubmit = function(e){
    e.preventDefault();
    
    // IMPORTANTÍSSIMO: Trigger save para o TinyMCE funcionar
    if (typeof tinyMCE !== 'undefined') {
        tinyMCE.triggerSave();
    }
    
    var fd = new FormData(this);
    fd.append('action','raz_save_curso'); fd.append('nonce',nonce);
    fetch(ajaxurl,{method:'POST',body:fd}).then(r=>r.json()).then(d=>{
        if(d.success) { showToast('Salvo!','success'); if(!cursoId) window.location.href=razAdmin.homeUrl+'/gestao-cursos/curso-editar/'+d.data.curso_id; }
    });
};

document.getElementById('form-config').onsubmit = function(e){
    e.preventDefault();
    var fd = new FormData(this);
    fd.append('action','raz_save_curso'); fd.append('nonce',nonce);
    fetch(ajaxurl,{method:'POST',body:fd}).then(r=>r.json()).then(d=>{ if(d.success) showToast('Salvo!','success'); });
};

document.getElementById('form-modulo').onsubmit = function(e){
    e.preventDefault();
    var fd = new FormData(this);
    fd.append('action','raz_save_modulo'); fd.append('nonce',nonce);
    fetch(ajaxurl,{method:'POST',body:fd}).then(r=>r.json()).then(d=>{ if(d.success) { showToast('Salvo!','success'); location.reload(); } else { alert(d.data.message); } });
};

document.getElementById('form-dup-aula').onsubmit = function(e){
    e.preventDefault();
    var fd = new FormData(this);
    fd.append('action','raz_duplicate_content'); fd.append('nonce',nonce);
    fetch(ajaxurl,{method:'POST',body:fd}).then(r=>r.json()).then(d=>{ if(d.success) { showToast('Duplicado!','success'); location.reload(); } });
};

document.getElementById('form-dup-modulo').onsubmit = function(e){
    e.preventDefault();
    var fd = new FormData(this);
    fd.append('action','raz_duplicate_content'); fd.append('nonce',nonce);
    fetch(ajaxurl,{method:'POST',body:fd}).then(r=>r.json()).then(d=>{ if(d.success) { showToast('Duplicado!','success'); location.reload(); } });
};

// Deletar
function deleteItem(id, type, btn) {
    if(!confirm('Excluir?')) return;
    var fd = new FormData();
    fd.append('action','raz_delete_item'); fd.append('nonce',nonce); fd.append('item_id',id); fd.append('type',type);
    fetch(ajaxurl,{method:'POST',body:fd}).then(r=>r.json()).then(d=>{ 
        if(d.success) location.reload(); 
        else alert(d.data.message);
    });
}

// Sortable Init
function initSortable() {
    if (typeof Sortable === 'undefined') return;
    
    var modulosList = document.getElementById('modulos-list');
    if (modulosList) {
        var modSort = new Sortable(modulosList, {
            animation: 150,
            handle: '.item-drag',
            ghostClass: 'sortable-ghost',
            disabled: !isSortingEnabled, // Inicialmente travado
            onEnd: function() {
                var items = [];
                modulosList.querySelectorAll('.modulo-item').forEach(function(el) {
                    items.push(el.dataset.id);
                });
                saveOrder(items, 'modulo');
            }
        });
        sortableInstances.push(modSort);
        
        document.querySelectorAll('.aulas-list').forEach(function(list) {
            var lessonSort = new Sortable(list, {
                animation: 150,
                handle: '.item-drag',
                group: 'lessons',
                ghostClass: 'sortable-ghost',
                disabled: !isSortingEnabled, // Inicialmente travado
                onEnd: function(evt) {
                    var items = [];
                    list.querySelectorAll('.item-row').forEach(function(el) {
                        items.push(el.dataset.id);
                    });
                    
                    if(evt.from !== evt.to) {
                        var lessonId = evt.item.dataset.id;
                        var newModId = evt.to.id.replace('aulas-', '');
                        updateLessonParent(lessonId, newModId);
                    }
                    
                    saveOrder(items, 'aula');
                }
            });
            sortableInstances.push(lessonSort);
        });
    }
}

document.addEventListener('DOMContentLoaded', initSortable);

function saveOrder(items, tipo) {
    fetch(razAdmin.ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=raz_reorder&nonce=' + nonce + '&tipo=' + tipo + '&items=' + JSON.stringify(items)
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
             showToast('Ordem atualizada!', 'success');
        } else {
             alert(d.data.message);
             location.reload();
        }
    });
}

function updateLessonParent(lessonId, newModId) {
    var fd = new FormData();
    fd.append('action', 'raz_save_aula');
    fd.append('nonce', nonce);
    fd.append('aula_id', lessonId);
    fd.append('modulo_id', newModId);
    fetch(ajaxurl, {method:'POST', body:fd});
}
</script>