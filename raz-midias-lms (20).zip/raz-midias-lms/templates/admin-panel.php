<?php
/**
 * Template: Admin Panel Frontend - Versão Melhorada
 * @package RazMidiasLMS
 */

if (!current_user_can('manage_options')) {
    wp_redirect(home_url());
    exit;
}

global $raz_admin_page, $raz_item_id;
$page = $raz_admin_page ?: (get_query_var('raz_admin_page') ?: 'dashboard');
$item_id = $raz_item_id ?: (get_query_var('raz_item_id') ?: 0);

$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC'));
$site_name = get_bloginfo('name');
$current_user = wp_get_current_user();

// Carregar biblioteca de mídia
wp_enqueue_media();
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Cursos - <?php echo esc_html($site_name); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    :root { 
        --primary: #6366f1; 
        --primary-dark: #4f46e5; 
        --bg: #f8fafc; 
        --card: #fff; 
        --border: #e2e8f0; 
        --text: #1e293b; 
        --muted: #64748b; 
        --success: #10b981; 
        --danger: #ef4444; 
        --warning: #f59e0b;
    }
    body { font-family: 'Inter', -apple-system, sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; }
    
    /* Header */
    .raz-site-header { background: #fff; border-bottom: 1px solid var(--border); padding: 0 24px; height: 64px; position: sticky; top: 0; z-index: 100; }
    .raz-header-content { max-width: 1400px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; height: 100%; }
    .raz-header-logo a { font-size: 18px; font-weight: 700; color: var(--text); text-decoration: none; }
    .raz-header-actions { display: flex; align-items: center; gap: 12px; }
    .raz-header-btn { padding: 8px 16px; background: var(--primary); color: #fff; border-radius: 8px; text-decoration: none; font-size: 14px; font-weight: 500; transition: background 0.15s; }
    .raz-header-btn:hover { background: var(--primary-dark); }
    .raz-header-btn-outline { padding: 8px 16px; border: 1px solid var(--border); color: var(--text); border-radius: 8px; text-decoration: none; font-size: 14px; font-weight: 500; transition: all 0.15s; }
    .raz-header-btn-outline:hover { border-color: var(--primary); color: var(--primary); }
    
    /* Footer */
    .raz-site-footer { background: #fff; border-top: 1px solid var(--border); padding: 24px; margin-top: auto; }
    .raz-footer-content { max-width: 1400px; margin: 0 auto; text-align: center; }
    .raz-footer-info p { color: var(--muted); font-size: 14px; }
    
    /* Layout */
    .admin-layout { display: flex; min-height: calc(100vh - 64px); }
    .admin-sidebar { width: 260px; background: var(--card); border-right: 1px solid var(--border); padding: 24px 0; position: sticky; top: 64px; height: calc(100vh - 64px); overflow-y: auto; }
    .admin-nav a { display: flex; align-items: center; gap: 12px; padding: 12px 24px; color: var(--muted); text-decoration: none; transition: all 0.15s; font-size: 14px; }
    .admin-nav a:hover, .admin-nav a.active { background: rgba(99,102,241,0.1); color: var(--primary); }
    .admin-nav a svg { width: 20px; height: 20px; }
    .admin-nav-divider { height: 1px; background: var(--border); margin: 16px 24px; }
    .admin-main { flex: 1; padding: 32px; max-width: calc(100% - 260px); }
    .admin-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 32px; }
    .admin-header h2 { font-size: 24px; font-weight: 600; }
    
    /* Cards Grid - Estilo Meus Cursos */
    .courses-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 24px; }
    .course-card { background: var(--card); border-radius: 16px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.08); transition: transform 0.2s, box-shadow 0.2s; }
    .course-card:hover { transform: translateY(-4px); box-shadow: 0 12px 24px rgba(0,0,0,0.1); }
    .course-card-image { aspect-ratio: 16/10; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); position: relative; overflow: hidden; }
    .course-card-image img { width: 100%; height: 100%; object-fit: cover; }
    .course-card-body { padding: 20px; }
    .course-card-title { font-size: 16px; font-weight: 600; margin-bottom: 4px; color: var(--text); }
    .course-card-meta { font-size: 13px; color: var(--muted); margin-bottom: 16px; }
    .course-card-actions { display: flex; gap: 8px; }
    .course-card-btn { flex: 1; padding: 12px; background: var(--primary); color: #fff; border: none; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; text-decoration: none; text-align: center; display: flex; align-items: center; justify-content: center; gap: 8px; transition: background 0.15s; }
    .course-card-btn:hover { background: var(--primary-dark); }
    .course-card-btn.secondary { background: var(--bg); color: var(--text); }
    .course-card-btn.secondary:hover { background: var(--border); }
    
    /* Stats */
    .stats-row { display: flex; gap: 16px; margin-bottom: 32px; flex-wrap: wrap; }
    .stat-item { background: var(--card); padding: 20px 24px; border-radius: 12px; flex: 1; min-width: 150px; }
    .stat-item h4 { font-size: 12px; color: var(--muted); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; }
    .stat-item .value { font-size: 28px; font-weight: 700; color: var(--primary); }
    
    /* Table */
    .data-table { width: 100%; background: var(--card); border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
    .data-table th, .data-table td { padding: 14px 20px; text-align: left; border-bottom: 1px solid var(--border); }
    .data-table th { font-size: 12px; color: var(--muted); text-transform: uppercase; letter-spacing: 0.5px; background: #f8fafc; font-weight: 600; }
    .data-table tr:last-child td { border-bottom: none; }
    .data-table tr:hover td { background: #fafafa; }
    
    /* Buttons */
    .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; transition: all 0.15s; border: none; text-decoration: none; }
    .btn-primary { background: var(--primary); color: #fff; }
    .btn-primary:hover { background: var(--primary-dark); }
    .btn-secondary { background: var(--bg); color: var(--text); border: 1px solid var(--border); }
    .btn-secondary:hover { border-color: var(--primary); color: var(--primary); }
    .btn-danger { background: var(--danger); color: #fff; }
    .btn-sm { padding: 6px 12px; font-size: 13px; }
    .btn svg { width: 16px; height: 16px; }
    
    /* Form */
    .form-card { background: var(--card); border-radius: 12px; padding: 32px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
    .form-group { margin-bottom: 24px; }
    .form-group label { display: block; font-size: 14px; font-weight: 500; margin-bottom: 8px; color: var(--text); }
    .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 12px 16px; border: 1px solid var(--border); border-radius: 8px; font-size: 15px; transition: border-color 0.15s; font-family: inherit; }
    .form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(99,102,241,0.1); }
    .form-group textarea { min-height: 120px; resize: vertical; }
    .form-row { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
    .form-hint { font-size: 13px; color: var(--muted); margin-top: 4px; }
    
    /* Search Box */
    .search-box { position: relative; }
    .search-box input { padding-left: 40px; }
    .search-box svg { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--muted); width: 18px; height: 18px; }
    
    /* Select2-like searchable select */
    .searchable-select { position: relative; }
    .searchable-select input { width: 100%; }
    .searchable-dropdown { position: absolute; top: 100%; left: 0; right: 0; background: #fff; border: 1px solid var(--border); border-radius: 8px; max-height: 250px; overflow-y: auto; z-index: 100; display: none; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
    .searchable-dropdown.show { display: block; }
    .searchable-option { padding: 10px 16px; cursor: pointer; font-size: 14px; }
    .searchable-option:hover { background: rgba(99,102,241,0.1); }
    .searchable-option.selected { background: var(--primary); color: #fff; }
    
    /* Tabs */
    .tabs { display: flex; gap: 4px; margin-bottom: 24px; background: var(--bg); padding: 4px; border-radius: 10px; width: fit-content; }
    .tab { padding: 10px 20px; border-radius: 8px; color: var(--muted); cursor: pointer; transition: all 0.15s; font-size: 14px; font-weight: 500; }
    .tab:hover { color: var(--text); }
    .tab.active { background: #fff; color: var(--primary); box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    
    /* Pagination */
    .pagination { display: flex; align-items: center; justify-content: center; gap: 8px; margin-top: 24px; }
    .pagination button { padding: 8px 14px; border: 1px solid var(--border); background: #fff; border-radius: 6px; cursor: pointer; font-size: 14px; }
    .pagination button:hover:not(:disabled) { border-color: var(--primary); color: var(--primary); }
    .pagination button:disabled { opacity: 0.5; cursor: not-allowed; }
    .pagination button.active { background: var(--primary); color: #fff; border-color: var(--primary); }
    .pagination-info { font-size: 14px; color: var(--muted); }
    
    /* Modal */
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; padding: 20px; }
    .modal-overlay.active { display: flex; }
    .modal { background: var(--card); border-radius: 16px; padding: 32px; width: 100%; max-width: 600px; max-height: 90vh; overflow-y: auto; }
    .modal-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; }
    .modal-header h3 { font-size: 20px; font-weight: 600; }
    .modal-close { width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; cursor: pointer; color: var(--muted); border-radius: 8px; transition: background 0.15s; }
    .modal-close:hover { background: var(--bg); }
    
    /* Badge */
    .badge { display: inline-flex; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    .badge-success { background: rgba(16,185,129,0.1); color: var(--success); }
    .badge-danger { background: rgba(239,68,68,0.1); color: var(--danger); }
    .badge-warning { background: rgba(245,158,11,0.1); color: var(--warning); }
    .badge-primary { background: rgba(99,102,241,0.1); color: var(--primary); }
    
    /* Drag & Drop */
    .sortable-item { cursor: grab; }
    .sortable-item:active { cursor: grabbing; }
    .sortable-ghost { opacity: 0.4; }
    .sortable-chosen { box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
    
    /* Module/Lesson List */
    .item-list { background: var(--card); border-radius: 12px; overflow: hidden; }
    .item-header { padding: 16px 20px; background: #f8fafc; font-weight: 600; display: flex; align-items: center; justify-content: space-between; cursor: pointer; border-bottom: 1px solid var(--border); }
    .item-header:hover { background: #f1f5f9; }
    .item-content { border-bottom: 1px solid var(--border); }
    .item-row { display: flex; align-items: center; gap: 12px; padding: 14px 20px; border-bottom: 1px solid var(--border); background: #fff; }
    .item-row:last-child { border-bottom: none; }
    .item-row:hover { background: #fafafa; }
    .item-drag { cursor: grab; color: var(--muted); padding: 4px; }
    .item-drag:hover { color: var(--text); }
    .item-title { flex: 1; font-size: 14px; }
    .item-actions { display: flex; gap: 8px; }
    
    /* Toast */
    .toast { position: fixed; bottom: 24px; right: 24px; background: var(--text); color: #fff; padding: 16px 24px; border-radius: 10px; transform: translateY(100px); opacity: 0; transition: all 0.3s; z-index: 2000; font-size: 14px; }
    .toast.show { transform: translateY(0); opacity: 1; }
    .toast.success { background: var(--success); }
    .toast.error { background: var(--danger); }
    
    /* Clickable number */
    .clickable { color: var(--primary); cursor: pointer; text-decoration: underline; }
    .clickable:hover { color: var(--primary-dark); }
    
    /* Empty state */
    .empty-state { text-align: center; padding: 60px 20px; color: var(--muted); }
    .empty-state svg { width: 64px; height: 64px; margin-bottom: 16px; opacity: 0.5; }
    .empty-state h3 { font-size: 18px; margin-bottom: 8px; color: var(--text); }
    
    @media (max-width: 1024px) {
        .admin-sidebar { display: none; }
        .admin-main { max-width: 100%; }
    }
    </style>
<?php wp_head(); ?>
</head>
<body>

<!-- Header -->
<header class="raz-site-header">
    <div class="raz-header-content">
        <div class="raz-header-logo">
            <a href="<?php echo home_url(); ?>"><?php echo esc_html(strtoupper($site_name)); ?></a>
        </div>
        <div class="raz-header-actions">
            <a href="<?php echo home_url('/meus-cursos/'); ?>" class="raz-header-btn">Meus Cursos</a>
            <a href="<?php echo wp_logout_url(home_url()); ?>" class="raz-header-btn-outline">Sair</a>
        </div>
    </div>
</header>

<div class="admin-layout">
    <!-- Sidebar -->
    <aside class="admin-sidebar">
        <nav class="admin-nav">
            <a href="<?php echo home_url('/gestao-cursos/'); ?>" class="<?php echo $page === 'dashboard' ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>
                Dashboard
            </a>
            <a href="<?php echo home_url('/gestao-cursos/cursos'); ?>" class="<?php echo $page === 'cursos' || $page === 'curso-editar' ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
                Cursos
            </a>
            <a href="<?php echo home_url('/gestao-cursos/alunos'); ?>" class="<?php echo $page === 'alunos' ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                Alunos
            </a>
            <a href="<?php echo home_url('/gestao-cursos/acessos'); ?>" class="<?php echo $page === 'acessos' ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                Acessos
            </a>
            <a href="<?php echo home_url('/gestao-cursos/relatorios'); ?>" class="<?php echo $page === 'relatorios' ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/></svg>
                Relatórios
            </a>
            <a href="<?php echo home_url('/gestao-cursos/avaliacoes'); ?>" class="<?php echo $page === 'avaliacoes' ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                Avaliações
            </a>
            <a href="<?php echo home_url('/gestao-cursos/exportar'); ?>" class="<?php echo $page === 'exportar' ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                Exportar
            </a>
            <a href="<?php echo home_url('/gestao-cursos/emails'); ?>" class="<?php echo $page === 'emails' ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                Emails
            </a>
            <a href="<?php echo home_url('/gestao-cursos/comunicacao'); ?>" class="<?php echo $page === 'comunicacao' ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                Comunicação
            </a>
            <a href="<?php echo home_url('/gestao-cursos/configuracoes'); ?>" class="<?php echo $page === 'configuracoes' ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                Configurações
            </a>
            <div class="admin-nav-divider"></div>
            <a href="<?php echo home_url(); ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                Ver Site
            </a>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="admin-main">
        <?php
        switch ($page) {
            case 'cursos':
                include RAZ_LMS_DIR . '/templates/admin/cursos.php';
                break;
            case 'curso-editar':
                include RAZ_LMS_DIR . '/templates/admin/curso-editar.php';
                break;
            case 'aula-editar':
                include RAZ_LMS_DIR . '/templates/admin/aula-editar.php';
                break;
            case 'alunos':
                include RAZ_LMS_DIR . '/templates/admin/alunos.php';
                break;
            case 'acessos':
                include RAZ_LMS_DIR . '/templates/admin/acessos.php';
                break;
            case 'relatorios':
                include RAZ_LMS_DIR . '/templates/admin/relatorios.php';
                break;
            case 'avaliacoes':
                include RAZ_LMS_DIR . '/templates/admin/avaliacoes.php';
                break;
            case 'exportar':
                include RAZ_LMS_DIR . '/templates/admin/exportar.php';
                break;
            case 'emails':
                include RAZ_LMS_DIR . '/templates/admin/emails.php';
                break;
            case 'comunicacao':
                include RAZ_LMS_DIR . '/templates/admin/comunicacao.php';
                break;
            case 'configuracoes':
                include RAZ_LMS_DIR . '/templates/admin/configuracoes.php';
                break;
            default:
                include RAZ_LMS_DIR . '/templates/admin/dashboard.php';
                break;
        }
        ?>
    </main>
</div>

<!-- Footer -->
<footer class="raz-site-footer">
    <div class="raz-footer-content">
        <div class="raz-footer-info">
            <p>© <?php echo date('Y'); ?> <?php echo esc_html(strtoupper($site_name)); ?>. Todos os direitos reservados.</p>
        </div>
    </div>
</footer>

<!-- Toast -->
<div class="toast" id="toast"></div>

<!-- SortableJS para drag and drop -->
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>

<script>
var razAdmin = {
    ajaxurl: '<?php echo admin_url('admin-ajax.php'); ?>',
    nonce: '<?php echo wp_create_nonce('raz_admin_nonce'); ?>',
    homeUrl: '<?php echo home_url(); ?>'
};

function showToast(message, type) {
    var toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = 'toast ' + (type || '') + ' show';
    setTimeout(function() { toast.classList.remove('show'); }, 3000);
}

function openModal(id) { document.getElementById(id).classList.add('active'); }
function closeModal(id) { document.getElementById(id).classList.remove('active'); }

// Close modal on overlay click
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active');
    }
});
</script>

<?php wp_footer(); ?>
</body>
</html>
