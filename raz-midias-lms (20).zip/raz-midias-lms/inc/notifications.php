<?php
/**
 * Sistema de Notificações e Avisos
 * @package RazMidiasLMS
 */

defined('ABSPATH') || exit;

/**
 * Criar tabela de notificações na ativação
 */
function raz_lms_create_notifications_table() {
    global $wpdb;
    $table = $wpdb->prefix . 'raz_notifications';
    $charset = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE IF NOT EXISTS {$table} (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        title VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        curso_id BIGINT(20) UNSIGNED DEFAULT 0,
        created_at DATETIME NOT NULL,
        created_by BIGINT(20) UNSIGNED NOT NULL,
        PRIMARY KEY (id),
        KEY curso_id (curso_id)
    ) {$charset};";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    // Tabela de leituras
    $table_read = $wpdb->prefix . 'raz_notification_reads';
    $sql_read = "CREATE TABLE IF NOT EXISTS {$table_read} (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        notification_id BIGINT(20) UNSIGNED NOT NULL,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        read_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY notif_user (notification_id, user_id),
        KEY user_id (user_id)
    ) {$charset};";
    
    dbDelta($sql_read);
}
add_action('after_switch_theme', 'raz_lms_create_notifications_table');
add_action('init', 'raz_lms_create_notifications_table');

/**
 * Obter notificações não lidas do usuário
 */
function raz_lms_get_user_notifications($user_id, $limit = 20) {
    global $wpdb;
    $table = $wpdb->prefix . 'raz_notifications';
    $table_read = $wpdb->prefix . 'raz_notification_reads';
    
    // Buscar cursos do usuário
    $user_cursos = array(0); // 0 = notificações globais
    $metas = $wpdb->get_results($wpdb->prepare(
        "SELECT meta_key FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key LIKE '_raz_curso_acesso_%%'",
        $user_id
    ));
    foreach ($metas as $m) {
        $curso_id = intval(str_replace('_raz_curso_acesso_', '', $m->meta_key));
        if ($curso_id > 0) $user_cursos[] = $curso_id;
    }
    
    $cursos_in = implode(',', array_map('intval', $user_cursos));
    
    // ALTERAÇÃO: Filtrar apenas notificações que NÃO foram lidas
    // Isso garante que após ler e recarregar, ela suma da lista.
    $notifications = $wpdb->get_results($wpdb->prepare(
        "SELECT n.* FROM {$table} n 
         WHERE n.curso_id IN ({$cursos_in})
         AND NOT EXISTS (SELECT 1 FROM {$table_read} r WHERE r.notification_id = n.id AND r.user_id = %d)
         ORDER BY n.created_at DESC 
         LIMIT %d",
        $user_id, $limit
    ));
    
    return $notifications;
}

/**
 * Contar notificações não lidas
 */
function raz_lms_count_unread_notifications($user_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'raz_notifications';
    $table_read = $wpdb->prefix . 'raz_notification_reads';
    
    $user_cursos = array(0);
    $metas = $wpdb->get_results($wpdb->prepare(
        "SELECT meta_key FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key LIKE '_raz_curso_acesso_%%'",
        $user_id
    ));
    foreach ($metas as $m) {
        $curso_id = intval(str_replace('_raz_curso_acesso_', '', $m->meta_key));
        if ($curso_id > 0) $user_cursos[] = $curso_id;
    }
    
    $cursos_in = implode(',', array_map('intval', $user_cursos));
    
    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$table} n 
         WHERE n.curso_id IN ({$cursos_in})
         AND n.id NOT IN (SELECT notification_id FROM {$table_read} WHERE user_id = %d)",
        $user_id
    ));
    
    return intval($count);
}

/**
 * Marcar notificação como lida
 */
function raz_lms_mark_notification_read($notification_id, $user_id) {
    global $wpdb;
    $table_read = $wpdb->prefix . 'raz_notification_reads';
    
    $wpdb->replace($table_read, array(
        'notification_id' => $notification_id,
        'user_id' => $user_id,
        'read_at' => current_time('mysql')
    ));
}

/**
 * Criar notificação
 */
function raz_lms_create_notification($title, $message, $curso_id = 0) {
    global $wpdb;
    $table = $wpdb->prefix . 'raz_notifications';
    
    $wpdb->insert($table, array(
        'title' => $title,
        'message' => $message,
        'curso_id' => $curso_id,
        'created_at' => current_time('mysql'),
        'created_by' => get_current_user_id()
    ));
    
    return $wpdb->insert_id;
}

/**
 * AJAX: Obter notificações do usuário
 */
function raz_lms_ajax_get_notifications() {
    $user_id = get_current_user_id();
    if (!$user_id) wp_send_json_error();
    
    $notifications = raz_lms_get_user_notifications($user_id);
    $unread = raz_lms_count_unread_notifications($user_id);
    
    $data = array();
    foreach ($notifications as $n) {
        $curso = $n->curso_id ? get_post($n->curso_id) : null;
        $data[] = array(
            'id' => $n->id,
            'title' => $n->title,
            'message' => $n->message, // Enviamos a mensagem completa para o modal
            'curso' => $curso ? $curso->post_title : 'Todos os cursos',
            'date' => date_i18n('d/m/Y H:i', strtotime($n->created_at)),
            'is_read' => false // Como filtramos apenas as não lidas, sempre será falso aqui
        );
    }
    
    wp_send_json_success(array(
        'notifications' => $data,
        'unread_count' => $unread
    ));
}
add_action('wp_ajax_raz_get_notifications', 'raz_lms_ajax_get_notifications');

/**
 * AJAX: Marcar notificação como lida
 */
function raz_lms_ajax_mark_notification_read() {
    $user_id = get_current_user_id();
    $notification_id = intval($_POST['notification_id']);
    
    if (!$user_id || !$notification_id) wp_send_json_error();
    
    raz_lms_mark_notification_read($notification_id, $user_id);
    
    wp_send_json_success(array(
        'unread_count' => raz_lms_count_unread_notifications($user_id)
    ));
}
add_action('wp_ajax_raz_mark_notification_read', 'raz_lms_ajax_mark_notification_read');

/**
 * AJAX: Marcar todas como lidas
 */
function raz_lms_ajax_mark_all_notifications_read() {
    $user_id = get_current_user_id();
    if (!$user_id) wp_send_json_error();
    
    // Pega as atuais listadas para marcar
    $notifications = raz_lms_get_user_notifications($user_id, 100);
    foreach ($notifications as $n) {
        raz_lms_mark_notification_read($n->id, $user_id);
    }
    
    wp_send_json_success();
}
add_action('wp_ajax_raz_mark_all_notifications_read', 'raz_lms_ajax_mark_all_notifications_read');

/**
 * AJAX: Criar notificação (admin)
 */
function raz_lms_ajax_create_notification() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $title = sanitize_text_field($_POST['title']);
    $message = wp_kses_post($_POST['message']);
    $curso_id = intval($_POST['curso_id']);
    
    if (empty($title) || empty($message)) {
        wp_send_json_error(array('message' => 'Título e mensagem são obrigatórios'));
    }
    
    $id = raz_lms_create_notification($title, $message, $curso_id);
    
    wp_send_json_success(array('id' => $id));
}
add_action('wp_ajax_raz_create_notification', 'raz_lms_ajax_create_notification');

/**
 * AJAX: Excluir notificação (admin)
 */
function raz_lms_ajax_delete_notification() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    global $wpdb;
    $notification_id = intval($_POST['notification_id']);
    
    $wpdb->delete($wpdb->prefix . 'raz_notifications', array('id' => $notification_id));
    $wpdb->delete($wpdb->prefix . 'raz_notification_reads', array('notification_id' => $notification_id));
    
    wp_send_json_success();
}
add_action('wp_ajax_raz_delete_notification', 'raz_lms_ajax_delete_notification');

/**
 * AJAX: Listar notificações (admin)
 */
function raz_lms_ajax_list_notifications() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    global $wpdb;
    $table = $wpdb->prefix . 'raz_notifications';
    
    $notifications = $wpdb->get_results("SELECT * FROM {$table} ORDER BY created_at DESC LIMIT 50");
    
    $data = array();
    foreach ($notifications as $n) {
        $curso = $n->curso_id ? get_post($n->curso_id) : null;
        $data[] = array(
            'id' => $n->id,
            'title' => $n->title,
            'message' => $n->message,
            'curso' => $curso ? $curso->post_title : 'Todos os cursos',
            'date' => date_i18n('d/m/Y H:i', strtotime($n->created_at))
        );
    }
    
    wp_send_json_success($data);
}
add_action('wp_ajax_raz_list_notifications', 'raz_lms_ajax_list_notifications');