<?php
/**
 * Database Handler - Gerencia tabelas personalizadas e logs de acesso
 * @package RazMidiasLMS
 */

defined('ABSPATH') || exit;

/**
 * 1. CRIA A TABELA DE LOGS AO ATIVAR O TEMA/PLUGIN
 * Tabela: wp_raz_lms_logs
 */
function raz_lms_create_tables() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'raz_lms_logs';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        curso_id bigint(20) NOT NULL,
        modulo_id bigint(20) DEFAULT 0,
        aula_id bigint(20) NOT NULL,
        ip_address varchar(45) DEFAULT '',
        user_agent text DEFAULT '',
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY user_id (user_id),
        KEY curso_id (curso_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
// Hook para criar a tabela. Você pode chamar isso manualmente ou na ativação.
add_action('after_switch_theme', 'raz_lms_create_tables');
add_action('init', 'raz_lms_check_db_exists');

function raz_lms_check_db_exists() {
    if (!get_option('raz_lms_db_version')) {
        raz_lms_create_tables();
        update_option('raz_lms_db_version', '1.0');
    }
}

/**
 * 2. FUNÇÃO PARA REGISTRAR ACESSO (LOG)
 * Chame esta função sempre que um aluno carregar uma aula.
 */
function raz_lms_log_access($user_id, $aula_id) {
    if (!$user_id || !$aula_id) return;

    global $wpdb;
    $table_name = $wpdb->prefix . 'raz_lms_logs';

    // Obter dados hierárquicos
    $modulo_id = get_post_meta($aula_id, '_raz_aula_modulo', true) ?: 0;
    $curso_id = $modulo_id ? get_post_meta($modulo_id, '_raz_modulo_curso', true) : 0;

    // Evitar log duplicado no mesmo minuto (anti-flood)
    $recent_log = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $table_name WHERE user_id = %d AND aula_id = %d AND created_at > %s",
        $user_id, $aula_id, date('Y-m-d H:i:s', strtotime('-1 minute'))
    ));

    if ($recent_log) return;

    // Inserir Log
    $wpdb->insert(
        $table_name,
        array(
            'user_id' => $user_id,
            'curso_id' => $curso_id,
            'modulo_id' => $modulo_id,
            'aula_id' => $aula_id,
            'ip_address' => raz_lms_get_ip(),
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
            'created_at' => current_time('mysql')
        ),
        array('%d', '%d', '%d', '%d', '%s', '%s', '%s')
    );

    // Atualizar meta de "Último Acesso" para facilitar consultas rápidas
    update_user_meta($user_id, '_raz_last_access_timestamp', current_time('timestamp'));
    update_user_meta($user_id, '_raz_last_ip', raz_lms_get_ip());
    update_user_meta($user_id, '_raz_last_ua', $_SERVER['HTTP_USER_AGENT']);
    update_user_meta($user_id, '_raz_last_aula_' . $curso_id, $aula_id);
    
    // Incrementar contador total
    $count = (int) get_user_meta($user_id, '_raz_access_count', true);
    update_user_meta($user_id, '_raz_access_count', $count + 1);
}

/**
 * 3. TRIGGER AUTOMÁTICO AO VER AULA (Hook no WordPress)
 */
function raz_lms_track_lesson_view() {
    if (is_singular('aula') && is_user_logged_in()) {
        raz_lms_log_access(get_current_user_id(), get_the_ID());
    }
}
add_action('template_redirect', 'raz_lms_track_lesson_view');

/**
 * Helper: Pegar IP Real
 */
function raz_lms_get_ip() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return $_SERVER['HTTP_X_FORWARDED_FOR'];
    return $_SERVER['REMOTE_ADDR'];
}