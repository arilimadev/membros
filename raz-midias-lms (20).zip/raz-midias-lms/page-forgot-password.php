<?php
/**
 * Template Name: Esqueci a Senha
 * @package RazMidiasLMS
 */

// Se já está logado, redireciona
if (is_user_logged_in()) {
    wp_redirect(home_url('/meus-cursos'));
    exit;
}

$login_logo = get_option('raz_lms_login_logo', '');
$login_bg_color = get_option('raz_lms_login_bg_color', '#667eea');
$login_btn_color = get_option('raz_lms_login_btn_color', '#4f46e5');

$message = '';
$message_type = '';

// Processar envio
if (isset($_POST['forgot_submit']) && isset($_POST['user_login'])) {
    $user_login = sanitize_text_field($_POST['user_login']);
    
    if (empty($user_login)) {
        $message = 'Por favor, informe seu email ou nome de usuário.';
        $message_type = 'error';
    } else {
        // Verificar se existe
        $user = get_user_by('email', $user_login);
        if (!$user) {
            $user = get_user_by('login', $user_login);
        }
        
        if ($user) {
            // Gerar chave de reset
            $key = get_password_reset_key($user);
            
            if (!is_wp_error($key)) {
                // Enviar email
                $reset_link = home_url('/nova-senha/?key=' . $key . '&login=' . rawurlencode($user->user_login));
                
                $subject = 'Redefinir sua senha - ' . get_bloginfo('name');
                $body = "Olá " . $user->display_name . ",\n\n";
                $body .= "Recebemos uma solicitação para redefinir sua senha.\n\n";
                $body .= "Clique no link abaixo para criar uma nova senha:\n";
                $body .= $reset_link . "\n\n";
                $body .= "Se você não solicitou isso, ignore este email.\n\n";
                $body .= "Atenciosamente,\n";
                $body .= get_bloginfo('name');
                
                $headers = array('Content-Type: text/plain; charset=UTF-8');
                
                if (wp_mail($user->user_email, $subject, $body, $headers)) {
                    $message = 'Enviamos um link de recuperação para seu email!';
                    $message_type = 'success';
                } else {
                    $message = 'Erro ao enviar email. Tente novamente.';
                    $message_type = 'error';
                }
            } else {
                $message = 'Erro ao gerar link. Tente novamente.';
                $message_type = 'error';
            }
        } else {
            // Por segurança, não revelamos se o email existe ou não
            $message = 'Se o email estiver cadastrado, você receberá um link de recuperação.';
            $message_type = 'success';
        }
    }
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Esqueci a Senha - <?php bloginfo('name'); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <?php wp_head(); ?>
    <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
        font-family: 'Inter', -apple-system, sans-serif;
        min-height: 100vh;
        display: flex;
        background: linear-gradient(135deg, <?php echo esc_attr($login_bg_color); ?> 0%, #764ba2 100%);
    }
    .login-container {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }
    .login-box {
        background: #fff;
        border-radius: 24px;
        padding: 48px 40px;
        width: 100%;
        max-width: 420px;
        box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
    }
    .login-logo {
        text-align: center;
        margin-bottom: 32px;
    }
    .login-logo img {
        max-height: 60px;
        max-width: 200px;
    }
    .login-logo h1 {
        font-size: 28px;
        font-weight: 700;
        color: #1e293b;
    }
    .login-title {
        text-align: center;
        margin-bottom: 8px;
        font-size: 24px;
        font-weight: 600;
        color: #1e293b;
    }
    .login-subtitle {
        text-align: center;
        margin-bottom: 32px;
        color: #64748b;
        font-size: 14px;
        line-height: 1.5;
    }
    .form-group {
        margin-bottom: 24px;
    }
    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
        font-size: 14px;
        color: #374151;
    }
    .form-group input {
        width: 100%;
        padding: 14px 16px;
        border: 2px solid #e5e7eb;
        border-radius: 12px;
        font-size: 16px;
        transition: border-color 0.15s, box-shadow 0.15s;
        font-family: inherit;
    }
    .form-group input:focus {
        outline: none;
        border-color: <?php echo esc_attr($login_btn_color); ?>;
        box-shadow: 0 0 0 3px <?php echo esc_attr($login_btn_color); ?>20;
    }
    .btn-submit {
        width: 100%;
        padding: 16px;
        background: <?php echo esc_attr($login_btn_color); ?>;
        color: #fff;
        border: none;
        border-radius: 12px;
        font-size: 16px;
        font-weight: 600;
        cursor: pointer;
        transition: transform 0.15s, box-shadow 0.15s;
        font-family: inherit;
    }
    .btn-submit:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px <?php echo esc_attr($login_btn_color); ?>40;
    }
    .message {
        padding: 14px 16px;
        border-radius: 10px;
        margin-bottom: 24px;
        font-size: 14px;
        text-align: center;
    }
    .message.error {
        background: #fef2f2;
        color: #dc2626;
        border: 1px solid #fecaca;
    }
    .message.success {
        background: #f0fdf4;
        color: #16a34a;
        border: 1px solid #bbf7d0;
    }
    .back-link {
        display: block;
        text-align: center;
        margin-top: 24px;
        color: #64748b;
        text-decoration: none;
        font-size: 14px;
    }
    .back-link:hover {
        color: <?php echo esc_attr($login_btn_color); ?>;
    }
    .icon-wrapper {
        text-align: center;
        margin-bottom: 24px;
    }
    .icon-wrapper svg {
        width: 64px;
        height: 64px;
        color: <?php echo esc_attr($login_btn_color); ?>;
    }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <div class="login-logo">
                <?php if ($login_logo) : ?>
                    <img src="<?php echo esc_url($login_logo); ?>" alt="<?php bloginfo('name'); ?>">
                <?php else : ?>
                    <h1><?php bloginfo('name'); ?></h1>
                <?php endif; ?>
            </div>
            
            <div class="icon-wrapper">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                </svg>
            </div>
            
            <h2 class="login-title">Esqueceu a senha?</h2>
            <p class="login-subtitle">Informe seu email e enviaremos um link para você criar uma nova senha.</p>
            
            <?php if ($message) : ?>
            <div class="message <?php echo esc_attr($message_type); ?>">
                <?php echo esc_html($message); ?>
            </div>
            <?php endif; ?>
            
            <form method="post">
                <div class="form-group">
                    <label for="user_login">Email ou nome de usuário</label>
                    <input type="text" name="user_login" id="user_login" placeholder="seu@email.com" required autofocus>
                </div>
                
                <button type="submit" name="forgot_submit" class="btn-submit">
                    Enviar link de recuperação
                </button>
            </form>
            
            <a href="<?php echo wp_login_url(); ?>" class="back-link">
                ← Voltar para o login
            </a>
        </div>
    </div>
    <?php wp_footer(); ?>
</body>
</html>
