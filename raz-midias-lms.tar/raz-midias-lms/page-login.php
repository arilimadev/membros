<?php
/**
 * Template Name: Login
 * @package RazMidiasLMS
 */

// Se já está logado, redireciona
if (is_user_logged_in()) {
    $user = wp_get_current_user();
    if (in_array('administrator', $user->roles)) {
        wp_redirect(home_url('/gestao-cursos/'));
    } else {
        wp_redirect(home_url('/meus-cursos/'));
    }
    exit;
}

// Buscar configurações salvas
$login_logo = get_option('raz_lms_login_logo', '');
$login_bg_color = get_option('raz_lms_login_bg_color', '#667eea');
$login_btn_color = get_option('raz_lms_login_btn_color', '#4f46e5');

// Fallbacks
if (empty($login_bg_color)) $login_bg_color = '#667eea';
if (empty($login_btn_color)) $login_btn_color = '#4f46e5';

$error = '';

// Processar login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_login'])) {
    $creds = array(
        'user_login' => sanitize_text_field($_POST['user_login']),
        'user_password' => $_POST['user_password'],
        'remember' => isset($_POST['remember'])
    );
    
    $user = wp_signon($creds, is_ssl());
    
    if (is_wp_error($user)) {
        $error = 'Email ou senha incorretos.';
    } else {
        // Redirecionar baseado no role
        if (in_array('administrator', $user->roles)) {
            wp_redirect(home_url('/gestao-cursos/'));
        } else {
            // Verificar se tem aula salva para continuar
            $last_curso = get_user_meta($user->ID, '_raz_last_curso', true);
            $last_aula = $last_curso ? get_user_meta($user->ID, '_raz_last_aula_' . $last_curso, true) : null;
            
            if ($last_aula && get_post($last_aula)) {
                wp_redirect(get_permalink($last_aula));
            } else {
                wp_redirect(home_url('/meus-cursos/'));
            }
        }
        exit;
    }
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Entrar - <?php bloginfo('name'); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <?php wp_head(); ?>
    <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
        font-family: 'Inter', -apple-system, sans-serif;
        min-height: 100vh;
        display: flex;
        /* ALTERAÇÃO AQUI: Gradiente removido, usa apenas a cor do banco de dados */
        background: <?php echo esc_attr($login_bg_color); ?>;
    }
    .login-container {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }
    .login-box {
        background: #fff;
        border-radius: 24px;
        padding: 40px 32px;
        width: 100%;
        max-width: 400px;
        box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
    }
    .login-logo {
        text-align: center;
        margin-bottom: 32px;
        width: 100%;
    }
    .login-logo img {
        max-height: 80px;
        max-width: 200px;
        margin: 0 auto;
        display: block;
    }
    .login-logo h1 {
        font-size: 24px;
        font-weight: 700;
        color: #1e293b;
    }
    .login-title {
        text-align: center;
        margin-bottom: 24px;
        font-size: 20px;
        font-weight: 600;
        color: #1e293b;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        display: block;
        margin-bottom: 6px;
        font-weight: 500;
        font-size: 14px;
        color: #374151;
    }
    .form-group input[type="text"],
    .form-group input[type="email"],
    .form-group input[type="password"] {
        width: 100%;
        padding: 14px 16px;
        border: 2px solid #e5e7eb;
        border-radius: 10px;
        font-size: 15px;
        transition: border-color 0.15s;
        font-family: inherit;
    }
    .form-group input:focus {
        outline: none;
        border-color: <?php echo esc_attr($login_btn_color); ?>;
    }
    .password-wrapper {
        position: relative;
    }
    .password-wrapper input {
        padding-right: 48px;
    }
    .toggle-password {
        position: absolute;
        right: 14px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        cursor: pointer;
        padding: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #9ca3af;
        transition: color 0.15s;
    }
    .toggle-password:hover {
        color: #6b7280;
    }
    .toggle-password svg {
        width: 20px;
        height: 20px;
    }
    .form-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        flex-wrap: wrap;
        gap: 12px;
    }
    .form-row label {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 14px;
        color: #64748b;
        cursor: pointer;
    }
    .form-row a {
        font-size: 14px;
        color: <?php echo esc_attr($login_btn_color); ?>;
        text-decoration: none;
    }
    .form-row a:hover {
        text-decoration: underline;
    }
    .btn-login {
        width: 100%;
        padding: 14px;
        background: <?php echo esc_attr($login_btn_color); ?>;
        color: #fff;
        border: none;
        border-radius: 10px;
        font-size: 16px;
        font-weight: 600;
        cursor: pointer;
        transition: opacity 0.15s, transform 0.15s;
        font-family: inherit;
    }
    .btn-login:hover {
        opacity: 0.9;
    }
    .btn-login:active {
        transform: scale(0.98);
    }
    .error-message {
        background: #fef2f2;
        color: #dc2626;
        padding: 12px 16px;
        border-radius: 8px;
        margin-bottom: 20px;
        font-size: 14px;
        text-align: center;
    }
    .login-footer {
        text-align: center;
        margin-top: 24px;
        font-size: 14px;
        color: #64748b;
    }
    .login-footer a {
        color: <?php echo esc_attr($login_btn_color); ?>;
        text-decoration: none;
    }
    
    @media (max-width: 480px) {
        .login-box {
            padding: 32px 24px;
            border-radius: 16px;
        }
        .login-title {
            font-size: 18px;
        }
    }
    </style>
</head>
<body>

<div class="login-container">
    <div class="login-box">
        <div class="login-logo">
            <?php if ($login_logo) : ?>
                <img src="<?php echo esc_url($login_logo); ?>" alt="<?php bloginfo('name'); ?>">
            <?php else : ?>
                <h1><?php bloginfo('name'); ?></h1>
            <?php endif; ?>
        </div>
        
        <h2 class="login-title">Acesse sua conta</h2>
        
        <?php if ($error) : ?>
        <div class="error-message"><?php echo esc_html($error); ?></div>
        <?php endif; ?>
        
        <form method="post">
            <div class="form-group">
                <label>Email</label>
                <input type="text" name="user_login" required autofocus autocomplete="email">
            </div>
            
            <div class="form-group">
                <label>Senha</label>
                <div class="password-wrapper">
                    <input type="password" name="user_password" id="user_password" required autocomplete="current-password">
                    <button type="button" class="toggle-password" onclick="togglePassword()">
                        <svg id="eye-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                        </svg>
                        <svg id="eye-off-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" style="display: none;">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
                        </svg>
                    </button>
                </div>
            </div>
            
            <div class="form-row">
                <label>
                    <input type="checkbox" name="remember" value="1">
                    Lembrar de mim
                </label>
                <a href="<?php echo home_url('/esqueci-senha'); ?>">Esqueceu a senha?</a>
            </div>
            
            <button type="submit" class="btn-login">Entrar</button>
        </form>
        <!--
        <div class="login-footer">
            <a href="<?php echo home_url(); ?>">← Voltar ao site</a>
        </div>
        -->
    </div>
</div>

<script>
function togglePassword() {
    const passwordInput = document.getElementById('user_password');
    const eyeIcon = document.getElementById('eye-icon');
    const eyeOffIcon = document.getElementById('eye-off-icon');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        eyeIcon.style.display = 'none';
        eyeOffIcon.style.display = 'block';
    } else {
        passwordInput.type = 'password';
        eyeIcon.style.display = 'block';
        eyeOffIcon.style.display = 'none';
    }
}
</script>

<?php wp_footer(); ?>
</body>
</html>