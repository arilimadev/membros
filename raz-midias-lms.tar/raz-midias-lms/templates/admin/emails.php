<?php
/**
 * Admin: Configuração de Emails
 * Design: Premium UX/UI
 */

// Recuperar Opções
$email_boas_vindas = get_option('raz_lms_email_boas_vindas', array(
    'ativo' => '1',
    'assunto' => 'Bem-vindo ao {curso}!',
    'mensagem' => "Olá {nome},\n\nSeja bem-vindo ao curso {curso}!\n\nVocê já pode começar a estudar acessando:\n{link_curso}\n\nSeu acesso é válido até: {data_expiracao}\n\nBons estudos!\n{site_nome}"
));

$email_expirando = get_option('raz_lms_email_expirando', array(
    'ativo' => '1',
    'dias_antes' => '7',
    'assunto' => 'Seu acesso ao {curso} expira em breve!',
    'mensagem' => "Olá {nome},\n\nSeu acesso ao curso {curso} expira em {dias_restantes} dias ({data_expiracao}).\n\nAproveite para concluir seus estudos!\n{link_curso}\n\nCaso queira renovar seu acesso, entre em contato conosco.\n\n{site_nome}"
));

$email_conclusao = get_option('raz_lms_email_conclusao', array(
    'ativo' => '0',
    'assunto' => 'Parabéns! Você concluiu o curso {curso}!',
    'mensagem' => "Olá {nome},\n\nParabéns por concluir o curso {curso}! 🎉\n\nSeu certificado está disponível em:\n{link_certificado}\n\nContinue aprendendo!\n{site_nome}"
));

// Lógica de Salvamento
$mensagem_feedback = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['raz_email_nonce']) && wp_verify_nonce($_POST['raz_email_nonce'], 'raz_save_emails')) {
    if (isset($_POST['boas_vindas'])) {
        // Checkbox não enviado se desmarcado, forçar 0 se não existir
        if (!isset($_POST['boas_vindas']['ativo'])) $_POST['boas_vindas']['ativo'] = '0';
        update_option('raz_lms_email_boas_vindas', array_map('sanitize_textarea_field', $_POST['boas_vindas']));
        $email_boas_vindas = $_POST['boas_vindas'];
    }
    
    if (isset($_POST['expirando'])) {
        if (!isset($_POST['expirando']['ativo'])) $_POST['expirando']['ativo'] = '0';
        update_option('raz_lms_email_expirando', array_map('sanitize_textarea_field', $_POST['expirando']));
        $email_expirando = $_POST['expirando'];
    }
    
    if (isset($_POST['conclusao'])) {
        if (!isset($_POST['conclusao']['ativo'])) $_POST['conclusao']['ativo'] = '0';
        update_option('raz_lms_email_conclusao', array_map('sanitize_textarea_field', $_POST['conclusao']));
        $email_conclusao = $_POST['conclusao'];
    }
    
    $mensagem_feedback = '
    <div class="raz-alert raz-alert-success">
        <div class="raz-alert-icon"><svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg></div>
        <div class="raz-alert-content">Configurações de e-mail salvas com sucesso!</div>
    </div>';
}
?>

<style>
    :root {
        --raz-primary: #0891b2;
        --raz-primary-hover: #0e7490;
        --raz-bg: #f8fafc;
        --raz-surface: #ffffff;
        --raz-border: #e2e8f0;
        --raz-text: #1e293b;
        --raz-text-muted: #64748b;
        --raz-text-light: #94a3b8;
        --raz-success-bg: #ecfdf5;
        --raz-success-text: #059669;
        --raz-success-border: #10b981;
        --raz-radius: 8px;
        --raz-radius-lg: 12px;
        --raz-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        --transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .raz-admin-container {
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        color: var(--raz-text);
        max-width: 900px; /* Largura um pouco menor para leitura confortável */
        margin: 20px auto 60px;
    }

    /* Headings */
    .raz-page-header {
        margin-bottom: 32px;
        padding-bottom: 20px;
        border-bottom: 1px solid var(--raz-border);
    }
    .raz-page-title {
        font-size: 24px;
        font-weight: 700;
        color: var(--raz-text);
        margin: 0 0 8px 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .raz-page-title svg { color: var(--raz-primary); }
    .raz-page-desc {
        font-size: 14px;
        color: var(--raz-text-muted);
        margin: 0;
    }

    /* Alerts */
    .raz-alert {
        padding: 16px;
        border-radius: var(--raz-radius);
        margin-bottom: 24px;
        display: flex;
        align-items: center;
        gap: 12px;
        border-left: 4px solid transparent;
        animation: slideIn 0.3s ease-out;
    }
    .raz-alert-success { background: var(--raz-success-bg); border-left-color: var(--raz-success-border); color: #064e3b; }
    @keyframes slideIn { from { transform: translateY(-10px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

    /* Cards */
    .raz-card {
        background: var(--raz-surface);
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius-lg);
        padding: 24px;
        box-shadow: var(--raz-shadow);
        margin-bottom: 24px;
        transition: var(--transition);
    }
    .raz-card:focus-within { border-color: var(--raz-primary); }

    .raz-card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        padding-bottom: 16px;
        border-bottom: 1px solid #f1f5f9;
    }

    .raz-card-title {
        font-size: 16px;
        font-weight: 700;
        color: var(--raz-text);
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .raz-card-title svg { color: var(--raz-text-muted); }

    /* Form Elements */
    .raz-form-group { margin-bottom: 16px; }
    .raz-label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 8px; color: var(--raz-text); }
    
    .raz-input, .raz-textarea {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius);
        font-size: 14px;
        font-family: inherit;
        background: #fff;
        transition: var(--transition);
        box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        color: var(--raz-text);
    }
    .raz-textarea { line-height: 1.5; resize: vertical; min-height: 120px; }
    
    .raz-input:focus, .raz-textarea:focus {
        border-color: var(--raz-primary);
        outline: none;
        box-shadow: 0 0 0 3px rgba(8, 145, 178, 0.15);
    }

    /* Switch Toggle */
    .raz-switch {
        position: relative;
        display: inline-flex;
        align-items: center;
        gap: 10px;
        cursor: pointer;
    }
    .raz-switch input { opacity: 0; width: 0; height: 0; position: absolute; }
    .raz-slider {
        position: relative;
        width: 44px;
        height: 24px;
        background-color: #cbd5e1;
        border-radius: 34px;
        transition: .3s;
    }
    .raz-slider:before {
        position: absolute;
        content: "";
        height: 18px;
        width: 18px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        border-radius: 50%;
        transition: .3s;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }
    .raz-switch input:checked + .raz-slider { background-color: var(--raz-primary); }
    .raz-switch input:checked + .raz-slider:before { transform: translateX(20px); }
    .raz-switch-label { font-size: 13px; font-weight: 600; color: var(--raz-text); }

    /* Info Box (Variables) */
    .raz-info-box {
        background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
        border: 1px solid #bae6fd;
        border-radius: var(--raz-radius);
        padding: 16px 20px;
        margin-bottom: 32px;
    }
    .raz-info-title {
        font-size: 14px;
        font-weight: 700;
        color: #0369a1;
        margin-bottom: 12px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .raz-var-list { display: flex; flex-wrap: wrap; gap: 8px; }
    .raz-var-tag {
        background: #fff;
        color: #0284c7;
        padding: 4px 10px;
        border-radius: 6px;
        font-size: 12px;
        font-family: 'Fira Code', monospace;
        border: 1px solid #bae6fd;
        cursor: help;
        transition: var(--transition);
    }
    .raz-var-tag:hover { transform: translateY(-1px); box-shadow: 0 2px 4px rgba(0,0,0,0.05); }

    /* Button */
    .raz-btn-primary {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 12px 24px;
        font-size: 14px;
        font-weight: 600;
        border-radius: var(--raz-radius);
        cursor: pointer;
        border: none;
        transition: var(--transition);
        background: var(--raz-primary);
        color: white;
        box-shadow: 0 1px 2px rgba(0,0,0,0.1);
        gap: 8px;
    }
    .raz-btn-primary:hover {
        background: var(--raz-primary-hover);
        transform: translateY(-1px);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }

    .raz-helper-text { font-size: 13px; color: var(--raz-text-muted); margin-bottom: 16px; line-height: 1.5; }
</style>

<div class="raz-admin-container">
    
    <div class="raz-page-header">
        <h2 class="raz-page-title">
            <svg width="28" height="28" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
            Configuração de E-mails
        </h2>
        <p class="raz-page-desc">Personalize as mensagens automáticas enviadas para os seus alunos.</p>
    </div>

    <?php echo $mensagem_feedback; ?>

    <form method="post">
        <?php wp_nonce_field('raz_save_emails', 'raz_email_nonce'); ?>
        
        <div class="raz-info-box">
            <div class="raz-info-title">
                <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                Variáveis Dinâmicas Disponíveis
            </div>
            <div class="raz-var-list">
                <span class="raz-var-tag" title="Nome completo do aluno">{nome}</span>
                <span class="raz-var-tag" title="E-mail do aluno">{email}</span>
                <span class="raz-var-tag" title="Senha de acesso (apenas novos usuários)">{senha}</span>
                <span class="raz-var-tag" title="Nome do curso">{curso}</span>
                <span class="raz-var-tag" title="Link direto para o curso">{link_curso}</span>
                <span class="raz-var-tag" title="Data que o acesso expira">{data_expiracao}</span>
                <span class="raz-var-tag" title="Dias restantes de acesso">{dias_restantes}</span>
                <span class="raz-var-tag" title="Nome do seu site">{site_nome}</span>
                <span class="raz-var-tag" title="URL do seu site">{site_url}</span>
                <span class="raz-var-tag" title="Link para baixar certificado (apenas conclusão)">{link_certificado}</span>
            </div>
        </div>
        
        <div class="raz-card">
            <div class="raz-card-header">
                <div class="raz-card-title">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    E-mail de Boas-vindas
                </div>
                <label class="raz-switch">
                    <input type="checkbox" name="boas_vindas[ativo]" value="1" <?php checked(isset($email_boas_vindas['ativo']) && $email_boas_vindas['ativo']); ?>>
                    <span class="raz-slider"></span>
                    <span class="raz-switch-label">Ativo</span>
                </label>
            </div>
            
            <p class="raz-helper-text">Este e-mail é enviado automaticamente assim que um aluno recebe acesso ao curso (compra aprovada ou cadastro manual).</p>
            
            <div class="raz-form-group">
                <label class="raz-label">Assunto</label>
                <input type="text" class="raz-input" name="boas_vindas[assunto]" value="<?php echo esc_attr($email_boas_vindas['assunto']); ?>">
            </div>
            
            <div class="raz-form-group">
                <label class="raz-label">Mensagem</label>
                <textarea class="raz-textarea" name="boas_vindas[mensagem]"><?php echo esc_textarea($email_boas_vindas['mensagem']); ?></textarea>
            </div>
        </div>
        
        <div class="raz-card">
            <div class="raz-card-header">
                <div class="raz-card-title">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    Aviso de Expiração
                </div>
                <label class="raz-switch">
                    <input type="checkbox" name="expirando[ativo]" value="1" <?php checked(isset($email_expirando['ativo']) && $email_expirando['ativo']); ?>>
                    <span class="raz-slider"></span>
                    <span class="raz-switch-label">Ativo</span>
                </label>
            </div>

            <p class="raz-helper-text">Enviado automaticamente para lembrar o aluno que o acesso está acabando.</p>
            
            <div class="raz-form-group">
                <label class="raz-label">Enviar quantos dias antes?</label>
                <input type="number" class="raz-input" name="expirando[dias_antes]" value="<?php echo intval($email_expirando['dias_antes']); ?>" min="1" max="60" style="max-width: 120px;">
            </div>
            
            <div class="raz-form-group">
                <label class="raz-label">Assunto</label>
                <input type="text" class="raz-input" name="expirando[assunto]" value="<?php echo esc_attr($email_expirando['assunto']); ?>">
            </div>
            
            <div class="raz-form-group">
                <label class="raz-label">Mensagem</label>
                <textarea class="raz-textarea" name="expirando[mensagem]"><?php echo esc_textarea($email_expirando['mensagem']); ?></textarea>
            </div>
        </div>
        
        <div class="raz-card">
            <div class="raz-card-header">
                <div class="raz-card-title">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    Conclusão do Curso
                </div>
                <label class="raz-switch">
                    <input type="checkbox" name="conclusao[ativo]" value="1" <?php checked(isset($email_conclusao['ativo']) && $email_conclusao['ativo']); ?>>
                    <span class="raz-slider"></span>
                    <span class="raz-switch-label">Ativo</span>
                </label>
            </div>

            <p class="raz-helper-text">Enviado quando o aluno completa 100% das aulas obrigatórias do curso.</p>
            
            <div class="raz-form-group">
                <label class="raz-label">Assunto</label>
                <input type="text" class="raz-input" name="conclusao[assunto]" value="<?php echo esc_attr($email_conclusao['assunto']); ?>">
            </div>
            
            <div class="raz-form-group">
                <label class="raz-label">Mensagem</label>
                <textarea class="raz-textarea" name="conclusao[mensagem]"><?php echo esc_textarea($email_conclusao['mensagem']); ?></textarea>
            </div>
        </div>
        
        <div style="position: sticky; bottom: 20px; text-align: right;">
            <button type="submit" class="raz-btn-primary">
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                Salvar Todas as Configurações
            </button>
        </div>
    </form>
</div>