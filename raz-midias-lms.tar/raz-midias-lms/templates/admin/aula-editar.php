<?php
/**
 * Admin: Editar Aula - Com Preview Real (Client-Side), Rascunho Automático e Rotina
 * Integração com WP Editor (TinyMCE) mantendo Layout Original
 *
 * Alterações:
 * - Removida frase "Editor padrão do WordPress".
 * - Adicionadas opções de Cor de Texto e Cor de Fundo.
 * - REMOVIDO CAMPO DURAÇÃO.
 *
 * @package RazMidiasLMS
 */

defined( 'ABSPATH' ) || exit;

// -----------------------------------------------------------------------------
// 1. INICIALIZAÇÃO E DADOS
// -----------------------------------------------------------------------------

$aula_id = isset( $item_id ) ? $item_id : 0;

// Fallback para pegar ID da URL se não vier da global
if ( ! $aula_id && isset( $_GET['aula_id'] ) ) {
    $aula_id = intval( $_GET['aula_id'] );
}

$aula = $aula_id ? get_post( $aula_id ) : null;

// Recuperar Módulo e Curso
$modulo_id = 0;
if ( $aula_id ) {
    $modulo_id = get_post_meta( $aula_id, '_raz_aula_modulo', true );
} elseif ( isset( $_GET['modulo'] ) ) {
    $modulo_id = intval( $_GET['modulo'] );
}

$curso_id = 0;
if ( isset( $_GET['curso'] ) ) {
    $curso_id = intval( $_GET['curso'] );
}

if ( ! $curso_id && $modulo_id ) {
    $curso_id = get_post_meta( $modulo_id, '_raz_modulo_curso', true );
}

$modulo = $modulo_id ? get_post( $modulo_id ) : null;
$curso  = $curso_id ? get_post( $curso_id ) : null;

// Metadados
$video_url      = $aula_id ? get_post_meta( $aula_id, '_raz_aula_video_url', true ) : '';
$video_provider = $aula_id ? get_post_meta( $aula_id, '_raz_aula_video_provider', true ) : '';
// $duracao removido conforme solicitado
$ordem          = $aula_id ? get_post_meta( $aula_id, '_raz_aula_ordem', true ) : 0;

$materiais = $aula_id ? get_post_meta( $aula_id, '_raz_aula_materiais', true ) : array();
if ( ! is_array( $materiais ) ) {
    $materiais = array();
}

// Rotina de Estudos
$rotina       = $aula_id ? get_post_meta( $aula_id, '_raz_aula_rotina', true ) : array();
$rotina_ativa = ! empty( $rotina['ativa'] );
$rotina_dias  = isset( $rotina['dias'] ) ? intval( $rotina['dias'] ) : 0;
$rotina_msg   = isset( $rotina['mensagem'] ) ? $rotina['mensagem'] : 'Esta aula estará disponível em breve.';

// Cores do curso para o preview
$cor_header   = $curso ? get_post_meta( $curso->ID, '_raz_curso_cor_header', true ) : '#0891b2';
$cor_controls = $curso ? get_post_meta( $curso->ID, '_raz_curso_cor_controls', true ) : '#1e293b';

if ( ! $cor_header ) {
    $cor_header = '#0891b2';
}
if ( ! $cor_controls ) {
    $cor_controls = '#1e293b';
}

$permalink = $aula_id ? get_permalink( $aula_id ) : '';

// Carrega scripts de mídia do WP (Necessário para o botão de upload e editor)
wp_enqueue_media();
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $aula_id ? 'Editar Aula' : 'Nova Aula'; ?> - <?php bloginfo( 'name' ); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <?php wp_head(); ?>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        :root { 
            --primary: #0284c7; 
            --primary-dark: #0369a1; 
            --primary-light: #e0f2fe;
            --bg: #f8fafc; 
            --card: #fff; 
            --border: #e2e8f0; 
            --text: #1e293b; 
            --text-light: #334155;
            --muted: #64748b; 
            --success: #10b981; 
            --success-light: #d1fae5;
            --warning: #f59e0b;
            --warning-light: #fef3c7;
            --danger: #ef4444; 
            --danger-light: #fef2f2;
            --gray-50: #f8fafc;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
        }
        body { font-family: 'Inter', -apple-system, sans-serif; background: var(--bg); color: var(--text); padding-bottom: 60px; }

        /* ========== HEADER ========== */
        .page-header { 
            background: var(--card); 
            border-bottom: 1px solid var(--border); 
            padding: 16px 32px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            position: sticky; 
            top: 0; 
            z-index: 100;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .page-header-left { display: flex; flex-direction: column; gap: 4px; }
        .page-header h1 { 
            font-size: 20px; 
            font-weight: 700; 
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .page-header h1 svg { color: var(--primary); }
        .back-link { 
            color: var(--muted); 
            text-decoration: none; 
            font-size: 13px; 
            display: inline-flex; 
            align-items: center; 
            gap: 6px;
            transition: all 0.2s;
        }
        .back-link:hover { color: var(--primary); }
        .back-link svg { width: 14px; height: 14px; }

        .page-header-actions {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* ========== CONTENT ========== */
        .page-content { max-width: 920px; margin: 0 auto; padding: 32px; }

        /* ========== BREADCRUMB / MODULE BADGE ========== */
        .module-badge { 
            background: linear-gradient(135deg, var(--primary-light), #dbeafe);
            padding: 14px 20px; 
            border-radius: 12px; 
            display: inline-flex; 
            align-items: center; 
            gap: 10px; 
            margin-bottom: 28px;
            border: 1px solid #bfdbfe;
        }
        .module-badge svg { color: var(--primary); }
        .module-badge span { color: var(--muted); font-size: 13px; }
        .module-badge strong { color: var(--text); font-size: 14px; }

        /* ========== FORM CARDS ========== */
        .form-card { 
            background: var(--card); 
            border-radius: 16px; 
            padding: 28px; 
            margin-bottom: 24px; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            border: 1px solid var(--border);
            transition: all 0.2s;
        }
        .form-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
        .form-card-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 20px;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--gray-100);
        }
        .form-card-icon {
            width: 44px;
            height: 44px;
            background: linear-gradient(135deg, var(--primary), #0369a1);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
        }
        .form-card-icon svg { width: 22px; height: 22px; }
        .form-card-title h3 { 
            font-size: 16px; 
            font-weight: 600; 
            margin: 0 0 4px 0;
            color: var(--text);
        }
        .form-card-title p {
            font-size: 13px;
            color: var(--muted);
            margin: 0;
        }

        /* ========== FORM ELEMENTS ========== */
        .form-group { margin-bottom: 20px; }
        .form-group:last-child { margin-bottom: 0; }
        .form-group label { 
            display: block; 
            font-size: 13px; 
            font-weight: 600; 
            margin-bottom: 8px;
            color: var(--text-light);
        }
        .form-group label .required { color: var(--danger); }
        .form-group input[type="text"], 
        .form-group input[type="url"], 
        .form-group input[type="number"], 
        .form-group select, 
        .form-group textarea { 
            width: 100%; 
            padding: 12px 16px; 
            border: 1px solid var(--gray-300); 
            border-radius: 10px; 
            font-size: 14px; 
            font-family: inherit;
            transition: all 0.2s;
            background: #fff;
        }
        .form-group input:focus, 
        .form-group select:focus,
        .form-group textarea:focus { 
            outline: none; 
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.1);
        }
        .form-group .input-title {
            font-size: 18px;
            padding: 16px 20px;
            font-weight: 500;
        }
        .form-hint { 
            font-size: 12px; 
            color: var(--muted); 
            margin-top: 6px;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        .form-hint svg { width: 14px; height: 14px; }
        
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }

        /* ========== BUTTONS ========== */
        .btn { 
            display: inline-flex; 
            align-items: center; 
            gap: 8px; 
            padding: 12px 24px; 
            border-radius: 10px; 
            font-size: 14px; 
            font-weight: 600; 
            cursor: pointer; 
            border: none; 
            text-decoration: none; 
            transition: all 0.2s; 
        }
        .btn svg { width: 16px; height: 16px; }
        .btn-primary { background: var(--primary); color: #fff; }
        .btn-primary:hover { background: var(--primary-dark); transform: translateY(-1px); box-shadow: 0 4px 12px rgba(2, 132, 199, 0.3); }
        .btn-secondary { background: #fff; color: var(--text); border: 1px solid var(--border); }
        .btn-secondary:hover { background: var(--gray-50); border-color: var(--gray-300); }
        .btn-success { background: var(--success); color: #fff; }
        .btn-danger { background: var(--danger); color: #fff; }
        .btn-sm { padding: 8px 14px; font-size: 13px; }
        .btn-lg { padding: 14px 32px; font-size: 15px; }

        /* ========== AUTOSAVE INDICATOR ========== */
        .autosave-indicator { 
            display: inline-flex; 
            align-items: center; 
            gap: 8px; 
            padding: 8px 14px; 
            border-radius: 8px; 
            font-size: 13px; 
            font-weight: 500;
            background: var(--gray-100); 
            color: var(--muted); 
            transition: all 0.3s; 
            opacity: 0; 
        }
        .autosave-indicator.show { opacity: 1; }
        .autosave-indicator.saving { background: var(--warning-light); color: #b45309; }
        .autosave-indicator.saved { background: var(--success-light); color: #059669; }
        
        /* ========== DRAFT ALERT ========== */
        .raz-draft-alert { 
            background: linear-gradient(135deg, #fffbeb, #fef3c7);
            border: 1px solid #fcd34d; 
            color: #92400e; 
            padding: 16px 20px; 
            border-radius: 12px; 
            margin-bottom: 24px; 
            display: flex; 
            align-items: center; 
            justify-content: space-between; 
            flex-wrap: wrap; 
            gap: 12px; 
            animation: slideDown 0.3s ease;
        }
        .raz-draft-alert-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .raz-draft-alert-icon {
            width: 40px;
            height: 40px;
            background: #fde68a;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .raz-draft-alert-icon svg { width: 20px; height: 20px; color: #b45309; }
        .raz-draft-alert-actions { display: flex; gap: 10px; }

        /* ========== SWITCH TOGGLE ========== */
        .switch-group {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 16px 20px;
            background: var(--gray-50);
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .switch { position: relative; display: inline-block; width: 48px; height: 26px; flex-shrink: 0; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { 
            position: absolute; 
            cursor: pointer; 
            top: 0; left: 0; right: 0; bottom: 0; 
            background-color: var(--gray-300); 
            transition: .3s; 
            border-radius: 26px; 
        }
        .slider:before { 
            position: absolute; 
            content: ""; 
            height: 20px; 
            width: 20px; 
            left: 3px; 
            bottom: 3px; 
            background-color: white; 
            transition: .3s; 
            border-radius: 50%;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        input:checked + .slider { background-color: var(--primary); }
        input:checked + .slider:before { transform: translateX(22px); }
        .switch-label { font-weight: 500; color: var(--text); }
        .switch-label small { display: block; font-weight: 400; font-size: 12px; color: var(--muted); margin-top: 2px; }

        /* ========== MATERIAIS REPEATER ========== */
        .materiais-list { display: flex; flex-direction: column; gap: 10px; margin-top: 16px; }
        .material-item { 
            display: flex; 
            align-items: center; 
            gap: 14px; 
            padding: 14px 18px; 
            background: var(--gray-50); 
            border-radius: 10px;
            border: 1px solid var(--gray-200);
            transition: all 0.2s;
        }
        .material-item:hover { border-color: var(--primary); background: #fff; }
        .material-icon {
            width: 42px;
            height: 42px;
            background: linear-gradient(135deg, var(--primary-light), #dbeafe);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        .material-icon svg { width: 20px; height: 20px; color: var(--primary); }
        .material-info { flex: 1; display: flex; flex-direction: column; gap: 4px; }
        .material-name-input { 
            border: none; 
            background: transparent; 
            font-size: 14px; 
            font-weight: 600; 
            padding: 4px 0; 
            width: 100%;
            color: var(--text);
        }
        .material-name-input:focus { outline: none; border-bottom: 2px solid var(--primary); }
        .material-type { font-size: 12px; color: var(--muted); }
        
        /* ========== TOAST ========== */
        .toast { 
            position: fixed; 
            bottom: 24px; 
            right: 24px; 
            background: var(--text); 
            color: #fff; 
            padding: 16px 24px; 
            border-radius: 12px; 
            transform: translateY(100px); 
            opacity: 0; 
            transition: all 0.3s; 
            z-index: 2000;
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 500;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }
        .toast.show { transform: translateY(0); opacity: 1; }
        .toast.success { background: var(--success); }
        .toast.error { background: var(--danger); }
        
        /* ========== ANIMATIONS ========== */
        .spin { animation: spin 1s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }

        /* ========== WP EDITOR STYLES ========== */
        .wp-editor-container { border: 1px solid var(--border); border-radius: 10px; overflow: hidden; margin-top: 10px; }
        .mce-toolbar-grp { background-color: #f8fafc !important; border-bottom: 1px solid #e2e8f0 !important; }
        .wp-editor-area { min-height: 450px !important; }
        
        .wp-editor-container ul, .mce-content-body ul, #raz_aula_content_ifr body ul {
            list-style-type: disc !important; list-style-position: inside !important; padding-left: 20px !important; margin-left: 10px !important; margin-bottom: 15px !important; display: block !important;
        }
        .wp-editor-container ol, .mce-content-body ol, #raz_aula_content_ifr body ol {
            list-style-type: decimal !important; list-style-position: inside !important; padding-left: 20px !important; margin-left: 10px !important; margin-bottom: 15px !important; display: block !important;
        }
        .wp-editor-container li, .mce-content-body li { margin-bottom: 5px !important; }

        .raz-editor-tools { 
            display: flex; 
            gap: 10px; 
            margin-bottom: 12px;
            padding: 12px 16px;
            background: var(--gray-50);
            border-radius: 10px;
            border: 1px solid var(--gray-200);
        }

        /* ========== FORM ACTIONS ========== */
        .form-actions {
            display: flex;
            gap: 16px;
            align-items: center;
            padding: 24px 28px;
            background: #fff;
            border-radius: 16px;
            border: 1px solid var(--border);
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }

        /* ========== RESPONSIVE ========== */
        @media (max-width: 768px) {
            .page-header { padding: 12px 16px; flex-direction: column; align-items: flex-start; gap: 12px; }
            .page-header-actions { width: 100%; justify-content: flex-end; }
            .page-content { padding: 16px; }
            .form-card { padding: 20px; }
            .form-row { grid-template-columns: 1fr; }
            .raz-draft-alert { flex-direction: column; align-items: flex-start; }
            .form-actions { flex-direction: column; }
            .form-actions .btn { width: 100%; justify-content: center; }
        }
    </style>
</head>
<body>

<div id="draft-alert" class="raz-draft-alert" style="display:none;">
    <div class="raz-draft-alert-content">
        <div class="raz-draft-alert-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
        </div>
        <div>
            <strong>Rascunho não salvo encontrado!</strong>
            <p style="font-size:13px;margin:4px 0 0 0;">Versão salva localmente em <span id="draft-time"></span></p>
        </div>
    </div>
    <div class="raz-draft-alert-actions">
        <button type="button" class="btn btn-sm btn-secondary" onclick="discardDraft()">Descartar</button>
        <button type="button" class="btn btn-sm btn-primary" onclick="restoreDraft()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
            Restaurar
        </button>
    </div>
</div>

<header class="page-header">
    <div class="page-header-left">
        <?php $back_link = $curso_id ? home_url( '/gestao-cursos/curso-editar/' . $curso_id . '?tab=conteudo' ) : home_url( '/gestao-cursos/cursos' ); ?>
        <a href="<?php echo esc_url( $back_link ); ?>" class="back-link">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
            Voltar para <?php echo $curso ? esc_html( $curso->post_title ) : 'Cursos'; ?>
        </a>
        <h1>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            <?php echo $aula_id ? 'Editar Aula' : 'Nova Aula'; ?>
        </h1>
    </div>
    <div class="page-header-actions">
        <span class="autosave-indicator" id="autosave-status">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><circle cx="12" cy="12" r="10"/></svg>
            <span>Não salvo</span>
        </span>
        <button type="button" class="btn btn-secondary" onclick="generateClientSidePreview()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            Preview
        </button>
        <button type="button" class="btn btn-primary" onclick="saveAula(false)">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
            Salvar
        </button>
    </div>
</header>

<div class="page-content">
    <?php if ( $modulo ) : ?>
        <div class="module-badge">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
            <span>Módulo:</span>
            <strong><?php echo esc_html( $modulo->post_title ); ?></strong>
            <?php if ($curso) : ?>
            <span style="color:var(--gray-300);">|</span>
            <span>Curso:</span>
            <strong><?php echo esc_html( $curso->post_title ); ?></strong>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <form id="form-aula">
        <input type="hidden" name="aula_id" id="aula_id" value="<?php echo $aula_id; ?>">
        <input type="hidden" name="modulo_id" value="<?php echo $modulo_id; ?>">
        <input type="hidden" name="ordem" value="<?php echo $ordem; ?>">

        <div class="form-card">
            <div class="form-group">
                <label>Título da Aula <span class="required">*</span></label>
                <input type="text" name="titulo" id="aula_titulo" class="track-change input-title" value="<?php echo $aula ? esc_attr( $aula->post_title ) : ''; ?>" required placeholder="Digite o título da aula...">
            </div>
        </div>

        <div class="form-card">
            <div class="form-card-header">
                <div class="form-card-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                </div>
                <div class="form-card-title">
                    <h3>Vídeo da Aula</h3>
                    <p>Configure o vídeo principal desta aula (opcional)</p>
                </div>
            </div>
            
            <div class="form-group">
                <label>Provedor de Vídeo</label>
                <select name="video_provider" id="video_provider" class="track-change">
                    <option value="">Sem vídeo</option>
                    <option value="youtube" <?php selected( $video_provider, 'youtube' ); ?>>YouTube</option>
                    <option value="vimeo" <?php selected( $video_provider, 'vimeo' ); ?>>Vimeo</option>
                    <option value="panda" <?php selected( $video_provider, 'panda' ); ?>>Panda Video</option>
                    <option value="bunny" <?php selected( $video_provider, 'bunny' ); ?>>Bunny Stream</option>
                    <option value="custom" <?php selected( $video_provider, 'custom' ); ?>>URL Direta (MP4)</option>
                </select>
            </div>
            <div class="form-group" id="video-url-group" style="<?php echo $video_provider ? '' : 'display:none;'; ?>">
                <label>URL do Vídeo</label>
                <div style="display:flex;gap:10px;">
                    <input type="url" name="video_url" id="video_url" class="track-change" value="<?php echo esc_url( $video_url ); ?>" placeholder="https://..." style="flex:1;">
                    <button type="button" class="btn btn-secondary" id="btn-select-video" style="display:none;" onclick="selectVideoFromLibrary()">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                        Biblioteca
                    </button>
                </div>
                <p class="form-hint">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
                    Cole a URL completa do vídeo
                </p>
            </div>
        </div>

        <div class="form-card">
            <div class="form-card-header">
                <div class="form-card-icon" style="background: linear-gradient(135deg, #8b5cf6, #7c3aed);">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                </div>
                <div class="form-card-title">
                    <h3>Conteúdo da Aula</h3>
                    <p>Texto, imagens e formatação do conteúdo escrito</p>
                </div>
            </div>
            
            <div class="raz-editor-tools">
                <button type="button" class="btn btn-sm btn-secondary" onclick="razInsertCollapse()">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
                    Inserir Acordeão
                </button>
            </div>

            <div class="editor-container">
                <?php 
                $content = $aula ? $aula->post_content : '';
                $editor_id = 'raz_aula_content'; // ID único para o editor
                
                $settings = array(
                    'media_buttons' => true, // Permite inserir mídia (Fotos/Vídeos)
                    'textarea_name' => 'raz_aula_content', // Nome do campo enviado no POST
                    'textarea_rows' => 25,
                    'teeny'         => false, // Toolbar completa
                    'quicktags'     => true, // Permite modo texto
                    'tinymce'       => array(
                        // LISTA COMPLETA DE PLUGINS ATIVOS
                        // Adicionado: table, searchreplace, print, contextmenu
                        'plugins' => 'lists,link,image,paste,wordpress,wplink,wptextpattern,hr,charmap,textcolor,colorpicker,table,searchreplace',
                        
                        // LINHA 1: Formatação Pesada e Estrutura
                        // Adicionado: fontselect, fontsizeselect
                        'toolbar1' => 'formatselect,fontselect,fontsizeselect,bold,italic,underline,strikethrough,bullist,numlist',
                        
                        // LINHA 2: Alinhamento, Links e Mídia
                        // Adicionado: justifyfull (Justificado)
                        'toolbar2' => 'alignleft,aligncenter,alignright,justifyfull,link,unlink,blockquote,hr,outdent,indent,undo,redo',
                        
                        // LINHA 3: Cores, Tabelas e Utilitários (NOVA LINHA)
                        // Adicionado: table, pastetext, removeformat, searchreplace
                        'toolbar3' => 'forecolor,backcolor,charmap,table,pastetext,removeformat,searchreplace,wp_help,fullscreen',
                        
                        // Configurações extras
                        'autoresize_min_height' => 400,
                        'wpautop'               => true,
                        'indent'                => true,
                        
                        // Mantém as tabelas com visual correto no editor
                        'content_css'           => get_bloginfo('stylesheet_directory') . '/css/editor-style.css', 
                    ),
                    'editor_class' => 'raz-wp-editor',
                );
                
                // Renderiza o Editor Padrão do WP com SUPER PODERES
                wp_editor( $content, $editor_id, $settings );
                ?>
            </div>
            <input type="hidden" name="conteudo" id="conteudo">
        </div>

        <div class="form-card">
            <div class="form-card-header">
                <div class="form-card-icon" style="background: linear-gradient(135deg, #10b981, #059669);">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                </div>
                <div class="form-card-title">
                    <h3>Materiais Complementares</h3>
                    <p>PDFs, documentos e arquivos para download</p>
                </div>
            </div>

            <button type="button" class="btn btn-secondary" onclick="addMaterial()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                Adicionar Material
            </button>

            <div class="materiais-list" id="materiais-list">
                <?php foreach ( $materiais as $index => $mat ) : ?>
                    <div class="material-item" data-index="<?php echo $index; ?>">
                        <div class="material-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                        </div>
                        <div class="material-info">
                            <input type="text" class="material-name-input track-change" name="materiais[<?php echo $index; ?>][display_name]" value="<?php echo esc_attr( $mat['display_name'] ?? $mat['nome'] ); ?>" placeholder="Nome para exibição">
                            <span class="material-type"><?php echo esc_html( $mat['tipo'] ); ?> - <?php echo esc_html( $mat['nome'] ); ?></span>
                            <input type="hidden" name="materiais[<?php echo $index; ?>][id]" value="<?php echo intval( $mat['id'] ); ?>">
                            <input type="hidden" name="materiais[<?php echo $index; ?>][nome]" value="<?php echo esc_attr( $mat['nome'] ); ?>">
                            <input type="hidden" name="materiais[<?php echo $index; ?>][url]" value="<?php echo esc_url( $mat['url'] ); ?>">
                            <input type="hidden" name="materiais[<?php echo $index; ?>][tipo]" value="<?php echo esc_attr( $mat['tipo'] ); ?>">
                        </div>
                        <button type="button" class="btn btn-sm btn-danger" onclick="removeMaterial(this)">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                        </button>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="form-card">
            <div class="form-card-header">
                <div class="form-card-icon" style="background: linear-gradient(135deg, #f59e0b, #d97706);">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                </div>
                <div class="form-card-title">
                    <h3>Rotina de Estudos (Drip Content)</h3>
                    <p>Configure quando esta aula será liberada após a matrícula</p>
                </div>
            </div>
            
            <div class="switch-group">
                <label class="switch">
                    <input type="checkbox" id="rotina_ativa" class="track-change" onchange="toggleRoutineFields()" <?php checked( $rotina_ativa ); ?>>
                    <span class="slider"></span>
                </label>
                <div class="switch-label">
                    Ativar Rotina para esta aula
                    <small>A aula só será liberada após o período definido</small>
                </div>
            </div>
            
            <div id="rotina_fields" style="display:<?php echo $rotina_ativa ? 'block' : 'none'; ?>;">
                <div class="form-row">
                    <div class="form-group">
                        <label>Liberar após quantos dias?</label>
                        <input type="number" id="rotina_dias" class="track-change" value="<?php echo esc_attr( $rotina_dias ); ?>" min="0" placeholder="Ex: 7">
                        <p class="form-hint">Dias contados a partir da data de matrícula</p>
                    </div>
                    
                    <div class="form-group">
                        <label>Mensagem de Bloqueio</label>
                        <input type="text" id="rotina_mensagem" class="track-change" value="<?php echo esc_attr( $rotina_msg ); ?>" placeholder="Ex: Esta aula será liberada em breve.">
                        <p class="form-hint">Exibida enquanto a aula estiver bloqueada</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary btn-lg">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                Salvar Aula
            </button>
            <a href="<?php echo esc_url( $back_link ); ?>" class="btn btn-secondary btn-lg">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                Cancelar
            </a>
            <?php if ($aula_id && $permalink) : ?>
            <a href="<?php echo esc_url($permalink); ?>" target="_blank" class="btn btn-secondary btn-lg" style="margin-left:auto;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                Ver Aula
            </a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="toast" id="toast"></div>

<?php wp_footer(); ?>

<script>
    var razAdmin = {
        ajaxurl: '<?php echo admin_url( 'admin-ajax.php' ); ?>',
        nonce: '<?php echo wp_create_nonce( 'raz_admin_nonce' ); ?>',
        homeUrl: '<?php echo home_url(); ?>',
        cursoId: <?php echo $curso_id ?: 0; ?>,
        corHeader: '<?php echo esc_js( $cor_header ); ?>',
        corControls: '<?php echo esc_js( $cor_controls ); ?>'
    };

    var materialIndex = <?php echo count( $materiais ); ?>;
    var aulaId = <?php echo $aula_id ?: 0; ?>;
    var draftKey = 'raz_lesson_draft_' + (aulaId || 'new');
    var autosaveTimer = null;
    var isSaving = false;

    // Inicialização
    document.addEventListener('DOMContentLoaded', function() {
        checkForDraft();
        initAutosaveListeners();
        toggleRoutineFields();
    });

    // --- FUNÇÃO PARA INSERIR COLLAPSE NO WP EDITOR ---
    function razInsertCollapse() {
        var title = prompt("Digite o título do Acordeão:");
        if (title) {
            // HTML estruturado para o Collapse (usando details/summary)
            var content = '<details class="raz-collapse"><summary>' + title + '</summary><div class="raz-collapse-content"><p>Digite o conteúdo aqui...</p></div></details><p>&nbsp;</p>';
            
            if (typeof tinyMCE !== 'undefined' && tinyMCE.activeEditor && !tinyMCE.activeEditor.isHidden()) {
                tinyMCE.activeEditor.insertContent(content);
            } else {
                // Fallback para modo texto
                var textarea = document.getElementById('raz_aula_content');
                if (textarea) {
                    // Insere na posição do cursor ou no final
                    if (textarea.selectionStart || textarea.selectionStart == '0') {
                        var startPos = textarea.selectionStart;
                        var endPos = textarea.selectionEnd;
                        textarea.value = textarea.value.substring(0, startPos) + content + textarea.value.substring(endPos, textarea.value.length);
                    } else {
                        textarea.value += content;
                    }
                }
            }
        }
    }

    // --- ROTINA TOGGLE ---
    function toggleRoutineFields() {
        var active = document.getElementById('rotina_ativa').checked;
        document.getElementById('rotina_fields').style.display = active ? 'block' : 'none';
        triggerChange();
    }

    // --- AUTOSAVE & RASCUNHOS ---

    function initAutosaveListeners() {
        var inputs = document.querySelectorAll('.track-change');
        inputs.forEach(input => {
            input.addEventListener('input', triggerChange);
        });
        
        // Listener para o TinyMCE
        if (typeof tinymce !== 'undefined') {
            setTimeout(function() {
                if (tinymce.get('raz_aula_content')) {
                    tinymce.get('raz_aula_content').on('input change keyup', triggerChange);
                }
            }, 2000);
        }
    }

    function triggerChange() {
        var status = document.getElementById('autosave-status');
        status.classList.add('show');
        status.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" class="spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg><span>Salvando...</span>';
        status.className = 'autosave-indicator show saving';

        clearTimeout(autosaveTimer);
        autosaveTimer = setTimeout(saveDraftToLocal, 3000); // 3 segundos
    }

    function getEditorContent() {
        if (typeof tinymce !== 'undefined' && tinymce.get('raz_aula_content') && !tinymce.get('raz_aula_content').isHidden()) {
            return tinymce.get('raz_aula_content').getContent();
        } else {
            return document.getElementById('raz_aula_content').value;
        }
    }

    function getFormDataObj() {
        var title = document.getElementById('aula_titulo').value;
        var content = getEditorContent();
        var video_url = document.getElementById('video_url').value;
        var video_provider = document.getElementById('video_provider').value;
        // duracao removida da coleta

        // Materiais
        var mats = [];
        document.querySelectorAll('.material-item').forEach(item => {
            var name = item.querySelector('.material-name-input').value;
            var hidden = item.querySelectorAll('input[type="hidden"]');
            mats.push({
                display_name: name,
                nome: hidden[1].value,
                url: hidden[2].value,
                tipo: hidden[3].value
            });
        });

        // Rotina
        var rotina = {
            ativa: document.getElementById('rotina_ativa').checked,
            dias: document.getElementById('rotina_dias').value,
            mensagem: document.getElementById('rotina_mensagem').value
        };

        return {
            titulo: title,
            conteudo: content,
            video_url: video_url,
            video_provider: video_provider,
            // duracao: duracao, (REMOVIDO)
            materiais: mats,
            rotina: rotina,
            timestamp: new Date().getTime()
        };
    }

    function saveDraftToLocal() {
        var data = getFormDataObj();
        localStorage.setItem(draftKey, JSON.stringify(data));

        var now = new Date();
        var timeString = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');

        var status = document.getElementById('autosave-status');
        status.className = 'autosave-indicator show saved';
        status.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><polyline points="20 6 9 17 4 12"/></svg><span>Rascunho salvo às ' + timeString + '</span>';
    }

    function checkForDraft() {
        var draft = localStorage.getItem(draftKey);
        if (draft) {
            var data = JSON.parse(draft);
            var draftDate = new Date(data.timestamp);
            var dateStr = draftDate.toLocaleDateString() + ' ' + draftDate.toLocaleTimeString();

            document.getElementById('draft-time').textContent = dateStr;
            document.getElementById('draft-alert').style.display = 'flex';
        }
    }

    function restoreDraft() {
        var draft = localStorage.getItem(draftKey);
        if (!draft) return;

        var data = JSON.parse(draft);

        document.getElementById('aula_titulo').value = data.titulo || '';
        // document.getElementById('duracao').value = data.duracao || ''; (REMOVIDO)
        
        if (typeof tinymce !== 'undefined' && tinymce.get('raz_aula_content')) {
            tinymce.get('raz_aula_content').setContent(data.conteudo || '');
        } else {
            document.getElementById('raz_aula_content').value = data.conteudo || '';
        }
        
        document.getElementById('video_url').value = data.video_url || '';
        document.getElementById('video_provider').value = data.video_provider || '';
        
        // Rotina
        if (data.rotina) {
            document.getElementById('rotina_ativa').checked = data.rotina.ativa;
            document.getElementById('rotina_dias').value = data.rotina.dias || '';
            document.getElementById('rotina_mensagem').value = data.rotina.mensagem || '';
            toggleRoutineFields();
        }
        
        document.getElementById('video_provider').dispatchEvent(new Event('change'));

        document.getElementById('draft-alert').style.display = 'none';
        showToast('Rascunho restaurado!', 'success');
    }

    function discardDraft() {
        if(confirm('Tem certeza? Isso apagará o rascunho salvo no navegador.')) {
            localStorage.removeItem(draftKey);
            document.getElementById('draft-alert').style.display = 'none';
        }
    }

    // --- CLIENT SIDE PREVIEW REAL ---

    function generateClientSidePreview() {
        var data = getFormDataObj();
        var win = window.open('', '_blank');
        
        // Simular embed de vídeo
        var embed = getEmbedUrl(data.video_url, data.video_provider);
        var embedHtml = embed ? '<div class="raz-player-container has-video"><div class="raz-video-wrapper"><iframe src="' + embed + '" frameborder="0" allowfullscreen></iframe></div></div>' : '';
        
        // Simular materiais
        var materiaisHtml = '';
        if(data.materiais && data.materiais.length > 0) {
            materiaisHtml = '<div class="raz-tab-content" id="tab-materiais" style="display:none;"><div class="raz-materials"><h3 class="raz-materials-title">📎 Materiais Complementares</h3><div class="raz-materials-list">';
            data.materiais.forEach(function(m) {
                materiaisHtml += '<a href="' + m.url + '" class="raz-material-item" target="_blank">' + 
                                '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="22" height="22"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>' +
                                '<div><span class="raz-material-name">' + (m.display_name || m.nome) + '</span></div></a>';
            });
            materiaisHtml += '</div></div></div>';
        }

        // Construção do HTML completo do single-aula.php simulado com sidebar
        var html = `<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Preview: ${data.titulo}</title>
            <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
            <style>
            *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
            :root {
                --primary: #0891b2;
                --bg-controls: ${razAdmin.corControls};
                --border: #e2e8f0;
                --success: #10b981;
                --sidebar-width: 380px;
                --bg-main: #ffffff;
                --bg-sidebar: #ffffff;
                --bg-content: #f8fafc;
                --bg-card: #f8fafc;
                --text-primary: #1e293b;
                --text-secondary: #64748b;
            }
            body { font-family: 'Inter', -apple-system, sans-serif; background: var(--bg-main); color: var(--text-primary); transition: background 0.3s, color 0.3s; margin:0; }
            
            .raz-wrapper { display: flex; min-height: 100vh; }
            .raz-main { flex: 1; display: flex; flex-direction: column; overflow-x: hidden; background: var(--bg-main); }
            
            .raz-player-container { position: relative; width: 100%; background: #000; }
            .raz-player-container.has-video { aspect-ratio: 16/9; }
            .raz-video-wrapper { width: 100%; height: 100%; }
            .raz-video-wrapper iframe { width: 100%; height: 100%; }
            
            .raz-lesson-controls { display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; background: var(--bg-controls); flex-wrap: wrap; gap: 10px; }
            .raz-lesson-title { color: #fff; font-size: 13px; font-weight: 500; flex: 1; }
            .raz-nav-btn { display: inline-flex; align-items: center; gap: 6px; padding: 8px 14px; background: rgba(255,255,255,0.1); border: none; border-radius: 8px; color: #fff; font-size: 12px; cursor: pointer; text-decoration: none; }
            
            .raz-tabs { display: flex; gap: 0; border-bottom: 1px solid var(--border); background: var(--bg-main); }
            .raz-tab { padding: 12px 20px; cursor: pointer; font-size: 13px; font-weight: 500; color: var(--text-secondary); border-bottom: 2px solid transparent; display: flex; align-items: center; gap: 6px; }
            .raz-tab.active { color: var(--primary); border-bottom-color: var(--primary); }
            
            .raz-lesson-content { padding: 24px 16px; max-width: 800px; width: 100%; margin: 0 auto; line-height: 1.7; color: var(--text-primary); }
            .raz-lesson-content img { max-width: 100%; border-radius: 8px; height: auto; }
            
            .raz-sidebar { width: var(--sidebar-width); min-width: var(--sidebar-width); background: var(--bg-sidebar); border-left: 1px solid var(--border); display: flex; flex-direction: column; }
            .raz-sidebar-header { padding: 16px; border-bottom: 1px solid var(--border); }
            .raz-module-header { padding: 14px 16px; cursor: pointer; display: flex; justify-content: space-between; align-items: center; }
            .raz-module-lessons { display:block; background: var(--bg-content); }
            .raz-lesson-item { display: flex; align-items: center; gap: 10px; padding: 10px 16px; transition: background 0.15s; cursor: pointer; }
            .raz-lesson-item:hover { background: var(--bg-card); }
            .raz-lesson-item.active { background: rgba(8, 145, 178, 0.15); }
            
            .raz-materials { padding: 24px 16px; max-width: 800px; width: 100%; margin: 0 auto; }
            .raz-material-item { display: flex; align-items: center; gap: 12px; padding: 14px; background: var(--bg-card); border-radius: 8px; text-decoration: none; margin-bottom: 8px; color: var(--text-primary); }
            
            /* Responsivo */
            @media (max-width: 768px) {
                .raz-sidebar { display: none; } /* Em preview, esconde sidebar no mobile */
                .raz-lesson-content { padding: 20px 14px; }
            }
            </style>
        </head>
        <body>
            <div class="raz-wrapper">
                <main class="raz-main">
                    ${embedHtml}
                    
                    <div class="raz-lesson-controls">
                        <div class="raz-lesson-title">${data.titulo} (Modo Preview)</div>
                        <div style="display:flex;gap:8px;">
                            <a href="#" class="raz-nav-btn">Anterior</a>
                            <a href="#" class="raz-nav-btn" style="background:var(--primary);">Próxima</a>
                        </div>
                    </div>
                    
                    <div class="raz-tabs">
                        <div class="raz-tab active" onclick="switchTab('conteudo')">Conteúdo</div>
                        ${data.materiais && data.materiais.length > 0 ? '<div class="raz-tab" onclick="switchTab(\'materiais\')">Materiais (' + data.materiais.length + ')</div>' : ''}
                    </div>
                    
                    <div class="raz-tab-content active" id="tab-conteudo">
                        <div class="raz-lesson-content">${data.conteudo}</div>
                    </div>
                    ${materiaisHtml}
                </main>
                
                <aside class="raz-sidebar">
                    <div class="raz-sidebar-header">
                        <h3 style="margin:0;font-size:16px;">Estrutura do Curso (Simulado)</h3>
                    </div>
                    <div class="raz-sidebar-content">
                        <div class="raz-module">
                            <div class="raz-module-header">
                                <span style="font-weight:500;font-size:13px;">Módulo Atual</span>
                            </div>
                            <div class="raz-module-lessons">
                                <div class="raz-lesson-item">
                                    <div style="width:22px;height:22px;border:2px solid #e2e8f0;border-radius:6px;"></div>
                                    <span style="font-size:12px;">Aula Anterior (Exemplo)</span>
                                </div>
                                <div class="raz-lesson-item active">
                                    <div style="width:22px;height:22px;border:2px solid #0891b2;border-radius:6px;"></div>
                                    <span style="font-size:12px;">${data.titulo}</span>
                                </div>
                                <div class="raz-lesson-item">
                                    <div style="width:22px;height:22px;border:2px solid #e2e8f0;border-radius:6px;"></div>
                                    <span style="font-size:12px;">Próxima Aula (Exemplo)</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </aside>
            </div>
            
            <script>
            function switchTab(id) {
                document.querySelectorAll('.raz-tab-content').forEach(el => el.style.display = 'none');
                document.getElementById('tab-' + id).style.display = 'block';
                document.querySelectorAll('.raz-tab').forEach(el => el.classList.remove('active'));
                event.target.classList.add('active');
            }
            // Inicializar tabs
            document.getElementById('tab-conteudo').style.display = 'block';
            <\/script>
        </body>
        </html>`;

        win.document.write(html);
        win.document.close();
    }

    function getEmbedUrl(url, provider) {
        if(!url) return '';
        if(provider === 'youtube') {
            var match = url.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/);
            if(match && match[1]) return 'https://www.youtube.com/embed/' + match[1] + '?rel=0';
        }
        if(provider === 'vimeo') {
            var match = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
            if(match && match[1]) return 'https://player.vimeo.com/video/' + match[1];
        }
        if(provider === 'panda' || provider === 'bunny') return url;
        return '';
    }

    // --- FUNÇÕES EDITOR E UI ---

    function showToast(msg, type) {
        var t = document.getElementById('toast');
        t.textContent = msg;
        t.className = 'toast ' + (type || '') + ' show';
        setTimeout(function() { t.classList.remove('show'); }, 3000);
    }

    document.getElementById('video_provider').addEventListener('change', function() {
        var g = document.getElementById('video-url-group');
        var b = document.getElementById('btn-select-video');
        g.style.display = this.value ? 'block' : 'none';
        b.style.display = this.value === 'custom' ? 'flex' : 'none';
        if (!this.value) document.getElementById('video_url').value = '';
        triggerChange();
    });
    if(document.getElementById('video_provider').value) {
        document.getElementById('video-url-group').style.display = 'block';
    }

    function selectVideoFromLibrary() {
        var frame = wp.media({ title: 'Selecionar Vídeo', button: { text: 'Usar' }, multiple: false, library: { type: 'video' } });
        frame.on('select', function() {
            var att = frame.state().get('selection').first().toJSON();
            document.getElementById('video_url').value = att.url;
            triggerChange();
        });
        frame.open();
    }

    function addMaterial() {
        var frame = wp.media({ title: 'Selecionar Material', button: { text: 'Adicionar' }, multiple: true });
        frame.on('select', function() {
            var atts = frame.state().get('selection').toJSON();
            atts.forEach(function(att) {
                var dn = att.title || att.filename.replace(/\.[^/.]+$/, '');
                var h = '<div class="material-item" data-index="' + materialIndex + '">';
                h += '<div class="material-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></div>';
                h += '<div class="material-info">';
                h += '<input type="text" class="material-name-input track-change" name="materiais[' + materialIndex + '][display_name]" value="' + dn + '" placeholder="Nome">';
                h += '<span class="material-type">' + (att.subtype || att.type) + ' - ' + att.filename + '</span>';
                h += '<input type="hidden" name="materiais[' + materialIndex + '][id]" value="' + att.id + '">';
                h += '<input type="hidden" name="materiais[' + materialIndex + '][nome]" value="' + att.filename + '">';
                h += '<input type="hidden" name="materiais[' + materialIndex + '][url]" value="' + att.url + '">';
                h += '<input type="hidden" name="materiais[' + materialIndex + '][tipo]" value="' + (att.subtype || att.type) + '">';
                h += '</div><button type="button" class="btn btn-sm btn-danger" onclick="removeMaterial(this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button></div>';
                document.getElementById('materiais-list').insertAdjacentHTML('beforeend', h);
                materialIndex++;
            });
            triggerChange();
        });
        frame.open();
    }

    function removeMaterial(btn) { btn.closest('.material-item').remove(); triggerChange(); }

    function saveAula(silent) {
        if (isSaving) return;
        isSaving = true;
        
        // Sincroniza o conteúdo do TinyMCE para o textarea antes de salvar
        if (typeof tinyMCE !== 'undefined' && tinyMCE.get('raz_aula_content')) {
            tinyMCE.triggerSave();
        } else {
             // Fallback se o editor não carregou
             var editor = document.getElementById('raz_aula_content');
             if(editor) document.getElementById('conteudo').value = editor.value;
        }
        
        var status = document.getElementById('autosave-status');
        if(!silent) {
            status.className = 'autosave-indicator show saving';
            status.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" class="spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg><span>Salvando...</span>';
        }
        
        // Include rotina data in FormData for real save
        var data = getFormDataObj();
        var fd = new FormData(document.getElementById('form-aula'));
        fd.append('action', 'raz_save_aula');
        fd.append('nonce', razAdmin.nonce);
        fd.append('rotina', JSON.stringify(data.rotina));
        
        fetch(razAdmin.ajaxurl, { method: 'POST', body: fd })
            .then(function(r) { return r.json(); })
            .then(function(d) {
                isSaving = false;
                if (d.success) {
                    localStorage.removeItem(draftKey);
                    document.getElementById('draft-alert').style.display = 'none';
                    
                    status.className = 'autosave-indicator show saved';
                    status.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><polyline points="20 6 9 17 4 12"/></svg><span>Salvo</span>';
                    
                    if (d.data.aula_id) {
                        document.getElementById('aula_id').value = d.data.aula_id;
                        if(window.history.replaceState && !window.location.href.includes(d.data.aula_id)) {
                            var newUrl = new URL(window.location.href);
                            newUrl.pathname = '/gestao-cursos/aula-editar/' + d.data.aula_id + '/';
                            window.history.replaceState(null, '', newUrl);
                        }
                    }
                    if (!silent) showToast('Aula salva!', 'success');
                } else {
                    status.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><circle cx="12" cy="12" r="10"/></svg><span>Erro ao salvar</span>';
                    showToast(d.data.message || 'Erro', 'error');
                }
            })
            .catch(function() { 
                isSaving = false; 
                status.innerHTML = 'Erro de conexão';
            });
    }

    document.getElementById('form-aula').onsubmit = function(e) {
        e.preventDefault();
        saveAula(false);
    };

    document.addEventListener('keydown', function(e) {
        if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); saveAula(false); }
    });

    // Collapse toggle
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('editor-collapse-header')) {
            e.target.parentElement.classList.toggle('open');
        }
    });
</script>

</body>
</html>