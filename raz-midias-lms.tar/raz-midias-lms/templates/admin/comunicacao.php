<?php
/**
 * Admin: Comunicação - Notificações e E-mails
 * Design: Premium UX/UI
 * MODIFICADO: Agendamento de notificações + filtro por data de cadastro
 */
$cursos = get_posts(array('post_type' => 'curso', 'posts_per_page' => -1, 'orderby' => 'title'));

// Configurações de lembrete
$config_lembrete = get_option('raz_lms_email_lembrete', array(
    'ativo' => false,
    'dias' => 7,
    'assunto' => 'Sentimos sua falta, {nome}!',
    'mensagem' => "Olá {nome},\n\nPercebemos que você não acessa o curso \"{curso}\" há {dias} dias.\n\nVolte agora e continue sua jornada de aprendizado!\n\n{link}\n\nAbraços,\n{site_nome}"
));

$mensagem_sucesso = '';
if (isset($_POST['save_lembrete']) && wp_verify_nonce($_POST['lembrete_nonce'], 'raz_save_lembrete')) {
    $config_lembrete = array(
        'ativo' => isset($_POST['lembrete_ativo']),
        'dias' => intval($_POST['lembrete_dias']),
        'assunto' => sanitize_text_field($_POST['lembrete_assunto']),
        'mensagem' => wp_kses_post($_POST['lembrete_mensagem'])
    );
    update_option('raz_lms_email_lembrete', $config_lembrete);
    $mensagem_sucesso = '
    <div class="raz-alert raz-alert-success">
        <div class="raz-alert-icon"><svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg></div>
        <div class="raz-alert-content">Configurações de lembrete salvas com sucesso!</div>
    </div>';
}
?>

<style>
    :root {
        --raz-primary: #0891b2;
        --raz-primary-hover: #0e7490;
        --raz-bg: #f8fafc;
        --raz-surface: #ffffff;
        --raz-border: #e2e8f0;
        --raz-text: #1e293b;
        --raz-text-muted: #64748b;
        --raz-text-light: #94a3b8;
        --raz-success-bg: #ecfdf5;
        --raz-success-text: #059669;
        --raz-danger-bg: #fef2f2;
        --raz-danger-text: #dc2626;
        --raz-warning-bg: #fef3c7;
        --raz-warning-text: #92400e;
        --raz-radius: 8px;
        --raz-radius-lg: 12px;
        --raz-shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        --raz-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        --transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .raz-admin-container {
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        color: var(--raz-text);
        max-width: 1000px;
        margin: 20px auto 60px;
    }

    /* Headings */
    .raz-page-header {
        margin-bottom: 24px;
        padding-bottom: 20px;
        border-bottom: 1px solid var(--raz-border);
    }
    .raz-page-title {
        font-size: 24px;
        font-weight: 700;
        color: var(--raz-text);
        margin: 0 0 8px 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .raz-page-title svg { color: var(--raz-primary); }
    .raz-page-desc { font-size: 14px; color: var(--raz-text-muted); margin: 0; }

    /* Tabs */
    .raz-nav-tabs {
        display: flex;
        gap: 4px;
        margin-bottom: 24px;
        border-bottom: 2px solid var(--raz-border);
    }
    .raz-nav-link {
        padding: 12px 20px;
        text-decoration: none;
        color: var(--raz-text-muted);
        font-weight: 600;
        font-size: 14px;
        border-bottom: 2px solid transparent;
        margin-bottom: -2px;
        transition: var(--transition);
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 8px;
        background: none;
        border: none;
        border-radius: 6px 6px 0 0;
    }
    .raz-nav-link:hover { color: var(--raz-primary); background: #f1f5f9; }
    .raz-nav-link.active { color: var(--raz-primary); border-bottom-color: var(--raz-primary); background: transparent; }
    .raz-nav-link svg { width: 18px; height: 18px; }

    .tab-content { display: none; animation: fadeIn 0.3s ease; }
    .tab-content.active { display: block; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }

    /* Cards */
    .raz-card {
        background: var(--raz-surface);
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius-lg);
        padding: 24px;
        box-shadow: var(--raz-shadow);
        margin-bottom: 24px;
    }
    .raz-section-title {
        font-size: 16px;
        font-weight: 700;
        color: var(--raz-text);
        margin: 0 0 16px 0;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    /* Form Elements */
    .raz-form-group { margin-bottom: 20px; }
    .raz-label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 8px; color: var(--raz-text); }
    
    .raz-input-wrapper { position: relative; }
    .raz-input-icon {
        position: absolute; left: 12px; top: 13px;
        color: var(--raz-text-light); pointer-events: none;
    }
    
    .raz-input, .raz-textarea, .raz-select {
        width: 100%;
        padding: 10px 12px 10px 36px;
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius);
        font-size: 14px;
        background: #fff;
        transition: var(--transition);
        font-family: inherit;
        color: var(--raz-text);
    }
    .raz-textarea { min-height: 100px; resize: vertical; padding-top: 12px; }
    .raz-select { height: 42px; }
    
    .raz-input:focus, .raz-textarea:focus, .raz-select:focus {
        border-color: var(--raz-primary);
        outline: none;
        box-shadow: 0 0 0 3px rgba(8, 145, 178, 0.15);
    }

    /* Schedule Fields */
    .raz-schedule-options {
        display: flex;
        gap: 16px;
        margin-bottom: 16px;
    }
    
    .raz-radio-option {
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        padding: 8px 12px;
        border-radius: var(--raz-radius);
        transition: var(--transition);
    }
    
    .raz-radio-option:hover {
        background: #f1f5f9;
    }
    
    .raz-radio-option input[type="radio"] {
        cursor: pointer;
        width: 16px;
        height: 16px;
    }
    
    .raz-radio-option span {
        font-size: 14px;
        font-weight: 500;
        color: var(--raz-text);
    }
    
    .raz-schedule-fields {
        display: none;
        gap: 12px;
        padding: 16px;
        background: #f8fafc;
        border-radius: var(--raz-radius);
        border: 1px solid var(--raz-border);
    }
    
    .raz-schedule-fields.active {
        display: flex;
    }
    
    .raz-schedule-field {
        flex: 1;
    }
    
    .raz-schedule-field label {
        display: block;
        font-size: 12px;
        font-weight: 600;
        color: var(--raz-text-muted);
        margin-bottom: 6px;
    }
    
    .raz-schedule-field input[type="date"],
    .raz-schedule-field input[type="time"] {
        width: 100%;
        padding: 8px 12px;
        border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius);
        font-size: 14px;
        font-family: inherit;
    }

    /* Buttons */
    .raz-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 10px 20px;
        font-size: 14px;
        font-weight: 600;
        border-radius: var(--raz-radius);
        cursor: pointer;
        border: none;
        transition: var(--transition);
        gap: 8px;
        height: 42px;
    }
    .raz-btn-primary { background: var(--raz-primary); color: white; box-shadow: 0 1px 2px rgba(0,0,0,0.1); }
    .raz-btn-primary:hover { background: var(--raz-primary-hover); transform: translateY(-1px); }
    
    .raz-btn-danger { background: #fff; color: var(--raz-danger-text); border: 1px solid #fee2e2; font-size: 12px; padding: 6px 12px; height: 32px; }
    .raz-btn-danger:hover { background: #fee2e2; }

    /* Switch */
    .raz-switch { position: relative; display: inline-flex; align-items: center; gap: 10px; cursor: pointer; }
    .raz-switch input { opacity: 0; width: 0; height: 0; position: absolute; }
    .raz-slider { position: relative; width: 44px; height: 24px; background-color: #cbd5e1; border-radius: 34px; transition: .3s; }
    .raz-slider:before { position: absolute; content: ""; height: 18px; width: 18px; left: 3px; bottom: 3px; background-color: white; border-radius: 50%; transition: .3s; box-shadow: 0 2px 4px rgba(0,0,0,0.2); }
    .raz-switch input:checked + .raz-slider { background-color: var(--raz-primary); }
    .raz-switch input:checked + .raz-slider:before { transform: translateX(20px); }
    .raz-switch-label { font-size: 14px; font-weight: 600; color: var(--raz-text); }

    /* Notification List */
    .notif-list { display: flex; flex-direction: column; gap: 12px; }
    .notif-item {
        display: flex; justify-content: space-between; align-items: flex-start;
        padding: 16px; background: #fff; border: 1px solid var(--raz-border);
        border-radius: var(--raz-radius); transition: var(--transition);
    }
    .notif-item:hover { box-shadow: var(--raz-shadow-sm); border-color: #cbd5e1; }
    .notif-item-info { flex: 1; }
    .notif-item-info h4 { margin: 0 0 6px; font-size: 15px; font-weight: 600; color: var(--raz-text); }
    .notif-item-info p { margin: 0; font-size: 13px; color: var(--raz-text-muted); line-height: 1.4; }
    .notif-item-meta { font-size: 12px; color: var(--raz-text-light); margin-top: 8px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    
    /* Status Badges */
    .raz-status-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 4px 10px;
        border-radius: 999px;
        font-size: 11px;
        font-weight: 600;
    }
    
    .raz-status-badge.scheduled {
        background: var(--raz-warning-bg);
        color: var(--raz-warning-text);
    }
    
    .raz-status-badge.sent {
        background: #d1fae5;
        color: #065f46;
    }
    
    /* Recipient Badge */
    .raz-recipient-badge {
        display: inline-flex; align-items: center; gap: 8px;
        padding: 8px 16px; background: #f0f9ff; color: #0369a1;
        border-radius: 999px; font-size: 13px; font-weight: 500;
        border: 1px solid #bae6fd;
    }
    .raz-recipient-badge strong { font-weight: 700; }

    /* Alerts */
    .raz-alert { padding: 16px; border-radius: var(--raz-radius); margin-bottom: 24px; display: flex; align-items: center; gap: 12px; border-left: 4px solid transparent; animation: slideIn 0.3s ease-out; }
    .raz-alert-success { background: var(--raz-success-bg); border-left-color: var(--raz-success-text); color: #064e3b; }
    
    .raz-helper-text { font-size: 13px; color: var(--raz-text-muted); margin-top: 4px; }
</style>

<div class="raz-admin-container">
    
    <div class="raz-page-header">
        <h2 class="raz-page-title">
            <svg width="28" height="28" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path></svg>
            Central de Comunicação
        </h2>
        <p class="raz-page-desc">Gerencie notificações no painel, envie e-mails manuais e configure lembretes automáticos.</p>
    </div>
    
    <?php echo $mensagem_sucesso; ?>

    <div class="raz-nav-tabs">
        <button class="raz-nav-link active" onclick="showTab('notificacoes')">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
            Notificações (Sininho)
        </button>
        <button class="raz-nav-link" onclick="showTab('email-manual')">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
            Enviar E-mail
        </button>
        <button class="raz-nav-link" onclick="showTab('lembretes')">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            Lembretes Automáticos
        </button>
    </div>

    <div class="tab-content active" id="tab-notificacoes">
        <div class="raz-card">
            <div class="raz-section-title">
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                Criar Nova Notificação
            </div>
            
            <div class="raz-form-group">
                <label class="raz-label">Título *</label>
                <div class="raz-input-wrapper">
                    <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z"></path></svg>
                    <input type="text" id="notif-title" class="raz-input" placeholder="Ex: Novo módulo disponível!">
                </div>
            </div>
            
            <div class="raz-form-group">
                <label class="raz-label">Mensagem *</label>
                <div class="raz-input-wrapper">
                    <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h7"></path></svg>
                    <textarea id="notif-message" class="raz-textarea" rows="3" placeholder="Escreva a mensagem que aparecerá no sininho..."></textarea>
                </div>
            </div>
            
            <div class="raz-form-group">
                <label class="raz-label">Destinatários</label>
                <div class="raz-input-wrapper">
                    <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                    <select id="notif-curso" class="raz-select">
                        <option value="0">Todos os alunos ativos</option>
                        <?php foreach ($cursos as $c) : ?>
                        <option value="<?php echo $c->ID; ?>">Apenas alunos de: <?php echo esc_html($c->post_title); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <div class="raz-form-group">
                <label class="raz-label">Agendamento</label>
                <div class="raz-schedule-options">
                    <label class="raz-radio-option">
                        <input type="radio" name="schedule-type" value="now" checked onchange="toggleScheduleFields()">
                        <span>Enviar Agora</span>
                    </label>
                    <label class="raz-radio-option">
                        <input type="radio" name="schedule-type" value="scheduled" onchange="toggleScheduleFields()">
                        <span>Agendar Para</span>
                    </label>
                </div>
                
                <div class="raz-schedule-fields" id="schedule-fields">
                    <div class="raz-schedule-field">
                        <label>Data</label>
                        <input type="date" id="schedule-date">
                    </div>
                    <div class="raz-schedule-field">
                        <label>Hora</label>
                        <input type="time" id="schedule-time">
                    </div>
                </div>
            </div>
            
            <button class="raz-btn raz-btn-primary" id="send-notif-btn" onclick="sendNotification()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/></svg>
                Enviar Notificação
            </button>
        </div>
        
        <div class="raz-card">
            <h3 class="raz-section-title">Histórico de Notificações</h3>
            <div id="notif-list" class="notif-list">
                <div style="text-align:center; padding: 40px; color: var(--raz-text-muted);">
                    <svg class="raz-spinner" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="animation: spin 1s linear infinite; margin: 0 auto 10px;"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
                    Carregando histórico...
                </div>
            </div>
        </div>
    </div>

    <div class="tab-content" id="tab-email-manual">
        <div class="raz-card">
            <div class="raz-section-title">
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                Disparar E-mail
            </div>
            
            <div class="raz-form-group">
                <label class="raz-label">Assunto *</label>
                <div class="raz-input-wrapper">
                    <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 20l4-16m2 16l4-16M6 9h14M4 15h14"></path></svg>
                    <input type="text" id="email_assunto" class="raz-input" placeholder="Assunto do e-mail">
                </div>
            </div>
            
            <div class="raz-form-group">
                <label class="raz-label">Mensagem *</label>
                <div class="raz-input-wrapper">
                    <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                    <textarea id="email_mensagem" class="raz-textarea" rows="6" placeholder="Escreva a mensagem do e-mail..."></textarea>
                </div>
                <div style="margin-top:8px; display:flex; gap:8px;">
                    <span class="raz-recipient-badge" style="padding:4px 8px; font-size:11px; background:#f1f5f9; color:#64748b; border:none;">{nome}</span>
                    <span class="raz-recipient-badge" style="padding:4px 8px; font-size:11px; background:#f1f5f9; color:#64748b; border:none;">{email}</span>
                    <span class="raz-recipient-badge" style="padding:4px 8px; font-size:11px; background:#f1f5f9; color:#64748b; border:none;">{site_nome}</span>
                </div>
            </div>
            
            <div class="raz-form-group">
                <label class="raz-label">Quem deve receber?</label>
                <div class="raz-input-wrapper">
                    <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                    <select id="email_destinatarios" class="raz-select" onchange="updateRecipientCount()">
                        <option value="todos">Todos os alunos da plataforma</option>
                        <option value="curso">Alunos de um curso específico</option>
                        <option value="manual">Lista manual de e-mails</option>
                    </select>
                </div>
            </div>
            
            <div class="raz-form-group" id="email_curso_group" style="display:none;">
                <label class="raz-label">Selecione o Curso</label>
                <div class="raz-input-wrapper">
                    <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                    <select id="email_curso" class="raz-select" onchange="updateRecipientCount()">
                        <?php foreach ($cursos as $c) : ?>
                        <option value="<?php echo $c->ID; ?>"><?php echo esc_html($c->post_title); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <div class="raz-form-group" id="email_manual_group" style="display:none;">
                <label class="raz-label">Lista de E-mails (um por linha)</label>
                <textarea id="email_manuais" class="raz-textarea" rows="4" placeholder="email1@exemplo.com&#10;email2@exemplo.com"></textarea>
            </div>
            
            <div class="raz-recipient-badge" id="recipient-count" style="margin-top:10px;">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                <span>Alcance Estimado: <strong id="recipient-num">-</strong></span>
            </div>
            
            <div style="margin-top:24px; text-align:right;">
                <button class="raz-btn raz-btn-primary" onclick="sendManualEmail()">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/></svg>
                    Disparar E-mail
                </button>
            </div>
        </div>
    </div>

    <div class="tab-content" id="tab-lembretes">
        <form method="post" class="raz-card">
            <?php wp_nonce_field('raz_save_lembrete', 'lembrete_nonce'); ?>
            
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; border-bottom:1px solid #f1f5f9; padding-bottom:16px;">
                <div class="raz-section-title" style="margin:0;">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    Lembrete de Inatividade
                </div>
                <label class="raz-switch">
                    <input type="checkbox" name="lembrete_ativo" <?php checked($config_lembrete['ativo']); ?>>
                    <span class="raz-slider"></span>
                    <span class="raz-switch-label">Ativo</span>
                </label>
            </div>
            
            <p class="raz-helper-text" style="margin-bottom:24px;">
                Envie e-mails automáticos para alunos que não acessam a plataforma há alguns dias para aumentar o engajamento.
            </p>
            
            <div class="raz-form-group">
                <label class="raz-label">Enviar após quantos dias sem acesso?</label>
                <div class="raz-input-wrapper">
                    <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                    <input type="number" name="lembrete_dias" class="raz-input" value="<?php echo esc_attr($config_lembrete['dias']); ?>" min="1" max="90" style="max-width:150px;">
                </div>
            </div>
            
            <div class="raz-form-group">
                <label class="raz-label">Assunto do E-mail</label>
                <div class="raz-input-wrapper">
                    <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 20l4-16m2 16l4-16M6 9h14M4 15h14"></path></svg>
                    <input type="text" name="lembrete_assunto" class="raz-input" value="<?php echo esc_attr($config_lembrete['assunto']); ?>">
                </div>
            </div>
            
            <div class="raz-form-group">
                <label class="raz-label">Mensagem</label>
                <div class="raz-input-wrapper">
                    <svg class="raz-input-icon" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                    <textarea name="lembrete_mensagem" class="raz-textarea" rows="6"><?php echo esc_textarea($config_lembrete['mensagem']); ?></textarea>
                </div>
                <small class="raz-helper-text">Variáveis: {nome}, {email}, {curso}, {dias}, {link}, {site_nome}</small>
            </div>
            
            <div style="text-align:right;">
                <button type="submit" name="save_lembrete" class="raz-btn raz-btn-primary">
                    <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                    Salvar Configurações
                </button>
            </div>
        </form>
    </div>

</div>

<script>
var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
var nonce = '<?php echo wp_create_nonce('raz_admin_nonce'); ?>';

function showTab(tab)
{
    document.querySelectorAll('.raz-nav-link').forEach(function(b) {
        b.classList.remove('active');
    });
    
    document.querySelectorAll('.tab-content').forEach(function(c) {
        c.classList.remove('active');
    });
    
    var buttons = document.querySelectorAll('.raz-nav-link');
    if (tab === 'notificacoes') buttons[0].classList.add('active');
    if (tab === 'email-manual') buttons[1].classList.add('active');
    if (tab === 'lembretes') buttons[2].classList.add('active');
    
    document.getElementById('tab-' + tab).classList.add('active');
}

function toggleScheduleFields()
{
    var scheduleType = document.querySelector('input[name="schedule-type"]:checked');
    
    if (!scheduleType) {
        return;
    }
    
    var scheduleFields = document.getElementById('schedule-fields');
    
    if (scheduleType.value === 'scheduled') {
        scheduleFields.classList.add('active');
    } else {
        scheduleFields.classList.remove('active');
    }
}

function loadNotifications()
{
    fetch(ajaxurl + '?action=raz_list_notifications&nonce=' + nonce)
        .then(function(r) {
            return r.json();
        })
        .then(function(d) {
            if (d.success && d.data.length > 0) {
                var html = '';
                d.data.forEach(function(n) {
                    var statusBadge = '';
                    
                    if (n.status === 'Agendada') {
                        statusBadge = '<span class="raz-status-badge scheduled">📅 Agendada para ' + n.scheduled_for + '</span>';
                    } else {
                        statusBadge = '<span class="raz-status-badge sent">✓ Enviada</span>';
                    }
                    
                    html += '<div class="notif-item">';
                    html += '<div class="notif-item-info">';
                    html += '<h4>' + n.title + '</h4>';
                    html += '<p>' + n.message.substring(0, 100) + (n.message.length > 100 ? '...' : '') + '</p>';
                    html += '<div class="notif-item-meta">';
                    html += '<svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg> ' + n.date;
                    html += ' • <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg> ' + n.curso;
                    html += ' • ' + statusBadge;
                    html += '</div>';
                    html += '</div>';
                    html += '<div class="notif-item-actions">';
                    html += '<button class="raz-btn raz-btn-danger" onclick="deleteNotification(' + n.id + ')">Excluir</button>';
                    html += '</div></div>';
                });
                
                document.getElementById('notif-list').innerHTML = html;
            } else {
                document.getElementById('notif-list').innerHTML = '<div style="text-align:center;color:var(--raz-text-muted);padding:40px;"><svg width="48" height="48" fill="none" stroke="#cbd5e1" viewBox="0 0 24 24" style="margin-bottom:10px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"/></svg><p>Nenhuma notificação enviada</p></div>';
            }
        })
        .catch(function(err) {
            console.error('Erro ao carregar notificações:', err);
        });
}

function sendNotification()
{
    var titleEl = document.getElementById('notif-title');
    var messageEl = document.getElementById('notif-message');
    var cursoEl = document.getElementById('notif-curso');
    var scheduleTypeRadio = document.querySelector('input[name="schedule-type"]:checked');
    var scheduleDateEl = document.getElementById('schedule-date');
    var scheduleTimeEl = document.getElementById('schedule-time');
    var btnEl = document.getElementById('send-notif-btn');
    
    if (!titleEl || !messageEl || !cursoEl || !btnEl) {
        alert('Erro: Elementos do formulário não encontrados');
        return;
    }
    
    var title = titleEl.value.trim();
    var message = messageEl.value.trim();
    var curso_id = cursoEl.value;
    var schedule_type = scheduleTypeRadio ? scheduleTypeRadio.value : 'now';
    var schedule_date = scheduleDateEl ? scheduleDateEl.value : '';
    var schedule_time = scheduleTimeEl ? scheduleTimeEl.value : '';
    
    if (!title || !message) {
        alert('Preencha título e mensagem');
        return;
    }
    
    if (schedule_type === 'scheduled' && (!schedule_date || !schedule_time)) {
        alert('Para agendar, preencha data e hora');
        return;
    }
    
    var originalText = btnEl.innerHTML;
    btnEl.disabled = true;
    btnEl.innerHTML = 'Enviando...';
    
    var bodyData = 'action=raz_create_notification&nonce=' + nonce + 
                   '&title=' + encodeURIComponent(title) + 
                   '&message=' + encodeURIComponent(message) + 
                   '&curso_id=' + curso_id + 
                   '&schedule_type=' + schedule_type;
    
    if (schedule_type === 'scheduled') {
        bodyData += '&schedule_date=' + encodeURIComponent(schedule_date) + 
                    '&schedule_time=' + encodeURIComponent(schedule_time);
    }
    
    fetch(ajaxurl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: bodyData
    })
    .then(function(r) {
        return r.json();
    })
    .then(function(d) {
        btnEl.disabled = false;
        btnEl.innerHTML = originalText;
        
        if (d.success) {
            alert(schedule_type === 'scheduled' ? 'Notificação agendada com sucesso!' : 'Notificação enviada!');
            
            titleEl.value = '';
            messageEl.value = '';
            
            if (scheduleDateEl) scheduleDateEl.value = '';
            if (scheduleTimeEl) scheduleTimeEl.value = '';
            
            var nowRadio = document.querySelector('input[name="schedule-type"][value="now"]');
            if (nowRadio) {
                nowRadio.checked = true;
                toggleScheduleFields();
            }
            
            loadNotifications();
        } else {
            alert('Erro: ' + (d.data && d.data.message ? d.data.message : 'Falha ao enviar'));
        }
    })
    .catch(function(err) {
        btnEl.disabled = false;
        btnEl.innerHTML = originalText;
        console.error('Erro ao enviar:', err);
        alert('Erro ao enviar notificação. Verifique o console.');
    });
}

function deleteNotification(id)
{
    if (!confirm('Excluir esta notificação?')) {
        return;
    }
    
    fetch(ajaxurl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'action=raz_delete_notification&nonce=' + nonce + '&notification_id=' + id
    })
    .then(function(r) {
        return r.json();
    })
    .then(function(d) {
        if (d.success) {
            loadNotifications();
        }
    })
    .catch(function(err) {
        console.error('Erro:', err);
        alert('Erro ao excluir notificação');
    });
}

document.getElementById('email_destinatarios').addEventListener('change', function() {
    document.getElementById('email_curso_group').style.display = this.value === 'curso' ? 'block' : 'none';
    document.getElementById('email_manual_group').style.display = this.value === 'manual' ? 'block' : 'none';
});

function updateRecipientCount()
{
    var tipo = document.getElementById('email_destinatarios').value;
    var curso_id = document.getElementById('email_curso').value;
    
    if (tipo === 'manual') {
        document.getElementById('recipient-num').textContent = 'Lista manual';
        return;
    }
    
    var url = ajaxurl + '?action=raz_count_recipients&nonce=' + nonce + '&tipo=' + tipo;
    if (tipo === 'curso') {
        url += '&curso_id=' + curso_id;
    }
    
    document.getElementById('recipient-num').textContent = 'Calculando...';
    
    fetch(url)
        .then(function(r) {
            return r.json();
        })
        .then(function(d) {
            if (d.success) {
                document.getElementById('recipient-num').textContent = d.data.count + ' aluno(s)';
            }
        });
}

function sendManualEmail()
{
    var assunto = document.getElementById('email_assunto').value;
    var mensagem = document.getElementById('email_mensagem').value;
    var destinatarios = document.getElementById('email_destinatarios').value;
    var curso_id = document.getElementById('email_curso').value;
    var emails_manuais = document.getElementById('email_manuais').value;
    
    if (!assunto || !mensagem) {
        alert('Preencha assunto e mensagem');
        return;
    }
    
    if (!confirm('Confirma o envio dos e-mails?')) {
        return;
    }
    
    var btn = event.target;
    var originalText = btn.innerHTML;
    btn.disabled = true;
    btn.textContent = 'Enviando...';
    
    var body = 'action=raz_send_manual_email&nonce=' + nonce;
    body += '&assunto=' + encodeURIComponent(assunto);
    body += '&mensagem=' + encodeURIComponent(mensagem);
    body += '&destinatarios=' + destinatarios;
    body += '&curso_id=' + curso_id;
    body += '&emails_manuais=' + encodeURIComponent(emails_manuais);
    
    fetch(ajaxurl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: body
    })
    .then(function(r) {
        return r.json();
    })
    .then(function(d) {
        btn.disabled = false;
        btn.innerHTML = originalText;
        
        if (d.success) {
            alert('E-mails enviados!\n\nEnviados: ' + d.data.enviados + '\nErros: ' + d.data.erros);
        } else {
            alert('Erro: ' + (d.data ? d.data.message : 'Desconhecido'));
        }
    });
}

// Carregar dados iniciais
loadNotifications();
updateRecipientCount();
</script>