<?php
/**
 * Template: Acesso Bloqueado (Versão Corrigida - Exibição de Motivo)
 * @package RazMidiasLMS
 */

get_header();

$user_id = get_current_user_id();
$curso = null;

// 1. Identifica o curso atual com base no conteúdo acessado
if (is_singular('aula')) {
    $curso = raz_lms_get_curso_from_aula(get_the_ID());
} elseif (is_singular('modulo')) {
    $curso_id = get_post_meta(get_the_ID(), '_raz_modulo_curso', true);
    $curso = $curso_id ? get_post($curso_id) : null;
}

// 2. Recupera os dados de acesso diretamente do banco
$acesso = $curso ? get_user_meta($user_id, '_raz_curso_acesso_' . $curso->ID, true) : null;

// Inicializa variáveis de estado
$is_blocked = false;
$block_reason = '';
$is_expired = false;

if ($acesso && is_array($acesso)) {
    // --- VERIFICAÇÃO DE BLOQUEIO MANUAL ---
    if (isset($acesso['status_bloqueio']) && $acesso['status_bloqueio'] === 'ativo') {
        $bloqueio_valido = true;

        // Se houver uma data de desbloqueio, verifica se ainda é válida
        if (!empty($acesso['data_desbloqueio'])) {
            $data_fim = strtotime($acesso['data_desbloqueio'] . ' 23:59:59');
            if (time() > $data_fim) {
                $bloqueio_valido = false; // Data já passou, bloqueio expirou
            }
        }

        if ($bloqueio_valido) {
            $is_blocked = true;
            $block_reason = isset($acesso['motivo_bloqueio']) ? $acesso['motivo_bloqueio'] : 'Motivo não especificado.';
        }
    }

    // --- VERIFICAÇÃO DE EXPIRAÇÃO (Apenas se não estiver bloqueado) ---
    if (!$is_blocked && isset($acesso['expiracao']) && !empty($acesso['expiracao'])) {
        // Verifica se não é vitalício
        if (empty($acesso['vitalicio'])) {
            if (strtotime($acesso['expiracao']) < time()) {
                $is_expired = true;
            }
        }
    }
}

// Mensagens padrão do sistema
$mensagem_negado = get_option('raz_lms_acesso_negado_msg', 'Você não tem acesso a este conteúdo.');
$mensagem_expirado = get_option('raz_lms_acesso_expirado_msg', 'Seu acesso a este curso expirou.');

?>

<div class="raz-access-blocked">
    <div class="raz-access-blocked-icon">
        <?php if ($is_blocked) : ?>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#dc2626" stroke-width="2" width="64" height="64"><path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
        <?php elseif ($is_expired) : ?>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="64" height="64"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <?php else : ?>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="64" height="64"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
        <?php endif; ?>
    </div>
    
    <h1 class="raz-access-blocked-title" style="<?php echo $is_blocked ? 'color:#dc2626;' : ''; ?>">
        <?php 
        if ($is_blocked) {
            echo 'Acesso Suspenso';
        } elseif ($is_expired) {
            echo 'Acesso Expirado';
        } else {
            echo 'Acesso Restrito';
        }
        ?>
    </h1>
    
    <div class="raz-access-blocked-message">
        <?php if ($is_blocked) : ?>
            <p>O seu acesso a este conteúdo está temporariamente suspenso.</p>
            
            <?php if (!empty($block_reason)) : ?>
                <div style="margin-top:1.5rem; background:#fef2f2; border:1px solid #fecaca; border-radius:8px; padding:1.25rem; text-align:left; max-width:450px; margin-left:auto; margin-right:auto; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">
                    <strong style="display:flex; align-items:center; gap:6px; color:#991b1b; font-size:0.875rem; margin-bottom:0.5rem;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        Motivo do bloqueio:
                    </strong>
                    <span style="color:#7f1d1d; font-size:1rem; line-height:1.5; display:block;">
                        <?php echo nl2br(esc_html($block_reason)); ?>
                    </span>
                </div>
            <?php endif; ?>

        <?php elseif ($is_expired) : ?>
            <?php echo esc_html($mensagem_expirado); ?>
        <?php else : ?>
            <?php echo esc_html($mensagem_negado); ?>
        <?php endif; ?>
    </div>
    
    <?php if ($is_expired && $curso && !$is_blocked) : ?>
    <p class="raz-access-blocked-message" style="font-size:.875rem; opacity: 0.8;">
        Seu acesso ao curso <strong><?php echo esc_html($curso->post_title); ?></strong> expirou em <?php echo date_i18n(get_option('date_format'), strtotime($acesso['expiracao'])); ?>.
    </p>
    <?php endif; ?>
    
    <div style="display:flex;gap:1rem;flex-wrap:wrap;justify-content:center; margin-top: 2.5rem;">
        <?php if ($curso) : ?>
        <a href="<?php echo get_permalink($curso->ID); ?>" class="raz-access-blocked-btn" style="background:var(--bg-card); color:var(--text-primary); border:1px solid var(--border);">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
            Voltar ao Curso
        </a>
        <?php endif; ?>
        
        <a href="<?php echo home_url('/meus-cursos/'); ?>" class="raz-access-blocked-btn">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            Meus Cursos
        </a>
    </div>
</div>

<?php get_footer(); ?>