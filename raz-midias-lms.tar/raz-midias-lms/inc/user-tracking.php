<?php
/**
 * Sistema de Rastreamento de Usuários
 * @package RazMidiasLMS
 */

defined('ABSPATH') || exit;

/**
 * Registrar acesso do usuário
 */
function raz_lms_log_user_access($user_id, $aula_id = 0, $curso_id = 0) {
    if (!$user_id) return;
    
    $timezone = wp_timezone();
    $now = new DateTime('now', $timezone);
    $timestamp = $now->getTimestamp();
    
    $ip = raz_lms_get_user_ip();
    $browser = raz_lms_get_browser_info();
    
    // Buscar módulo da aula
    $modulo_id = 0;
    if ($aula_id) {
        $modulo = raz_lms_get_modulo_from_aula($aula_id);
        if ($modulo) $modulo_id = $modulo->ID;
    }
    
    // Atualizar último acesso
    update_user_meta($user_id, '_raz_last_access_timestamp', $timestamp);
    update_user_meta($user_id, '_raz_last_access_ip', $ip);
    update_user_meta($user_id, '_raz_last_browser', $browser['browser']);
    update_user_meta($user_id, '_raz_last_os', $browser['os']);
    update_user_meta($user_id, '_raz_last_access_aula', $aula_id);
    update_user_meta($user_id, '_raz_last_access_curso', $curso_id);
    update_user_meta($user_id, '_raz_last_access_modulo', $modulo_id);
    
    // Adicionar ao histórico
    $history = get_user_meta($user_id, '_raz_access_history', true);
    if (!is_array($history)) $history = array();
    
    array_unshift($history, array(
        'timestamp' => $timestamp,
        'aula_id' => $aula_id,
        'curso_id' => $curso_id,
        'modulo_id' => $modulo_id,
        'ip' => $ip,
        'browser' => $browser['browser'],
        'os' => $browser['os']
    ));
    
    // Limitar a 500 entradas
    $history = array_slice($history, 0, 500);
    update_user_meta($user_id, '_raz_access_history', $history);
}

/**
 * Obter IP do usuário
 */
function raz_lms_get_user_ip() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return sanitize_text_field($_SERVER['HTTP_CLIENT_IP']);
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return sanitize_text_field($_SERVER['HTTP_X_FORWARDED_FOR']);
    }
    return sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '');
}

/**
 * Obter info do navegador
 */
function raz_lms_get_browser_info() {
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    
    $browser = 'Desconhecido';
    $os = 'Desconhecido';
    
    if (strpos($ua, 'Firefox') !== false) $browser = 'Firefox';
    elseif (strpos($ua, 'Chrome') !== false && strpos($ua, 'Edg') === false) $browser = 'Chrome';
    elseif (strpos($ua, 'Safari') !== false && strpos($ua, 'Chrome') === false) $browser = 'Safari';
    elseif (strpos($ua, 'Edg') !== false) $browser = 'Edge';
    elseif (strpos($ua, 'Opera') !== false || strpos($ua, 'OPR') !== false) $browser = 'Opera';
    
    if (strpos($ua, 'Windows') !== false) $os = 'Windows';
    elseif (strpos($ua, 'Mac') !== false) $os = 'macOS';
    elseif (strpos($ua, 'Linux') !== false) $os = 'Linux';
    elseif (strpos($ua, 'Android') !== false) $os = 'Android';
    elseif (strpos($ua, 'iPhone') !== false || strpos($ua, 'iPad') !== false) $os = 'iOS';
    
    return array('browser' => $browser, 'os' => $os);
}

/**
 * Sessão única
 */
function raz_lms_single_session($user_login, $user) {
    $session_token = wp_get_session_token();
    $sessions = WP_Session_Tokens::get_instance($user->ID);
    $all_sessions = $sessions->get_all();
    foreach ($all_sessions as $token => $data) {
        if ($token !== $session_token) {
            $sessions->destroy($token);
        }
    }
}
add_action('wp_login', 'raz_lms_single_session', 10, 2);

/**
 * AJAX: Obter dados de auditoria do usuário (versão completa com paginação)
 */
function raz_lms_ajax_get_user_audit() {
    check_ajax_referer('raz_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Sem permissão'));
    }
    
    $user_id = intval($_GET['user_id']);
    $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
    $per_page = 20;
    
    $user = get_userdata($user_id);
    if (!$user) {
        wp_send_json_error(array('message' => 'Usuário não encontrado'));
    }
    
    $timezone = wp_timezone();
    
    // Dados do último acesso
    $last_timestamp = get_user_meta($user_id, '_raz_last_access_timestamp', true);
    $last_aula_id = get_user_meta($user_id, '_raz_last_access_aula', true);
    $last_curso_id = get_user_meta($user_id, '_raz_last_access_curso', true);
    $last_modulo_id = get_user_meta($user_id, '_raz_last_access_modulo', true);
    $last_browser = get_user_meta($user_id, '_raz_last_browser', true);
    $last_os = get_user_meta($user_id, '_raz_last_os', true);
    $last_ip = get_user_meta($user_id, '_raz_last_access_ip', true);
    
    $last_access = array(
        'date' => 'Nunca',
        'dias_sem_acesso' => '-',
        'aula' => '-',
        'curso' => '-',
        'browser' => $last_browser ?: '-',
        'os' => $last_os ?: '-',
        'ip' => $last_ip ?: '-'
    );
    
    if ($last_timestamp) {
        $dt = new DateTime('@' . $last_timestamp);
        $dt->setTimezone($timezone);
        $last_access['date'] = $dt->format('d/m/Y H:i');
        
        $now = new DateTime('now', $timezone);
        $diff = $now->diff($dt);
        $last_access['dias_sem_acesso'] = $diff->days;
    }
    
    if ($last_aula_id) {
        $aula = get_post($last_aula_id);
        if ($aula) $last_access['aula'] = $aula->post_title;
    }
    
    if ($last_curso_id) {
        $curso = get_post($last_curso_id);
        if ($curso) $last_access['curso'] = $curso->post_title;
    }
    
    // Posição atual (módulo e aula sendo estudado)
    $posicao = array(
        'modulo' => '-',
        'aula' => '-',
        'progresso' => '0%'
    );
    
    if ($last_modulo_id) {
        $modulo = get_post($last_modulo_id);
        if ($modulo) $posicao['modulo'] = $modulo->post_title;
    }
    
    if ($last_aula_id) {
        $aula = get_post($last_aula_id);
        if ($aula) $posicao['aula'] = $aula->post_title;
    }
    
    if ($last_curso_id) {
        $progress = raz_lms_get_course_progress($user_id, $last_curso_id);
        if ($progress) {
            $posicao['progresso'] = $progress['percent'] . '%';
        }
    }
    
    // Origem do cadastro
    $origem = 'manual';
    global $wpdb;
    $acesso_meta = $wpdb->get_var($wpdb->prepare(
        "SELECT meta_value FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key LIKE '_raz_curso_acesso_%%' LIMIT 1",
        $user_id
    ));
    if ($acesso_meta) {
        $acesso_data = maybe_unserialize($acesso_meta);
        if (isset($acesso_data['origem'])) {
            $origem = $acesso_data['origem'];
        }
    }
    
    // Histórico com paginação
    $history = get_user_meta($user_id, '_raz_access_history', true);
    if (!is_array($history)) $history = array();
    
    $total_acessos = count($history);
    $total_pages = ceil($total_acessos / $per_page);
    $offset = ($page - 1) * $per_page;
    $history_page = array_slice($history, $offset, $per_page);
    
    $history_data = array();
    foreach ($history_page as $h) {
        $date = '-';
        if (isset($h['timestamp'])) {
            $dt = new DateTime('@' . $h['timestamp']);
            $dt->setTimezone($timezone);
            $date = $dt->format('d/m/Y H:i');
        }
        
        $curso_title = '-';
        if (isset($h['curso_id']) && $h['curso_id']) {
            $curso = get_post($h['curso_id']);
            if ($curso) $curso_title = $curso->post_title;
        }
        
        $modulo_title = '-';
        if (isset($h['modulo_id']) && $h['modulo_id']) {
            $modulo = get_post($h['modulo_id']);
            if ($modulo) $modulo_title = $modulo->post_title;
        }
        
        $aula_title = '-';
        if (isset($h['aula_id']) && $h['aula_id']) {
            $aula = get_post($h['aula_id']);
            if ($aula) $aula_title = $aula->post_title;
        }
        
        $history_data[] = array(
            'date' => $date,
            'curso' => $curso_title,
            'modulo' => $modulo_title,
            'aula' => $aula_title,
            'ip' => isset($h['ip']) ? $h['ip'] : '-'
        );
    }
    
    wp_send_json_success(array(
        'user' => array(
            'name' => $user->display_name,
            'email' => $user->user_email,
            'registered' => wp_date('d/m/Y', strtotime($user->user_registered)),
            'origem' => $origem
        ),
        'last_access' => $last_access,
        'posicao' => $posicao,
        'history' => $history_data,
        'total_acessos' => $total_acessos,
        'total_pages' => $total_pages,
        'current_page' => $page
    ));
}
add_action('wp_ajax_raz_get_user_audit', 'raz_lms_ajax_get_user_audit');
