<?php
/**
 * Sistema de Grupos de Acesso
 * Gerencia permissões de acesso a cursos e aulas através de grupos
 * 
 * @package RazMidiasLMS
 * @version 1.0.0
 */

defined('ABSPATH') || exit;

/**
 * ARQUITETURA ESCOLHIDA:
 * 
 * 1. CPT 'grupo_acesso' - Armazena os grupos como posts
 *    - Facilita gestão via admin nativo do WordPress
 *    - Permite usar recursos nativos (título, slug, status)
 * 
 * 2. Post Meta do grupo:
 *    - '_raz_grupo_cursos' => array de IDs de cursos
 *    - '_raz_grupo_aulas' => array de IDs de aulas
 *    - '_raz_grupo_is_default' => bool (apenas um pode ser default)
 * 
 * 3. User Meta:
 *    - '_raz_user_grupos' => array de IDs de grupos
 * 
 * VANTAGENS:
 * - Performance: Uma única query busca todos os grupos do usuário
 * - Escalabilidade: Cache automático do WordPress
 * - Manutenibilidade: Estrutura padrão WP
 * - Flexibilidade: Fácil adicionar novos campos
 */

// ============================================================================
// 1. REGISTRO DO CPT
// ============================================================================

add_action('init', 'raz_register_grupo_acesso_cpt');
function raz_register_grupo_acesso_cpt() {
    register_post_type('grupo_acesso', array(
        'labels' => array(
            'name' => 'Grupos de Acesso',
            'singular_name' => 'Grupo de Acesso',
            'add_new' => 'Adicionar Novo',
            'add_new_item' => 'Adicionar Novo Grupo',
            'edit_item' => 'Editar Grupo',
            'new_item' => 'Novo Grupo',
            'view_item' => 'Ver Grupo',
            'search_items' => 'Buscar Grupos',
            'not_found' => 'Nenhum grupo encontrado',
            'menu_name' => 'Grupos de Acesso',
        ),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => 'edit.php?post_type=curso',
        'menu_position' => 6,
        'supports' => array('title'),
        'capability_type' => 'post',
        'map_meta_cap' => true,
    ));
}

// ============================================================================
// 2. FUNÇÕES PRINCIPAIS DE VALIDAÇÃO DE ACESSO
// ============================================================================

/**
 * Verifica se o usuário tem acesso a um curso
 * 
 * @param int $user_id ID do usuário
 * @param int $curso_id ID do curso
 * @return bool True se tem acesso
 */
function raz_user_can_access_curso($user_id, $curso_id) {
    // Admin sempre tem acesso
    if (user_can($user_id, 'manage_options')) {
        return true;
    }
    
    // Busca grupos do usuário (com cache)
    $user_grupos = raz_get_user_grupos($user_id);
    
    if (empty($user_grupos)) {
        return false;
    }
    
    // Verifica se algum grupo libera o curso
    foreach ($user_grupos as $grupo_id) {
        $cursos_liberados = get_post_meta($grupo_id, '_raz_grupo_cursos', true);
        
        if (is_array($cursos_liberados) && in_array($curso_id, $cursos_liberados)) {
            return true;
        }
    }
    
    return false;
}

/**
 * Verifica se o usuário tem acesso a uma aula
 * 
 * @param int $user_id ID do usuário
 * @param int $aula_id ID da aula
 * @return bool True se tem acesso
 */
function raz_user_can_access_aula($user_id, $aula_id) {
    // Admin sempre tem acesso
    if (user_can($user_id, 'manage_options')) {
        return true;
    }
    
    // Verifica se tem acesso direto à aula
    $has_direct_access = raz_check_direct_aula_access($user_id, $aula_id);
    if ($has_direct_access) {
        return true;
    }
    
    // Verifica se tem acesso via curso
    $curso_id = get_post_meta($aula_id, '_aula_curso_id', true);
    if ($curso_id && raz_user_can_access_curso($user_id, $curso_id)) {
        return true;
    }
    
    return false;
}

/**
 * Verifica acesso direto a uma aula específica (sem passar pelo curso)
 * 
 * @param int $user_id ID do usuário
 * @param int $aula_id ID da aula
 * @return bool True se tem acesso direto
 */
function raz_check_direct_aula_access($user_id, $aula_id) {
    $user_grupos = raz_get_user_grupos($user_id);
    
    if (empty($user_grupos)) {
        return false;
    }
    
    foreach ($user_grupos as $grupo_id) {
        $aulas_liberadas = get_post_meta($grupo_id, '_raz_grupo_aulas', true);
        
        if (is_array($aulas_liberadas) && in_array($aula_id, $aulas_liberadas)) {
            return true;
        }
    }
    
    return false;
}

// ============================================================================
// 3. FUNÇÕES AUXILIARES
// ============================================================================

/**
 * Busca todos os grupos de um usuário (com cache)
 * 
 * @param int $user_id ID do usuário
 * @return array Array de IDs de grupos
 */
function raz_get_user_grupos($user_id) {
    static $cache = array();
    
    if (isset($cache[$user_id])) {
        return $cache[$user_id];
    }
    
    $grupos = get_user_meta($user_id, '_raz_user_grupos', true);
    
    if (!is_array($grupos)) {
        $grupos = array();
    }
    
    // Remove grupos que não existem mais
    $grupos = array_filter($grupos, function($grupo_id) {
        return get_post_status($grupo_id) === 'publish';
    });
    
    $cache[$user_id] = $grupos;
    
    return $grupos;
}

/**
 * Adiciona um usuário a um grupo
 * 
 * @param int $user_id ID do usuário
 * @param int $grupo_id ID do grupo
 * @return bool True se adicionado com sucesso
 */
function raz_add_user_to_grupo($user_id, $grupo_id) {
    $grupos = raz_get_user_grupos($user_id);
    
    if (!in_array($grupo_id, $grupos)) {
        $grupos[] = $grupo_id;
        update_user_meta($user_id, '_raz_user_grupos', $grupos);
        
        // Limpa cache
        raz_clear_user_access_cache($user_id);
        
        return true;
    }
    
    return false;
}

/**
 * Remove um usuário de um grupo
 * 
 * @param int $user_id ID do usuário
 * @param int $grupo_id ID do grupo
 * @return bool True se removido com sucesso
 */
function raz_remove_user_from_grupo($user_id, $grupo_id) {
    $grupos = raz_get_user_grupos($user_id);
    
    $key = array_search($grupo_id, $grupos);
    if ($key !== false) {
        unset($grupos[$key]);
        update_user_meta($user_id, '_raz_user_grupos', array_values($grupos));
        
        // Limpa cache
        raz_clear_user_access_cache($user_id);
        
        return true;
    }
    
    return false;
}

/**
 * Limpa o cache de acesso do usuário
 * 
 * @param int $user_id ID do usuário
 */
function raz_clear_user_access_cache($user_id) {
    // Limpa cache estático
    static $cache = array();
    unset($cache[$user_id]);
}

/**
 * Busca o grupo padrão
 * 
 * @return int|false ID do grupo padrão ou false
 */
function raz_get_default_grupo() {
    $args = array(
        'post_type' => 'grupo_acesso',
        'posts_per_page' => 1,
        'meta_query' => array(
            array(
                'key' => '_raz_grupo_is_default',
                'value' => '1',
                'compare' => '='
            )
        )
    );
    
    $query = new WP_Query($args);
    
    if ($query->have_posts()) {
        return $query->posts[0]->ID;
    }
    
    return false;
}

/**
 * Define um grupo como padrão
 * 
 * @param int $grupo_id ID do grupo
 */
function raz_set_default_grupo($grupo_id) {
    // Remove flag default de todos os grupos
    $all_grupos = get_posts(array(
        'post_type' => 'grupo_acesso',
        'posts_per_page' => -1,
        'fields' => 'ids'
    ));
    
    foreach ($all_grupos as $id) {
        delete_post_meta($id, '_raz_grupo_is_default');
    }
    
    // Define o novo grupo padrão
    update_post_meta($grupo_id, '_raz_grupo_is_default', '1');
}

/**
 * Adiciona automaticamente novos usuários ao grupo padrão
 */
add_action('user_register', 'raz_add_new_user_to_default_grupo');
function raz_add_new_user_to_default_grupo($user_id) {
    $default_grupo = raz_get_default_grupo();
    
    if ($default_grupo) {
        raz_add_user_to_grupo($user_id, $default_grupo);
    }
}

// ============================================================================
// 4. INTEGRAÇÃO COM TEMPLATES
// ============================================================================

/**
 * Adiciona validação de acesso nos templates single-curso.php e single-aula.php
 * Usar no topo dos templates:
 * 
 * if (!raz_validate_access_or_redirect('curso')) {
 *     return;
 * }
 */
function raz_validate_access_or_redirect($post_type = 'curso') {
    if (!is_user_logged_in()) {
        wp_redirect(home_url('/login'));
        exit;
    }
    
    $user_id = get_current_user_id();
    $post_id = get_the_ID();
    
    $has_access = false;
    
    if ($post_type === 'curso') {
        $has_access = raz_user_can_access_curso($user_id, $post_id);
    } elseif ($post_type === 'aula') {
        $has_access = raz_user_can_access_aula($user_id, $post_id);
    }
    
    if (!$has_access) {
        // Redireciona para página de bloqueio
        raz_display_access_blocked($post_type);
        return false;
    }
    
    return true;
}

/**
 * Exibe mensagem de acesso bloqueado
 */
function raz_display_access_blocked($post_type = 'curso') {
    get_header();
    
    $titulo = $post_type === 'curso' ? 'Curso' : 'Aula';
    ?>
    <div class="raz-access-blocked">
        <div class="container">
            <div class="access-blocked-content">
                <div class="icon">🔒</div>
                <h1>Acesso Restrito</h1>
                <p>Você não tem permissão para acessar este <?php echo strtolower($titulo); ?>.</p>
                <p>Entre em contato com o suporte se acredita que isto é um erro.</p>
                <a href="<?php echo home_url('/cursos'); ?>" class="btn btn-primary">Ver Meus Cursos</a>
            </div>
        </div>
    </div>
    <?php
    
    get_footer();
    exit;
}

/**
 * Filtra lista de cursos exibindo apenas os que o usuário tem acesso
 */
function raz_filter_courses_by_access($query) {
    if (!is_admin() && $query->is_main_query() && is_post_type_archive('curso')) {
        if (is_user_logged_in() && !current_user_can('manage_options')) {
            $user_id = get_current_user_id();
            $accessible_cursos = raz_get_user_accessible_cursos($user_id);
            
            if (!empty($accessible_cursos)) {
                $query->set('post__in', $accessible_cursos);
            } else {
                // Nenhum curso acessível
                $query->set('post__in', array(0));
            }
        }
    }
}
add_action('pre_get_posts', 'raz_filter_courses_by_access');

/**
 * Busca todos os cursos que o usuário tem acesso
 * 
 * @param int $user_id ID do usuário
 * @return array Array de IDs de cursos
 */
function raz_get_user_accessible_cursos($user_id) {
    $cache_key = 'raz_user_cursos_' . $user_id;
    $cached = wp_cache_get($cache_key);
    
    if ($cached !== false) {
        return $cached;
    }
    
    $user_grupos = raz_get_user_grupos($user_id);
    $accessible_cursos = array();
    
    foreach ($user_grupos as $grupo_id) {
        $cursos = get_post_meta($grupo_id, '_raz_grupo_cursos', true);
        
        if (is_array($cursos)) {
            $accessible_cursos = array_merge($accessible_cursos, $cursos);
        }
    }
    
    $accessible_cursos = array_unique($accessible_cursos);
    
    wp_cache_set($cache_key, $accessible_cursos, '', 3600);
    
    return $accessible_cursos;
}
