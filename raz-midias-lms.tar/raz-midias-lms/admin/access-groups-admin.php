<?php
/**
 * Admin Interface - Grupos de Acesso
 * Metaboxes e campos customizados para gerenciar grupos
 * 
 * @package RazMidiasLMS
 */

defined('ABSPATH') || exit;

// ============================================================================
// METABOXES DO GRUPO DE ACESSO
// ============================================================================

add_action('add_meta_boxes', 'raz_grupo_acesso_metaboxes');
function raz_grupo_acesso_metaboxes() {
    add_meta_box(
        'raz_grupo_cursos',
        'Cursos Liberados',
        'raz_grupo_cursos_metabox',
        'grupo_acesso',
        'normal',
        'high'
    );
    
    add_meta_box(
        'raz_grupo_aulas',
        'Aulas Específicas Liberadas',
        'raz_grupo_aulas_metabox',
        'grupo_acesso',
        'normal',
        'high'
    );
    
    add_meta_box(
        'raz_grupo_config',
        'Configurações do Grupo',
        'raz_grupo_config_metabox',
        'grupo_acesso',
        'side',
        'default'
    );
}

/**
 * Metabox: Selecionar Cursos
 */
function raz_grupo_cursos_metabox($post) {
    wp_nonce_field('raz_save_grupo_meta', 'raz_grupo_nonce');
    
    $selected_cursos = get_post_meta($post->ID, '_raz_grupo_cursos', true);
    if (!is_array($selected_cursos)) {
        $selected_cursos = array();
    }
    
    $cursos = get_posts(array(
        'post_type' => 'curso',
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'ASC'
    ));
    
    ?>
    <div class="raz-grupo-cursos-selector">
        <p class="description">Selecione os cursos que este grupo terá acesso. O acesso ao curso inclui automaticamente todas as aulas.</p>
        
        <div class="raz-cursos-list">
            <?php if (empty($cursos)): ?>
                <p><em>Nenhum curso cadastrado ainda.</em></p>
            <?php else: ?>
                <div class="raz-select-all">
                    <label>
                        <input type="checkbox" id="select-all-cursos"> 
                        <strong>Selecionar todos</strong>
                    </label>
                </div>
                
                <div class="raz-cursos-grid">
                    <?php foreach ($cursos as $curso): ?>
                        <label class="raz-curso-item">
                            <input 
                                type="checkbox" 
                                name="raz_grupo_cursos[]" 
                                value="<?php echo $curso->ID; ?>"
                                <?php checked(in_array($curso->ID, $selected_cursos)); ?>
                            >
                            <span class="curso-title"><?php echo esc_html($curso->post_title); ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <style>
        .raz-cursos-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-top: 15px;
        }
        .raz-curso-item {
            display: flex;
            align-items: center;
            padding: 10px;
            background: #f0f0f1;
            border-radius: 4px;
            cursor: pointer;
        }
        .raz-curso-item:hover {
            background: #e5e5e5;
        }
        .raz-curso-item input {
            margin-right: 8px;
        }
        .raz-select-all {
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #ddd;
        }
    </style>
    
    <script>
    jQuery(document).ready(function($) {
        $('#select-all-cursos').on('change', function() {
            $('input[name="raz_grupo_cursos[]"]').prop('checked', this.checked);
        });
    });
    </script>
    <?php
}

/**
 * Metabox: Selecionar Aulas Específicas
 */
function raz_grupo_aulas_metabox($post) {
    $selected_aulas = get_post_meta($post->ID, '_raz_grupo_aulas', true);
    if (!is_array($selected_aulas)) {
        $selected_aulas = array();
    }
    
    // Busca aulas agrupadas por curso
    $cursos = get_posts(array(
        'post_type' => 'curso',
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'ASC'
    ));
    
    ?>
    <div class="raz-grupo-aulas-selector">
        <p class="description">
            Selecione aulas específicas que este grupo terá acesso, <strong>independente do curso</strong>.<br>
            <em>Use isto para liberar apenas algumas aulas de um curso sem liberar o curso completo.</em>
        </p>
        
        <div class="raz-aulas-list">
            <?php foreach ($cursos as $curso): ?>
                <?php
                $aulas = get_posts(array(
                    'post_type' => 'aula',
                    'posts_per_page' => -1,
                    'meta_key' => '_aula_curso_id',
                    'meta_value' => $curso->ID,
                    'orderby' => 'meta_value_num',
                    'order' => 'ASC',
                    'meta_query' => array(
                        array(
                            'key' => '_aula_order',
                            'type' => 'NUMERIC'
                        )
                    )
                ));
                
                if (!empty($aulas)):
                ?>
                    <div class="raz-curso-aulas-group">
                        <h4><?php echo esc_html($curso->post_title); ?></h4>
                        
                        <div class="raz-aulas-grid">
                            <?php foreach ($aulas as $aula): ?>
                                <label class="raz-aula-item">
                                    <input 
                                        type="checkbox" 
                                        name="raz_grupo_aulas[]" 
                                        value="<?php echo $aula->ID; ?>"
                                        <?php checked(in_array($aula->ID, $selected_aulas)); ?>
                                    >
                                    <span class="aula-title"><?php echo esc_html($aula->post_title); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>
    
    <style>
        .raz-curso-aulas-group {
            margin-bottom: 25px;
            padding: 15px;
            background: #fafafa;
            border-left: 3px solid #2271b1;
        }
        .raz-curso-aulas-group h4 {
            margin-top: 0;
            color: #2271b1;
        }
        .raz-aulas-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 8px;
        }
        .raz-aula-item {
            display: flex;
            align-items: center;
            padding: 8px;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 3px;
            cursor: pointer;
        }
        .raz-aula-item:hover {
            background: #f0f0f1;
        }
        .raz-aula-item input {
            margin-right: 8px;
        }
    </style>
    <?php
}

/**
 * Metabox: Configurações
 */
function raz_grupo_config_metabox($post) {
    $is_default = get_post_meta($post->ID, '_raz_grupo_is_default', true);
    ?>
    <div class="raz-grupo-config">
        <p>
            <label>
                <input 
                    type="checkbox" 
                    name="raz_grupo_is_default" 
                    value="1"
                    <?php checked($is_default, '1'); ?>
                >
                <strong>Grupo Padrão</strong>
            </label>
        </p>
        <p class="description">
            Novos usuários serão automaticamente adicionados a este grupo.
            Apenas um grupo pode ser definido como padrão.
        </p>
    </div>
    <?php
}

/**
 * Salvar metadados do grupo
 */
add_action('save_post_grupo_acesso', 'raz_save_grupo_meta', 10, 2);
function raz_save_grupo_meta($post_id, $post) {
    // Verificações de segurança
    if (!isset($_POST['raz_grupo_nonce']) || !wp_verify_nonce($_POST['raz_grupo_nonce'], 'raz_save_grupo_meta')) {
        return;
    }
    
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    // Salvar cursos
    $cursos = isset($_POST['raz_grupo_cursos']) ? array_map('intval', $_POST['raz_grupo_cursos']) : array();
    update_post_meta($post_id, '_raz_grupo_cursos', $cursos);
    
    // Salvar aulas
    $aulas = isset($_POST['raz_grupo_aulas']) ? array_map('intval', $_POST['raz_grupo_aulas']) : array();
    update_post_meta($post_id, '_raz_grupo_aulas', $aulas);
    
    // Salvar grupo padrão
    if (isset($_POST['raz_grupo_is_default'])) {
        raz_set_default_grupo($post_id);
    } else {
        delete_post_meta($post_id, '_raz_grupo_is_default');
    }
}

// ============================================================================
// COLUNAS PERSONALIZADAS NA LISTA DE GRUPOS
// ============================================================================

add_filter('manage_grupo_acesso_posts_columns', 'raz_grupo_columns');
function raz_grupo_columns($columns) {
    $new_columns = array();
    
    foreach ($columns as $key => $value) {
        $new_columns[$key] = $value;
        
        if ($key === 'title') {
            $new_columns['cursos_count'] = 'Cursos';
            $new_columns['aulas_count'] = 'Aulas';
            $new_columns['users_count'] = 'Usuários';
            $new_columns['is_default'] = 'Padrão';
        }
    }
    
    return $new_columns;
}

add_action('manage_grupo_acesso_posts_custom_column', 'raz_grupo_column_content', 10, 2);
function raz_grupo_column_content($column, $post_id) {
    switch ($column) {
        case 'cursos_count':
            $cursos = get_post_meta($post_id, '_raz_grupo_cursos', true);
            echo is_array($cursos) ? count($cursos) : 0;
            break;
            
        case 'aulas_count':
            $aulas = get_post_meta($post_id, '_raz_grupo_aulas', true);
            echo is_array($aulas) ? count($aulas) : 0;
            break;
            
        case 'users_count':
            $count = raz_count_users_in_grupo($post_id);
            echo $count;
            break;
            
        case 'is_default':
            $is_default = get_post_meta($post_id, '_raz_grupo_is_default', true);
            echo $is_default ? '✓ Sim' : '';
            break;
    }
}

/**
 * Conta quantos usuários estão em um grupo
 */
function raz_count_users_in_grupo($grupo_id) {
    global $wpdb;
    
    $count = $wpdb->get_var($wpdb->prepare("
        SELECT COUNT(DISTINCT user_id)
        FROM {$wpdb->usermeta}
        WHERE meta_key = '_raz_user_grupos'
        AND meta_value LIKE %s
    ", '%' . $wpdb->esc_like(serialize(strval($grupo_id))) . '%'));
    
    return (int) $count;
}

// ============================================================================
// GERENCIAR GRUPOS NA EDIÇÃO DO USUÁRIO
// ============================================================================

add_action('show_user_profile', 'raz_user_grupos_fields');
add_action('edit_user_profile', 'raz_user_grupos_fields');
function raz_user_grupos_fields($user) {
    if (!current_user_can('edit_users')) {
        return;
    }
    
    $user_grupos = raz_get_user_grupos($user->ID);
    
    $all_grupos = get_posts(array(
        'post_type' => 'grupo_acesso',
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'ASC'
    ));
    
    ?>
    <h2>Grupos de Acesso</h2>
    <table class="form-table">
        <tr>
            <th><label>Grupos do Usuário</label></th>
            <td>
                <?php if (empty($all_grupos)): ?>
                    <p><em>Nenhum grupo cadastrado. <a href="<?php echo admin_url('post-new.php?post_type=grupo_acesso'); ?>">Criar primeiro grupo</a></em></p>
                <?php else: ?>
                    <fieldset>
                        <legend class="screen-reader-text"><span>Grupos de Acesso</span></legend>
                        
                        <?php foreach ($all_grupos as $grupo): ?>
                            <label style="display: block; margin-bottom: 8px;">
                                <input 
                                    type="checkbox" 
                                    name="raz_user_grupos[]" 
                                    value="<?php echo $grupo->ID; ?>"
                                    <?php checked(in_array($grupo->ID, $user_grupos)); ?>
                                >
                                <?php echo esc_html($grupo->post_title); ?>
                                
                                <?php if (get_post_meta($grupo->ID, '_raz_grupo_is_default', true)): ?>
                                    <span style="color: #2271b1;">(Padrão)</span>
                                <?php endif; ?>
                            </label>
                        <?php endforeach; ?>
                    </fieldset>
                    
                    <p class="description">
                        Selecione os grupos aos quais este usuário pertence.<br>
                        O acesso final é a soma de todos os grupos selecionados.
                    </p>
                <?php endif; ?>
            </td>
        </tr>
    </table>
    <?php
}

add_action('personal_options_update', 'raz_save_user_grupos');
add_action('edit_user_profile_update', 'raz_save_user_grupos');
function raz_save_user_grupos($user_id) {
    if (!current_user_can('edit_users')) {
        return;
    }
    
    $grupos = isset($_POST['raz_user_grupos']) ? array_map('intval', $_POST['raz_user_grupos']) : array();
    
    update_user_meta($user_id, '_raz_user_grupos', $grupos);
    
    raz_clear_user_access_cache($user_id);
}
